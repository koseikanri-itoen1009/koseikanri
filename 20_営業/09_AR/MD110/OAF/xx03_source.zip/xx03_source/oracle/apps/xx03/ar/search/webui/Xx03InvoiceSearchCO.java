/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005. All rights reserved.
 * FILENAME     Xx03InvoiceSearchCO.java
 * VERSION      11.5.10.1.6B
 * DATE         2006/02/02
 * HISTORY      2005/02/14  Ver1.0          �V�K�쐬
 *              2005/02/24  Ver1.1          �d�l�ύX�Ή��g��
 *              2005/03/17  Ver1.2          �m�F��ʑJ�ڎ��̃p�����[�^�ɓ`�[��ʂh�c��
 *                                          ���F�҂h�c��ǉ�
 *              2005/03/24  Ver1.3          �`�[�폜���̕s��Ή��g��
 *              2005/09/07  Ver11.5.10.1.5  ���������Z�b�g�����̕s��C��
 *              2006/01/30  Ver11.5.10.1.6  ������ʂ̉�ʑJ�ڕύX�Ή�
 *              2006/02/02  Ver11.5.10.1.6B �{�^���̃_�u���N���b�N�Ή�
 *===========================================================================*/
package oracle.apps.xx03.ar.search.webui;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import java.util.ArrayList;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OADefaultHideShowBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAFlowLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAMessageComponentLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASeparatorBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASpacerBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.table.OATableBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;
//Ver11.5.10.1.6 Add Start
import oracle.apps.xx03.util.Xx03CommonUtil;
//Ver11.5.10.1.6 Add End

import oracle.jbo.domain.Date;

//ver11.5.10.1.6B Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6B Add End

/**
 *
 * Xx03InvoiceSearch��CO
 *
 * @version     11.5.10.1.6
 */
public class Xx03InvoiceSearchCO extends OAControllerImpl
{
  public static final String  RCS_ID          = "$Header$: Xx03InvoiceSearchCO.java 2005/02/14";
  public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.ar.search.webui");

  /*
  public OARawTextBean                message;
  public OAMessageComponentLayoutBean conditionRN;
  public OAFlowLayoutBean             searchBtnRN;
  public OASeparatorBean              separator1;
  public OASpacerBean                 spacer1;
  public OATableBean                  resultRN;
  public OATableBean                  approveConfirmRN;
  public OATableBean                  approverResultRN;
  public OAFlowLayoutBean             delConfirmRN;
  public OAFlowLayoutBean             massApprovalRN;
  public OADefaultHideShowBean        searchShow;
  public OADefaultHideShowBean        detailShow;
  */

  public Xx03InvoiceSearchCO()
  {
  }

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //ver11.5.10.1.6B Add Start
    OAApplicationModule am = pageContext.getRootApplicationModule();
    
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6B Add End

    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    // �X�e�[�^�X�̒l���Œ�ɂ��āA��ʔ�\���ɂ���
    OAMessageChoiceBean status    = (OAMessageChoiceBean)webBean.findChildRecursive("WfStatus");

    // ���F�{�^���̕\����ύX����
    OASubmitButtonBean allApprove = (OASubmitButtonBean)massApprovalRN.findChildRecursive("MassApprovalBtn");
    OASubmitButtonBean approveYes = (OASubmitButtonBean)massApprovalRN.findChildRecursive("approveYes");
    OASubmitButtonBean approveNo  = (OASubmitButtonBean)massApprovalRN.findChildRecursive("approveNo");

    //ver11.5.10.1.6B Del Start
    //OAApplicationModule am = pageContext.getRootApplicationModule();
    //ver11.5.10.1.6B Del End

    // ��������AFF,DFF�v�����v�g�ݒ�
    OAMessageLovInputBean linesDepartment = (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
    OAMessageLovInputBean linesAccountCode = (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
    OAWebBeanTextInput reconReference = (OAWebBeanTextInput)webBean.findChildRecursive("ReconReference");
    ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptArSearch");
    String affSearchHeader = pageContext.getMessage("XX03", "APP-XX03-33503", null);
    linesDepartment.setPrompt(affSearchHeader + (String)affPromptInfo.get(1));
    linesAccountCode.setPrompt(affSearchHeader + (String)affPromptInfo.get(2));
    reconReference.setLabel(affSearchHeader + (String)affPromptInfo.get(9));
    

    // �p�����[�^�쐬
    OAFormValueBean delReceivableId  = (OAFormValueBean)webBean.findChildRecursive("delReceivableId");
    OAFormValueBean delReceivableNum = (OAFormValueBean)webBean.findChildRecursive("delReceivableNum");
    OAFormValueBean searchKind       = (OAFormValueBean)webBean.findChildRecursive("searchKind");   // ���j���[��������p���p�����[�^��

    delReceivableId.setValue(pageContext, null);
    delReceivableNum.setValue(pageContext, null);

    // ��ʑS���ڂ��\����
    unDispAll(webBean);

    // �p�����[�^�擾
    String transaction  = null;
    String searchParam  = null;
    String approveParam = null;

    transaction  = pageContext.getParameter("transaction");
    searchParam  = pageContext.getParameter("search");
    approveParam = pageContext.getParameter("approverSearch");
    if (transaction == null)
    {
      transaction = "";
    }
    if (searchParam == null)
    {
      searchParam = "";
    }
    if (approveParam == null)
    {
      approveParam = "";
    }

    // �����\���i�����j
    if ((searchParam.equals("true")) ||
        (searchParam.equals("")))
    {
      //------------------------------------------------------------------------
      // ����
      if (transaction.equals("result"))
      {
        // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        result(webBean);

        // �����������Z�b�g����B
//        setSearchItem(pageContext, webBean);

        // �B���t�B�[���h�Ɂu�񏳔F�v��ݒ�
        searchKind.setValue(pageContext,"noApprover");

        // ���������s����B
        am.invokeMethod("getReceivableResult");
      }
      //------------------------------------------------------------------------
      // �폜�m�F���
      else if (transaction.equals("deleteConfirm"))
      {
        // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        deleteConfirm(webBean);

        // �B���t�B�[���h�Ɂu�񏳔F�v��ݒ�
        searchKind.setValue(pageContext,"noApprover");

        String receivableNum = pageContext.getParameter("receivableNum");
        String receivableId  = pageContext.getParameter("receivableId");

        delReceivableId.setValue(pageContext, receivableId);
        delReceivableNum.setValue(pageContext, receivableNum);

        // �폜�Ώۂ̓`�[ID���擾����B
        pageContext.putParameter("receivableId",   receivableId);

        // �폜�m�F���b�Z�[�W��ݒ肷��B
        MessageToken msg = new MessageToken("TOK_XX03_DELETE_SLIP", receivableNum);
        OAException  ex  = new OAException("XX03", "APP-XX03-34055", new MessageToken[]{msg});
        ex.setApplicationModule(am);
        message.setText(ex.getMessage());
      }
      //------------------------------------------------------------------------
      // �폜OK
      else if (transaction.equals("deleteOK"))
      {
        String receivableNum  = pageContext.getParameter("receivableNum");
        String receivableId   = pageContext.getParameter("receivableId");

        // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        result(webBean);

        // �B���t�B�[���h�Ɂu�񏳔F�v��ݒ�
        searchKind.setValue(pageContext,"noApprover");

        Serializable[] param = new Serializable[]{receivableId};
        Serializable[] returnValue = new Serializable[]{am.invokeMethod("deleteReceivable", param)};
        String errMsg = (String)returnValue[0];

        // �Č������s���B
        am.invokeMethod("getReceivableResult");

        // �G���[�̂Ƃ�
        if (errMsg != null)
        {
          // �����X�V�`�F�b�N�G���[�̂Ƃ�
          if (errMsg.equals("1"))
          {
            MessageToken[] tokens = {new MessageToken("TOK_XX03_RECEIVABLE_NUM", receivableNum)};
            throw new OAException("XX03", "APP-XX03-13042", tokens);
          }
          else
          {
            throw new OAException("XX03", "APP-XX03-14999", null, OAException.ERROR, null);
          }
        }
        // ����ɍ폜�ł����Ƃ�
        else
        {
          MessageToken msg = new MessageToken("TOK_XX03_AP_DELETE", receivableNum);
          throw new OAException("XX03", "APP-XX03-14128",new MessageToken[]{msg},OAException.INFORMATION, null);
        }
      }
      //------------------------------------------------------------------------
      // �폜NG�i���Ƃ̉�ʂɖ߂�j
      else if (transaction.equals("deleteNG"))
      {
        // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        result(webBean);

        // �B���t�B�[���h�Ɂu�񏳔F�v��ݒ�
        searchKind.setValue(pageContext,"noApprover");
      }
      //------------------------------------------------------------------------
      // �@�\�ݒ�Ȃ�
      else if (transaction.equals(""))
      {
        // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        search(webBean);

        // �B���t�B�[���h�Ɂu�񏳔F�v��ݒ�
        searchKind.setValue(pageContext,"noApprover");
        am.invokeMethod("createSearchRow",new Serializable[]{"search"});

        // �m�F��ʂ���u�߂�v�{�^�����������ꂽ��̉�ʐ���
        //Ver11.5.10.1.6 Change Start
        //if (pageContext.getParameter("pageStatus") != null &&
        //    pageContext.getParameter("pageStatus").equals(Xx03ArCommonUtil.WINDOW_NAME_CONFIRM))
        //{
        //  // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
        //  result(webBean);
        //  // �p�����[�^���擾���A�����ɃZ�b�g
        //  setSearchItem(pageContext, webBean);

        //  // �Č������s���B
        //  am.invokeMethod("getReceivableResult");

        Object objPageStatus = pageContext.getParameter("pageStatus");          
        if (objPageStatus != null)
        {
          if (objPageStatus.equals(Xx03ArCommonUtil.WINDOW_NAME_CONFIRM))
          {
            // ��ʂ̕\���E��\���Ώۃ��[�W�����̐ݒ�
            result(webBean);
            // �p�����[�^���擾���A�����ɃZ�b�g
            setSearchItem(pageContext, webBean);

            // �Č������s���B
            am.invokeMethod("getReceivableResult");
            String messageSpecified=pageContext.getParameter("messages");
            if(null!=messageSpecified && !"".equals(messageSpecified))
            {
              pageContext.putDialogMessage(Xx03CommonUtil.stringToBundledOAException(messageSpecified));
            }
          }
          else
          {
            // ������ʈȊO����J�ځB
            // �Z�b�V�����Ɋi�[���������������N���A�B
            removeSearchItem(pageContext);
          }
        }
        else
        {
          // ���j���[����J�ځB
          // �Z�b�V�����Ɋi�[���������������N���A�B
          removeSearchItem(pageContext);
        }
        //Ver11.5.10.1.6 Change End
      }
    }

    //ver11.5.10.1.6B Add Start
    }
    //ver11.5.10.1.6B Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    OAApplicationModule am = pageContext.getRootApplicationModule();

    //------------------------------------------------------------------------
    // �����{�^��������
    if (pageContext.getParameter("SearchBtn") != null)
    {
      Vector vector = new Vector();

      // ���t�`�F�b�N
      Serializable[] returnValue =new Serializable[]{am.invokeMethod("dateInputCheck")};
      vector = (Vector)returnValue[0];
      if (vector != null)
      {
        throw OAException.getBundledOAException(vector);
      }
      else
      {
        String kind = pageContext.getParameter("searchKind");
        
        // �����̏ꍇ�̃p�����[�^�Z�b�g
        pageContext.putParameter("approverSearch","false");
        pageContext.putParameter("search","true");

        pageContext.putParameter("transaction", "result");
        pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_SEARCH,
                                  null,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  true,
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
    }
    //------------------------------------------------------------------------
    // �m�F�{�^��������
    //  else if (pageContext.getParameter("Confirm") != null)
    // ver 1.3 change start -----------------------------------------------------
    //    else if (pageContext.getParameter(EVENT_PARAM).equals("Confirm"))
    else if ("Confirm".equals(pageContext.getParameter(EVENT_PARAM)))
    // ver 1.3 change end -------------------------------------------------------
    {
      // ���������̃A�C�e��Bean�쐬
      OAMessageLovInputBean  oaEntryDepartment   = (OAMessageLovInputBean)webBean.findChildRecursive("EntryDepartment");
      OAMessageLovInputBean  oaEntryPersonName   = (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
      OAMessageChoiceBean    oaWfStatus          = (OAMessageChoiceBean)webBean.findChildRecursive("WfStatus");
      OAMessageLovInputBean  oaSlipType          = (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
      // ver1.2 add start --------------------------------------------------------- */   
      OAFormValueBean        oaSlipTypeId        = (OAFormValueBean)webBean.findChildRecursive("SlipTypeCodeId");
      // ver1.2 add end ----------------------------------------------------------- */   
      OAMessageTextInputBean oaReceivableNum     = (OAMessageTextInputBean)webBean.findChildRecursive("ReceivableNum");
      OAMessageLovInputBean  oaApprover          = (OAMessageLovInputBean)webBean.findChildRecursive("Approver");
      // ver1.2 add start --------------------------------------------------------- */   
      OAFormValueBean        oaApproverId  = (OAFormValueBean)webBean.findChildRecursive("ApproverPersonId");
      // ver1.2 add end ----------------------------------------------------------- */   

      OAMessageLovInputBean  oaCustomerName      = (OAMessageLovInputBean)webBean.findChildRecursive("CustomerName");
      OAMessageDateFieldBean oaInvoiceDateStart  = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateStart");
      OAMessageDateFieldBean oaInvoiceDateEnd    = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateEnd");
      OAMessageDateFieldBean oaEntryDateStart    = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateStart");
      OAMessageDateFieldBean oaEntryDateEnd      = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateEnd");

      OAMessageDateFieldBean oaGlDateStart       = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
      OAMessageDateFieldBean oaGlDateEnd         = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
      OAMessageDateFieldBean oaPaymentScheduledDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("PaymentScheduledDateStart");
      OAMessageDateFieldBean oaPaymentScheduledDateEnd = (OAMessageDateFieldBean)webBean.findChildRecursive("PaymentScheduledDateEnd");

      OAMessageLovInputBean  oaReceiptMethodName = (OAMessageLovInputBean)webBean.findChildRecursive("ReceiptMethodName");
      OAMessageLovInputBean  oaLinesDepartment   = (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
      OAMessageLovInputBean  oaLinesAccountCode  = (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
      OAMessageTextInputBean oaReconReference    = (OAMessageTextInputBean)webBean.findChildRecursive("ReconReference");

      OADefaultHideShowBean searchShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DefaultSearchRN");
      OADefaultHideShowBean detailShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DetailSearchRN");

      //Ver11.5.10.1.6 Change Start
      // �������ʑJ�ڂŌ���������ێ����Ă����Ȃ��Ă͂Ȃ�Ȃ��Ȃ������߁A
      // �ێ����TransientSessionValue�ɕύX�B
      // �p�����[�^�̃Z�b�g
      if (oaEntryDepartment.getValue(pageContext) != null)            // �N�[����
      {
        pageContext.putTransientSessionValue("paramEntryDepartment", oaEntryDepartment.getValue(pageContext));
      }
      if (oaEntryPersonName.getValue(pageContext) != null)            // �`�[���͎�
      {
        pageContext.putTransientSessionValue("paramEntryPersonName", oaEntryPersonName.getValue(pageContext));
      }
      if (oaWfStatus.getValue(pageContext) != null)                   // WF�X�e�[�^�X
      {
        pageContext.putTransientSessionValue("paramWfStatus", oaWfStatus.getValue(pageContext));
      }
      if (oaSlipType.getValue(pageContext) != null)                   // �`�[���
      {
        pageContext.putTransientSessionValue("paramSlipType", oaSlipType.getValue(pageContext));
      }
      if (oaSlipTypeId.getValue(pageContext) != null)                   // �`�[���ID
      {
        pageContext.putTransientSessionValue("paramSlipTypeId", oaSlipTypeId.getValue(pageContext));
      }
      if (oaReceivableNum.getValue(pageContext) != null)              // �`�[�ԍ�
      {
        pageContext.putTransientSessionValue("paramReceivableNum", oaReceivableNum.getValue(pageContext));
      }
      if (oaApprover.getValue(pageContext) != null)                   // ���F��
      {
        pageContext.putTransientSessionValue("paramApprover", oaApprover.getValue(pageContext));
      }
      if (oaApproverId.getValue(pageContext) != null)           // ���F��ID
      {
        pageContext.putTransientSessionValue("paramApproverId", oaApproverId.getValue(pageContext));
      }
      if (oaCustomerName.getValue(pageContext) != null)               // �ڋq��
      {
        pageContext.putTransientSessionValue("paramCustomerName", oaCustomerName.getValue(pageContext));
      }
      if (oaInvoiceDateStart.getValue(pageContext) != null)           // ���������t�i���j
      {
        pageContext.putTransientSessionValue("paramInvoiceDateStart", oaInvoiceDateStart.getValue(pageContext));
      }
      if (oaInvoiceDateEnd.getValue(pageContext) != null)             // ���������t�i���j
      {
        pageContext.putTransientSessionValue("paramInvoiceDateEnd", oaInvoiceDateEnd.getValue(pageContext));
      }
      if (oaEntryDateStart.getValue(pageContext) != null)             // �N�[���i���j
      {
        pageContext.putTransientSessionValue("paramEntryDateStart", oaEntryDateStart.getValue(pageContext));
      }
      if (oaEntryDateEnd.getValue(pageContext) != null)               // �N�[���i���j
      {
        pageContext.putTransientSessionValue("paramEntryDateEnd", oaEntryDateEnd.getValue(pageContext));
      }
      if (oaGlDateStart.getValue(pageContext) != null)                // �v����i���j
      {
        pageContext.putTransientSessionValue("paramGlDateStart", oaGlDateStart.getValue(pageContext));
      }
      if (oaGlDateEnd.getValue(pageContext) != null)                  // �v����i���j
      {
        pageContext.putTransientSessionValue("paramGlDateEnd", oaGlDateEnd.getValue(pageContext));
      }
      if (oaPaymentScheduledDateStart.getValue(pageContext) != null)  // �����\����i���j
      {
        pageContext.putTransientSessionValue("paramPaymentScheduledDateStart", oaPaymentScheduledDateStart.getValue(pageContext));
      }
      if (oaPaymentScheduledDateEnd.getValue(pageContext) != null)    // �����\����i���j
      {
        pageContext.putTransientSessionValue("paramPaymentScheduledDateEnd", oaPaymentScheduledDateEnd.getValue(pageContext));
      }
      if (oaReceiptMethodName.getValue(pageContext) != null)          // �x�����@��
      {
        pageContext.putTransientSessionValue("paramReceiptMethod", oaReceiptMethodName.getValue(pageContext));
      }
      if (oaLinesDepartment.getValue(pageContext) != null)            // ���ׁF����
      {
        pageContext.putTransientSessionValue("paramLinesDepartment", oaLinesDepartment.getValue(pageContext));
      }
      if (oaLinesAccountCode.getValue(pageContext) != null)           // ���ׁF����Ȗ�
      {
        pageContext.putTransientSessionValue("paramLinesAccountCode", oaLinesAccountCode.getValue(pageContext));
      }
      if (oaReconReference.getValue(pageContext) != null)             // ���ׁF�����Q��
      {
        pageContext.putTransientSessionValue("paramReconReference", oaReconReference.getValue(pageContext));
      }
      if(pageContext.getParameter("EntryDepartmentId") != null &&     // �N�[����ID
         pageContext.getParameter("EntryDepartmentId") != "")
      {
        pageContext.putTransientSessionValue("paramEntryDepartmentId", pageContext.getParameter("EntryDepartmentId"));
      }
      if(pageContext.getParameter("EntryPersonId") != null &&         // �`�[���͎�ID
         pageContext.getParameter("EntryPersonId") != "")
      {
        pageContext.putTransientSessionValue("paramEntryPersonId", pageContext.getParameter("EntryPersonId"));
      }
      if(pageContext.getParameter("ApproverPersonId") != null &&      // ���F��ID
         pageContext.getParameter("ApproverPersonId") != "")
      {
        pageContext.putTransientSessionValue("paramApproverPersonId", pageContext.getParameter("ApproverPersonId"));
      }
      if(pageContext.getParameter("SlipTypeCodeId") != null &&        // �`�[���ID
         pageContext.getParameter("SlipTypeCodeId") != "")
      {
        pageContext.putTransientSessionValue("paramSlipTypeCodeId", pageContext.getParameter("SlipTypeCodeId"));
      }

      if(pageContext.getParameter("CustomerId") != null &&            // �ڋqID
         pageContext.getParameter("CustomerId") != "")
      {
        pageContext.putTransientSessionValue("paramCustomerId", pageContext.getParameter("CustomerId"));
      }
      if(pageContext.getParameter("ReceiptMethodId") != null &&       // �x�����@ID 
         pageContext.getParameter("ReceiptMethodId") != "")
      {
        pageContext.putTransientSessionValue("paramReceiptMethodId", pageContext.getParameter("ReceiptMethodId"));
      }

      if(pageContext.getParameter("LinesDepartmentId") != null &&     // ���ׁF����ID
         pageContext.getParameter("LinesDepartmentId") != "")
      {
        pageContext.putTransientSessionValue("paramLinesDepartmentId", pageContext.getParameter("LinesDepartmentId"));
      }
      if(pageContext.getParameter("LinesAccountCodeId") != null &&   // // ���ׁF����Ȗ�ID
         pageContext.getParameter("LinesAccountCodeId") != "")
      {
        pageContext.putTransientSessionValue("paramLinesAccountCodeId", pageContext.getParameter("LinesAccountCodeId"));
      }
      if (searchShowItem.isDisclosed(pageContext) == true)
      {
        pageContext.putTransientSessionValue("searchShow", "true");
      }
      else
      {
        pageContext.putTransientSessionValue("searchShow", "false");
      }
      if (detailShowItem.isDisclosed(pageContext) == true)
      {
        pageContext.putTransientSessionValue("paramDetailShow", "true");
      }
      else
      {
        pageContext.putTransientSessionValue("paramDetailShow", "false");
      }

      //// �p�����[�^�̃Z�b�g
      //if (oaEntryDepartment.getValue(pageContext) != null)            // �N�[����
      //{
      //  pageContext.putParameter("paramEntryDepartment", oaEntryDepartment.getValue(pageContext));
      //}
      //if (oaEntryPersonName.getValue(pageContext) != null)            // �`�[���͎�
      //{
      //  pageContext.putParameter("paramEntryPersonName", oaEntryPersonName.getValue(pageContext));
      //}
      //if (oaWfStatus.getValue(pageContext) != null)                   // WF�X�e�[�^�X
      //{
      //  pageContext.putParameter("paramWfStatus", oaWfStatus.getValue(pageContext));
      //}
      //if (oaSlipType.getValue(pageContext) != null)                   // �`�[���
      //{
      //  pageContext.putParameter("paramSlipType", oaSlipType.getValue(pageContext));
      //}
      //// ver1.2 add start ---------------------------------------------------------
      //if (oaSlipTypeId.getValue(pageContext) != null)                   // �`�[���
      //{
      //  pageContext.putParameter("paramSlipTypeId", oaSlipTypeId.getValue(pageContext));
      //}
      //// ver1.2 add end ----------------------------------------------------------- */   
      //if (oaReceivableNum.getValue(pageContext) != null)              // �`�[�ԍ�
      //{
      //  pageContext.putParameter("paramReceivableNum", oaReceivableNum.getValue(pageContext));
      //}
      //if (oaApprover.getValue(pageContext) != null)                   // ���F��
      //{
      //  pageContext.putParameter("paramApprover", oaApprover.getValue(pageContext));
      //}
      //// ver1.2 add start ---------------------------------------------------------
      //if (oaApproverId.getValue(pageContext) != null)           // ���F��ID
      //{
      //  pageContext.putParameter("paramApproverId", oaApproverId.getValue(pageContext));
      //}
      //// ver1.2 add end ----------------------------------------------------------- */   
      //if (oaCustomerName.getValue(pageContext) != null)               // �ڋq��
      //{
      //  pageContext.putParameter("paramCustomerName", oaCustomerName.getValue(pageContext));
      //}
      //if (oaInvoiceDateStart.getValue(pageContext) != null)           // ���������t�i���j
      //{
      //  pageContext.putParameter("paramInvoiceDateStart", oaInvoiceDateStart.getValue(pageContext));
      //}
      //if (oaInvoiceDateEnd.getValue(pageContext) != null)             // ���������t�i���j
      //{
      //  pageContext.putParameter("paramInvoiceDateEnd", oaInvoiceDateEnd.getValue(pageContext));
      //}
      //if (oaEntryDateStart.getValue(pageContext) != null)             // �N�[���i���j
      //{
      //  pageContext.putParameter("paramEntryDateStart", oaEntryDateStart.getValue(pageContext));
      //}
      //if (oaEntryDateEnd.getValue(pageContext) != null)               // �N�[���i���j
      //{
      //  pageContext.putParameter("paramEntryDateEnd", oaEntryDateEnd.getValue(pageContext));
      //}
      //if (oaGlDateStart.getValue(pageContext) != null)                // �v����i���j
      //{
      //  pageContext.putParameter("paramGlDateStart", oaGlDateStart.getValue(pageContext));
      //}
      //if (oaGlDateEnd.getValue(pageContext) != null)                  // �v����i���j
      //{
      //  pageContext.putParameter("paramGlDateEnd", oaGlDateEnd.getValue(pageContext));
      //}
      //if (oaPaymentScheduledDateStart.getValue(pageContext) != null)  // �����\����i���j
      //{
      //  pageContext.putParameter("paramPaymentScheduledDateStart", oaPaymentScheduledDateStart.getValue(pageContext));
      //}
      //if (oaPaymentScheduledDateEnd.getValue(pageContext) != null)    // �����\����i���j
      //{
      //  pageContext.putParameter("paramPaymentScheduledDateEnd", oaPaymentScheduledDateEnd.getValue(pageContext));
      //}

      //if (oaReceiptMethodName.getValue(pageContext) != null)          // �x�����@��
      //{
      //  pageContext.putParameter("paramReceiptMethod", oaReceiptMethodName.getValue(pageContext));
      //}
      //if (oaLinesDepartment.getValue(pageContext) != null)            // ���ׁF����
      //{
      //  pageContext.putParameter("paramLinesDepartment", oaLinesDepartment.getValue(pageContext));
      //}
      //if (oaLinesAccountCode.getValue(pageContext) != null)           // ���ׁF����Ȗ�
      //{
      //  pageContext.putParameter("paramLinesAccountCode", oaLinesAccountCode.getValue(pageContext));
      //}
      //if (oaReconReference.getValue(pageContext) != null)             // ���ׁF�����Q��
      //{
      //  pageContext.putParameter("paramReconReference", oaReconReference.getValue(pageContext));
      //}

      //if(pageContext.getParameter("EntryDepartmentId") != null &&
      //   pageContext.getParameter("EntryDepartmentId") != "")
      //{
      //  pageContext.putParameter("paramEntryDepartmentId", pageContext.getParameter("EntryDepartmentId"));
      //}
      //if(pageContext.getParameter("EntryPersonId") != null &&
      //   pageContext.getParameter("EntryPersonId") != "")
      //{
      //  pageContext.putParameter("paramEntryPersonId", pageContext.getParameter("EntryPersonId"));
      //}
      //if(pageContext.getParameter("ApproverPersonId") != null &&
      //   pageContext.getParameter("ApproverPersonId") != "")
      //{
      //  pageContext.putParameter("paramApproverPersonId", pageContext.getParameter("ApproverPersonId"));
      //}
      //if(pageContext.getParameter("SlipTypeCodeId") != null &&
      //   pageContext.getParameter("SlipTypeCodeId") != "")
      //{
      //  pageContext.putParameter("paramSlipTypeCodeId", pageContext.getParameter("SlipTypeCodeId"));
      //}

      //if(pageContext.getParameter("CustomerId") != null &&
      //   pageContext.getParameter("CustomerId") != "")
      //{
      //  pageContext.putParameter("paramCustomerId", pageContext.getParameter("CustomerId"));
      //}
      //if(pageContext.getParameter("ReceiptMethodId") != null &&
      //   pageContext.getParameter("ReceiptMethodId") != "")
      //{
      //  pageContext.putParameter("paramReceiptMethodId", pageContext.getParameter("ReceiptMethodId"));
      //}

      //if(pageContext.getParameter("LinesDepartmentId") != null &&
      //   pageContext.getParameter("LinesDepartmentId") != "")
      //{
      //  pageContext.putParameter("paramLinesDepartmentId", pageContext.getParameter("LinesDepartmentId"));
      //}
      //if(pageContext.getParameter("LinesAccountCodeId") != null &&
      //   pageContext.getParameter("LinesAccountCodeId") != "")
      //{
      //  pageContext.putParameter("paramLinesAccountCodeId", pageContext.getParameter("LinesAccountCodeId"));
      //}
      //if (searchShowItem.isDisclosed(pageContext) == true)
      //{
      //  pageContext.putParameter("searchShow", "true");
      //}
      //else
      //{
      //  pageContext.putParameter("searchShow", "false");
      //}
      //if (detailShowItem.isDisclosed(pageContext) == true)
      //{
      //  pageContext.putParameter("paramDetailShow", "true");
      //}
      //else
      //{
      //  pageContext.putParameter("paramDetailShow", "false");
      //}
      //Ver11.5.10.1.6 Change End
      
      String receivableId = pageContext.getParameter("receivableId");

      pageContext.putParameter("receivableId", receivableId);
      pageContext.putParameter("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
      pageContext.putParameter("funcButton", Xx03ArCommonUtil.FUNC_NAME_CONFIRM);
      pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_CONFIRM,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                false,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    //------------------------------------------------------------------------
    // �폜�{�^��������
    else if (pageContext.getParameter("datadelete") != null)
//    else if (pageContext.getParameter(EVENT_PARAM).equals("Delete"))
    {
      String receivableId   = pageContext.getParameter("receivableId");
      String receivableNum  = pageContext.getParameter("receivableNum");

      pageContext.putParameter("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
      pageContext.putParameter("transaction",    "deleteConfirm");
      pageContext.putParameter("receivableId",   receivableId);
      pageContext.putParameter("receivableNum",  receivableNum);
      pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_SEARCH,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    //------------------------------------------------------------------------
    // �폜�F�͂��{�^��������
    else if (pageContext.getParameter("DeleteYesBtn") != null)
    {
      String receivableId   = pageContext.getParameter("delReceivableId");
      String receivableNum  = pageContext.getParameter("delReceivableNum");

      pageContext.putParameter("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
      pageContext.putParameter("transaction", "deleteOK");
      pageContext.putParameter("receivableId", receivableId);
      pageContext.putParameter("receivableNum", receivableNum);
      pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_SEARCH,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    //------------------------------------------------------------------------
    // �폜�F�������{�^��������
    else if (pageContext.getParameter("DeleteNoBtn") != null)
    {
      pageContext.putParameter("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
      pageContext.putParameter("transaction", "deleteNG");
      pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_SEARCH,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    //------------------------------------------------------------------------
    // �N���A�{�^��������
    else if (pageContext.getParameter("ClearBtn") != null)
    {
      pageContext.putParameter("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
      pageContext.putParameter("transaction", "");
      pageContext.setForwardURL(Xx03ArCommonUtil.WINDOW_URL_SEARCH,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
  }

  /**
   * �S���\��
   */
  private void dispAll(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(true);              // ���b�Z�[�W
    conditionRN.setRendered(true);          // ��������
    searchBtnRN.setRendered(true);          // �����{�^��
    separator1.setRendered(true);           // �Z�p���[�^
    spacer1.setRendered(true);              // �X�y�[�X
    resultRN.setRendered(true);             // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(true);     // ���ʁi���F�p�j
    approveConfirmRN.setRendered(true);     // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(true);         // �폜�m�F�{�^��
    massApprovalRN.setRendered(true);       // �ꊇ���F�{�^��
  }

  /**
   * �S����\��
   */
  private void unDispAll(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(false);             // ���b�Z�[�W
    conditionRN.setRendered(false);         // ��������
    searchBtnRN.setRendered(false);         // �����{�^��
    separator1.setRendered(false);          // �Z�p���[�^
    spacer1.setRendered(false);             // �X�y�[�X
    resultRN.setRendered(false);            // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(false);    // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(false);      // �ꊇ���F�{�^��
  }
  
  /**
   * ������\���i�o���ȊO�j
   */
  private void search(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(false);             // ���b�Z�[�W
    conditionRN.setRendered(true);          // ��������
    searchBtnRN.setRendered(true);          // �����{�^��
    separator1.setRendered(true);           // �Z�p���[�^
    spacer1.setRendered(true);              // �X�y�[�X
    resultRN.setRendered(true);             // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(false);    // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(false);      // �ꊇ���F�{�^��
  }

  /**
   * ������\���i�o�����F�p�j
   */
  private void approveSearch(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(false);             // ���b�Z�[�W
    conditionRN.setRendered(true);          // ��������
    searchBtnRN.setRendered(true);          // �����{�^��
    separator1.setRendered(true);           // �Z�p���[�^
    spacer1.setRendered(true);              // �X�y�[�X
    resultRN.setRendered(false);            // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(true);     // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(false);      // �ꊇ���F�{�^��
  }
  
  /**
   * ���ʕ\���i�o���ȊO�j
   */
  private void result(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(false);             // ���b�Z�[�W
    conditionRN.setRendered(true);          // ��������
    searchBtnRN.setRendered(true);          // �����{�^��
    separator1.setRendered(true);           // �Z�p���[�^
    spacer1.setRendered(true);              // �X�y�[�X
    resultRN.setRendered(true);             // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(false);    // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(false);      // �ꊇ���F�{�^��
  }
  /**
   * ���ʕ\���i�o�����F�p�j
   */
  private void approveResult(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(false);             // ���b�Z�[�W
    conditionRN.setRendered(true);          // ��������
    searchBtnRN.setRendered(true);          // �����{�^��
    separator1.setRendered(true);           // �Z�p���[�^
    spacer1.setRendered(true);              // �X�y�[�X
    resultRN.setRendered(false);            // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(true);     // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(true);       // �ꊇ���F�{�^��
  }
  
  /**
   * �폜�m�F
   */
  private void deleteConfirm(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(true);              // ���b�Z�[�W
    conditionRN.setRendered(false);         // ��������
    searchBtnRN.setRendered(false);         // �����{�^��
    separator1.setRendered(false);          // �Z�p���[�^
    spacer1.setRendered(false);             // �X�y�[�X
    resultRN.setRendered(false);            // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(false);    // ���ʁi���F�p�j
    approveConfirmRN.setRendered(false);    // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(true);         // �폜�m�F�{�^��
    massApprovalRN.setRendered(false);      // �ꊇ���F�{�^��
  }

  /**
   * ���F�m�F
   */
  private void approveConfirm(OAWebBean webBean)
  {
    OARawTextBean                message          = (OARawTextBean)webBean.findChildRecursive("message");                     // ���b�Z�[�W
    OAMessageComponentLayoutBean conditionRN      = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");  // ��������
    OAFlowLayoutBean             searchBtnRN      = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");              // �����{�^��
    OASeparatorBean              separator1       = (OASeparatorBean)webBean.findChildRecursive("separator1");                // �Z�p���[�^
    OASpacerBean                 spacer1          = (OASpacerBean)webBean.findChildRecursive("spacer1");                      // �X�y�[�X
    OATableBean                  resultRN         = (OATableBean)webBean.findChildRecursive("ResultRN");                      // ���ʁi���[�U�[�����p�j
    OATableBean                  approverResultRN = (OATableBean)webBean.findChildRecursive("ApproverResultRN");              // ���ʁi���F�p�j
    OATableBean                  approveConfirmRN = (OATableBean)webBean.findChildRecursive("ApproveConfirmRN");              // ���ʁi���F�m�F�p�j
    OAFlowLayoutBean             delConfirmRN     = (OAFlowLayoutBean)webBean.findChildRecursive("DeleteConfirmRN");          // �폜�m�F�{�^��
    OAFlowLayoutBean             massApprovalRN   = (OAFlowLayoutBean)webBean.findChildRecursive("MassApprovalRN");           // �ꊇ���F�{�^��

    message.setRendered(true);              // ���b�Z�[�W
    conditionRN.setRendered(false);         // ��������
    searchBtnRN.setRendered(false);         // �����{�^��
    separator1.setRendered(false);          // �Z�p���[�^
    spacer1.setRendered(false);             // �X�y�[�X
    resultRN.setRendered(false);            // ���ʁi���[�U�[�����p�j
    approverResultRN.setRendered(false);    // ���ʁi���F�p�j
    approveConfirmRN.setRendered(true);     // ���ʁi���F�m�F�p�j
    delConfirmRN.setRendered(false);        // �폜�m�F�{�^��
    massApprovalRN.setRendered(true);       // �ꊇ���F�{�^��
  }
  /**
   * ���������Z�b�g����
   * @param  pageContext OAPageContext
   * @param  webBean     OAWebBean
   */
  private void setSearchItem(OAPageContext pageContext, OAWebBean webBean)
  {
    // Application Module �C���X�^���X
    OAApplicationModule am = pageContext.getRootApplicationModule();

    // ���������A�C�e��Bean�쐬
    OAMessageLovInputBean  oaEntryDepartment  = (OAMessageLovInputBean)webBean.findChildRecursive("EntryDepartment");
    OAMessageLovInputBean  oaEntryPersonName  = (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
    OAMessageChoiceBean    oaWfStatus         = (OAMessageChoiceBean)webBean.findChildRecursive("WfStatus");
    OAMessageLovInputBean  oaSlipType         = (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
    // ver1.2 add start ---------------------------------------------------------
    OAFormValueBean        oaSlipTypeId       = (OAFormValueBean)webBean.findChildRecursive("SlipTypeCodeId");
    // ver1.2 add end ----------------------------------------------------------- */ 
    OAMessageTextInputBean oaReceivableNum    = (OAMessageTextInputBean)webBean.findChildRecursive("ReceivableNum");
    OAMessageLovInputBean  oaApprover         = (OAMessageLovInputBean)webBean.findChildRecursive("Approver");
    // ver1.2 add start ---------------------------------------------------------
    OAFormValueBean        oaApproverId       = (OAFormValueBean)webBean.findChildRecursive("ApproverPersonId");
    // ver1.2 add end -----------------------------------------------------------

    OAMessageLovInputBean  oaCustomerName     = (OAMessageLovInputBean)webBean.findChildRecursive("CustomerName");
    OAMessageDateFieldBean oaInvoiceDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateStart");
    OAMessageDateFieldBean oaInvoiceDateEnd   = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateEnd");
    OAMessageDateFieldBean oaEntryDateStart   = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateStart");
    OAMessageDateFieldBean oaEntryDateEnd     = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateEnd");

    OAMessageDateFieldBean oaGlDateStart      = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
    OAMessageDateFieldBean oaGlDateEnd        = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
    OAMessageDateFieldBean oaPaymentScheduledDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("PaymentScheduledDateStart");
    OAMessageDateFieldBean oaPaymentScheduledDateEnd   = (OAMessageDateFieldBean)webBean.findChildRecursive("PaymentScheduledDateEnd");

    OAMessageLovInputBean  oaReceiptMethodName = (OAMessageLovInputBean)webBean.findChildRecursive("ReceiptMethodName");
    OAMessageLovInputBean  oaLinesDepartment   = (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
    OAMessageLovInputBean  oaLinesAccountCode  = (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
    OAMessageTextInputBean oaReconReference    = (OAMessageTextInputBean)webBean.findChildRecursive("ReconReference");

    OADefaultHideShowBean  searchShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DefaultSearchRN");
    OADefaultHideShowBean  detailShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DetailSearchRN");

    OAFormValueBean        oaEntryDepartmentId = (OAFormValueBean)webBean.findChildRecursive("EntryDepartmentId");
    OAFormValueBean        oaEntryPersonId     = (OAFormValueBean)webBean.findChildRecursive("EntryPersonId");
    OAFormValueBean        oaApproverPersonId  = (OAFormValueBean)webBean.findChildRecursive("ApproverPersonId");
    OAFormValueBean        oaSlipTypeCodeId    = (OAFormValueBean)webBean.findChildRecursive("SlipTypeCodeId");

    OAFormValueBean        oaCustomerId      = (OAFormValueBean)webBean.findChildRecursive("CustomerId");
    OAFormValueBean        oaReceiptMethodId = (OAFormValueBean)webBean.findChildRecursive("ReceiptMethodId");

    OAFormValueBean        oaLinesDepartmentId  = (OAFormValueBean)webBean.findChildRecursive("LinesDepartmentId");
    OAFormValueBean        oaLinesAccountCodeId = (OAFormValueBean)webBean.findChildRecursive("LinesAccountCodeId");

    //Ver11.5.10.1.6 Change Start
    // �������ʑJ�ڂŌ���������ێ����Ă����Ȃ��Ă͂Ȃ�Ȃ��Ȃ������߁A
    // ���������̕ۑ����TransientSessionValue�ɕύX�B
    // �A�C�e����Row�ɒl��ݒ�
    // �N�[����
    if (pageContext.getTransientSessionValue("paramEntryDepartment") != null)
    {
      oaEntryDepartment.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramEntryDepartment").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDepartment",(String)pageContext.getTransientSessionValue("paramEntryDepartment")});
      pageContext.removeTransientSessionValue("paramEntryDepartment");
    }
    // �`�[���͎�
    if (pageContext.getTransientSessionValue("paramEntryPersonName") != null)
    {
      oaEntryPersonName.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramEntryPersonName").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryPersonName",(String)pageContext.getTransientSessionValue("paramEntryPersonName")});
      pageContext.removeTransientSessionValue("paramEntryPersonName");
    }
    // �X�e�[�^�X
    if (pageContext.getTransientSessionValue("paramWfStatus") != null)
    {
      oaWfStatus.setDefaultValue(pageContext.getTransientSessionValue("paramWfStatus").toString());
      am.invokeMethod("insertValue",new Serializable[]{"wfStatus",(String)pageContext.getTransientSessionValue("paramWfStatus")});
      pageContext.removeTransientSessionValue("paramWfStatus");
    }
    // �`�[���
    if (pageContext.getTransientSessionValue("paramSlipType") != null)
    {
      oaSlipType.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramSlipType").toString());
      am.invokeMethod("insertValue",new Serializable[]{"slipTypeName",(String)pageContext.getTransientSessionValue("paramSlipType")});
      pageContext.removeTransientSessionValue("paramSlipType");
    }
    // �`�[���ID
    if (pageContext.getTransientSessionValue("paramSlipTypeId") != null)
    {
      oaSlipTypeId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramSlipTypeId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"slipType",(String)pageContext.getTransientSessionValue("paramSlipTypeId")});
      pageContext.removeTransientSessionValue("paramSlipTypeId");
    }
    // �`�[�ԍ�
    if (pageContext.getTransientSessionValue("paramReceivableNum") != null)
    {
      oaReceivableNum.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramReceivableNum").toString());
      am.invokeMethod("insertValue",new Serializable[]{"receivableNum",(String)pageContext.getTransientSessionValue("paramReceivableNum")});
      pageContext.removeTransientSessionValue("paramReceivableNum");
    }
    // ���F��
    if (pageContext.getTransientSessionValue("paramApprover") != null)
    {
      oaApprover.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramApprover").toString());
      am.invokeMethod("insertValue",new Serializable[]{"approver",(String)pageContext.getTransientSessionValue("paramApprover")});
      pageContext.removeTransientSessionValue("paramApprover");
    }
    // ���F��ID
    if (pageContext.getTransientSessionValue("paramApproverId") != null)
    {
      oaApproverId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramApproverId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"approverId",(String)pageContext.getTransientSessionValue("paramApproverId")});
      pageContext.removeTransientSessionValue("paramApproverId");
    }
    // �ڋq
    if (pageContext.getTransientSessionValue("paramCustomerName") != null)
    {
      oaCustomerName.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramCustomerName").toString());
      am.invokeMethod("insertValue",new Serializable[]{"customerName",(String)pageContext.getTransientSessionValue("paramCustomerName")});
      pageContext.removeTransientSessionValue("paramCustomerName");
    }
    // ���������t�i���j
    if (pageContext.getTransientSessionValue("paramInvoiceDateStart") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramInvoiceDateStart"));
      oaInvoiceDateStart.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"invoiceDateStart",newDate.toString()});
      pageContext.removeTransientSessionValue("paramInvoiceDateStart");
    }
    // ���������t�i���j
    if (pageContext.getTransientSessionValue("paramInvoiceDateEnd") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramInvoiceDateEnd"));
      oaInvoiceDateEnd.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"invoiceDateEnd",newDate.toString()});
      pageContext.removeTransientSessionValue("paramInvoiceDateEnd");
    }
    // �N�[���i���j
    if (pageContext.getTransientSessionValue("paramEntryDateStart") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramEntryDateStart"));
      oaEntryDateStart.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"entryDateStart",newDate.toString()});
      pageContext.removeTransientSessionValue("paramEntryDateStart");
    }
    // �N�[���i���j
    if (pageContext.getTransientSessionValue("paramEntryDateEnd") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramEntryDateEnd"));
      oaEntryDateEnd.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"entryDateEnd",newDate.toString()});
      pageContext.removeTransientSessionValue("paramEntryDateEnd");
    }
    // �v����i���j
    if (pageContext.getTransientSessionValue("paramGlDateStart") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramGlDateStart"));
      oaGlDateStart.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"glDateStart",newDate.toString()});
      pageContext.removeTransientSessionValue("paramGlDateStart");
    }
    // �v����i���j
    if (pageContext.getTransientSessionValue("paramGlDateEnd") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramGlDateEnd"));
      oaGlDateEnd.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"glDateEnd",newDate.toString()});
      pageContext.removeTransientSessionValue("paramGlDateEnd");
    }
    // �����\����i���j
    if (pageContext.getTransientSessionValue("paramPaymentScheduledDateStart") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramPaymentScheduledDateStart"));
      oaPaymentScheduledDateStart.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"paymentScheduledDateStart",newDate.toString()});
      pageContext.removeTransientSessionValue("paramPaymentScheduledDateStart");
    }
    // �����\����i���j
    if (pageContext.getTransientSessionValue("paramPaymentScheduledDateEnd") != null)
    {
      Date newDate=new Date((java.sql.Date)pageContext.getTransientSessionValue("paramPaymentScheduledDateEnd"));
      oaPaymentScheduledDateEnd.setValue(pageContext, newDate);
      am.invokeMethod("insertValue",new Serializable[]{"paymentScheduledDateEnd",newDate.toString()});
      pageContext.removeTransientSessionValue("paramPaymentScheduledDateEnd");
    }

    // �x�����@
    if (pageContext.getTransientSessionValue("paramReceiptMethod") != null)
    {
      oaReceiptMethodName.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramReceiptMethod").toString());
      am.invokeMethod("insertValue",new Serializable[]{"receiptMethodName",(String)pageContext.getTransientSessionValue("paramReceiptMethod")});
      pageContext.removeTransientSessionValue("paramReceiptMethod");
    }
    // �x�����@ID
    if (pageContext.getTransientSessionValue("paramReceiptMethodId") != null)
    {
      oaReceiptMethodId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramReceiptMethodId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"receiptMethodId",(String)pageContext.getTransientSessionValue("paramReceiptMethodId")});
      pageContext.removeTransientSessionValue("paramReceiptMethodId");
    }
    // ���ׁF����
    if (pageContext.getTransientSessionValue("paramLinesDepartment") != null)
    {
      oaLinesDepartment.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramLinesDepartment").toString());
      am.invokeMethod("insertValue",new Serializable[]{"linesDepartment",(String)pageContext.getTransientSessionValue("paramLinesDepartment")});
      pageContext.removeTransientSessionValue("paramLinesDepartment");
    }
    // ���ׁF����Ȗ�
    if (pageContext.getTransientSessionValue("paramLinesAccountCode") != null)
    {
      oaLinesAccountCode.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramLinesAccountCode").toString());
      am.invokeMethod("insertValue",new Serializable[]{"linesAccountCode",(String)pageContext.getTransientSessionValue("paramLinesAccountCode")});
      pageContext.removeTransientSessionValue("paramLinesAccountCode");
    }
    // ���ׁF����Ȗ�ID
    if (pageContext.getTransientSessionValue("paramLinesAccountCodeId") != null)
    {
      oaLinesAccountCodeId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramLinesAccountCodeId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"lineAccountCodeId",(String)pageContext.getTransientSessionValue("paramLinesAccountCodeId")});
      pageContext.removeTransientSessionValue("paramLinesAccountCodeId");
    }
    // ���ׁF�����Q��
    if (pageContext.getTransientSessionValue("paramReconReference") != null)
    {
      oaReconReference.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramReconReference").toString());
      am.invokeMethod("insertValue",new Serializable[]{"reconReference",(String)pageContext.getTransientSessionValue("paramReconReference")});
      pageContext.removeTransientSessionValue("paramReconReference");
    }
    // �N�[����ID
    if (pageContext.getTransientSessionValue("paramEntryDepartmentId") != null)
    {
      oaEntryDepartmentId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramEntryDepartmentId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDepartmentId",(String)pageContext.getTransientSessionValue("paramEntryDepartmentId")});
      pageContext.removeTransientSessionValue("paramEntryDepartmentId");
    }
    // �`�[���ID
    if (pageContext.getTransientSessionValue("paramSlipTypeCodeID") != null)
    {
      oaSlipTypeCodeId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramSlipTypeCodeId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"slipTypeCodeID",(String)pageContext.getTransientSessionValue("paramSlipTypeCodeId")});
      pageContext.removeTransientSessionValue("paramSlipTypeCodeID");
    }
    // ���F��ID
    if (pageContext.getTransientSessionValue("paramApproverPersonId") != null)
    {
      oaApproverPersonId.setValue(pageContext, new Integer((String)pageContext.getTransientSessionValue("paramApproverPersonId")));
      am.invokeMethod("insertValue",new Serializable[]{"approverPersonId",(String)pageContext.getTransientSessionValue("paramApproverPersonId")});
      pageContext.removeTransientSessionValue("paramApproverPersonId");
    }
    // �ڋqID
    if (pageContext.getTransientSessionValue("paramCustomerId") != null)
    {
      oaCustomerId.setValue(pageContext, new Integer((String)pageContext.getTransientSessionValue("paramCustomerId")));
      am.invokeMethod("insertValue",new Serializable[]{"customerId",(String)pageContext.getTransientSessionValue("paramCustomerId")});
      pageContext.removeTransientSessionValue("paramCustomerId");
    }
    // �`�[���͎�ID
    if (pageContext.getTransientSessionValue("paramEntryPersonId") != null)
    {
     oaEntryPersonId.setValue(pageContext, new Integer((String)pageContext.getTransientSessionValue("paramEntryPersonId")));
     am.invokeMethod("insertValue",new Serializable[]{"entryPersonId",(String)pageContext.getTransientSessionValue("paramEntryPersonId")});
      pageContext.removeTransientSessionValue("paramEntryPersonId");
    }
    // ���ׁF����ID
    if (pageContext.getTransientSessionValue("paramLinesDepartmentId") != null)
    {
      oaLinesDepartmentId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramLinesDepartmentId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"linesDepartmentId",(String)pageContext.getTransientSessionValue("paramLinesDepartmentId")});
      pageContext.removeTransientSessionValue("paramLinesDepartmentId");
    }
    // ���ׁF����Ȗ�ID
    if (pageContext.getTransientSessionValue("paramLinesAccountCodeId") != null)
    {
      oaLinesAccountCodeId.setValue(pageContext,(String)pageContext.getTransientSessionValue("paramLinesAccountCodeId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"linesAccountCodeId",(String)pageContext.getTransientSessionValue("paramLinesAccountCodeId")});
      pageContext.removeTransientSessionValue("paramLinesAccountCodeId");
    }


    //if (pageContext.getParameter("paramEntryDepartment") != null)
    //{
    //  oaEntryDepartment.setValue(pageContext, pageContext.getParameter("paramEntryDepartment").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"entryDepartment",pageContext.getParameter("paramEntryDepartment")});
    //  pageContext.removeParameter("paramEntryDepartment");
    //}
    //// �`�[���͎�
    //if (pageContext.getParameter("paramEntryPersonName") != null)
    //{
    //  oaEntryPersonName.setValue(pageContext, pageContext.getParameter("paramEntryPersonName").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"entryPersonName",pageContext.getParameter("paramEntryPersonName")});
    //  pageContext.removeParameter("paramEntryPersonName");
    //}
    //// �X�e�[�^�X
    //if (pageContext.getParameter("paramWfStatus") != null)
    //{
    //  oaWfStatus.setDefaultValue(pageContext.getParameter("paramWfStatus").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"wfStatus",pageContext.getParameter("paramWfStatus")});
    //  pageContext.removeParameter("paramWfStatus");
    //}
    //// �`�[���
    //if (pageContext.getParameter("paramSlipType") != null)
    //{
    //  oaSlipType.setValue(pageContext, pageContext.getParameter("paramSlipType").toString());
    //// ver1.2 change start ------------------------------------------------------
    ////    am.invokeMethod("insertValue",new Serializable[]{"slipTypeKind",pageContext.getParameter("paramSlipType")});
    //  am.invokeMethod("insertValue",new Serializable[]{"slipTypeName",pageContext.getParameter("paramSlipType")});
    //  pageContext.removeParameter("paramSlipType");
    //// ver1.2 change end --------------------------------------------------------
    //}
    //// ver1.2 add start ---------------------------------------------------------
    //// �`�[���ID
    //if (pageContext.getParameter("paramSlipTypeId") != null)
    //{
    //  oaSlipTypeId.setValue(pageContext, pageContext.getParameter("paramSlipTypeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"slipType",pageContext.getParameter("paramSlipTypeId")});
    //  pageContext.removeParameter("paramSlipTypeId");
    //}
    //// ver1.2 add end -----------------------------------------------------------

    //// �`�[�ԍ�
    //if (pageContext.getParameter("paramReceivableNum") != null)
    //{
    //  oaReceivableNum.setValue(pageContext, pageContext.getParameter("paramReceivableNum").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"receivableNum",pageContext.getParameter("paramReceivableNum")});
    //  pageContext.removeParameter("paramReceivableNum");
    //}
    // ���F��
    //if (pageContext.getParameter("paramApprover") != null)
    //{
    //  oaApprover.setValue(pageContext, pageContext.getParameter("paramApprover").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"approver",pageContext.getParameter("paramApprover")});
    //  pageContext.removeParameter("paramApprover");
    //}
    //// ver1.2 add start ---------------------------------------------------------
    //// ���F��ID
    //if (pageContext.getParameter("paramApproverId") != null)
    //{
    //  oaApproverId.setValue(pageContext, pageContext.getParameter("paramApproverId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"approverId",pageContext.getParameter("paramApproverId")});
    //  pageContext.removeParameter("paramApproverId");
    //}
    //// ver1.2 add end -----------------------------------------------------------
    //// �ڋq
    //if (pageContext.getParameter("paramCustomerName") != null)
    //{
    //  oaCustomerName.setValue(pageContext, pageContext.getParameter("paramCustomerName").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"customerName",pageContext.getParameter("paramCustomerName")});
    //  pageContext.removeParameter("paramCustomerName");
    //}
    //// ���������t�i���j
    //if (pageContext.getParameter("paramInvoiceDateStart") != null)
    //{
    //  oaInvoiceDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramInvoiceDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"invoiceDateStart",pageContext.getParameter("paramInvoiceDateStart")});
    //  pageContext.removeParameter("paramInvoiceDateStart");
    //}
    //// ���������t�i���j
    //if (pageContext.getParameter("paramInvoiceDateEnd") != null)
    //{
    //  oaInvoiceDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramInvoiceDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"invoiceDateEnd",pageContext.getParameter("paramInvoiceDateEnd")});
    //  pageContext.removeParameter("paramInvoiceDateEnd");
    //}
    //// �N�[���i���j
    //if (pageContext.getParameter("paramEntryDateStart") != null)
    //{
    //  oaEntryDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramEntryDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"entryDateStart",pageContext.getParameter("paramEntryDateStart")});
    //  pageContext.removeParameter("paramEntryDateStart");
    //}
    //// �N�[���i���j
    //if (pageContext.getParameter("paramEntryDateEnd") != null)
    //{
    //  oaEntryDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramEntryDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"entryDateEnd",pageContext.getParameter("paramEntryDateEnd")});
    //  pageContext.removeParameter("paramEntryDateEnd");
    //}

    //// �v����i���j
    //if (pageContext.getParameter("paramGlDateStart") != null)
    //{
    //  oaGlDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramGlDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"glDateStart",pageContext.getParameter("paramGlDateStart")});
    //  pageContext.removeParameter("paramGlDateStart");
    //}
    //// �v����i���j
    //if (pageContext.getParameter("paramGlDateEnd") != null)
    //{
    //  oaGlDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramGlDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"glDateEnd",pageContext.getParameter("paramGlDateEnd")});
    //  pageContext.removeParameter("paramGlDateEnd");
    //}
    //// �����\����i���j
    //if (pageContext.getParameter("paramPaymentScheduledDateStart") != null)
    //{
    //  //Ver11.5.10.1.5 2005/09/07 Change Start
    //  //oaGlDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramPaymentScheduledDateStart")).toString());
    //  oaPaymentScheduledDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramPaymentScheduledDateStart")).toString());
    //  //Ver11.5.10.1.5 2005/09/07 Change End
    //  am.invokeMethod("insertValue",new Serializable[]{"paymentScheduledDateStart",pageContext.getParameter("paramPaymentScheduledDateStart")});
    //  pageContext.removeParameter("paramPaymentScheduledDateStart");
    //}
    //// �����\����i���j
    //if (pageContext.getParameter("paramPaymentScheduledDateEnd") != null)
    //{
    //  oaPaymentScheduledDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramPaymentScheduledDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"paymentScheduledDateEnd",pageContext.getParameter("paramPaymentScheduledDateEnd")});
    //  pageContext.removeParameter("paramPaymentScheduledDateEnd");
    //}

    //// �x�����@
    //if (pageContext.getParameter("paramReceiptMethod") != null)
    //{
    //  oaReceiptMethodName.setValue(pageContext, pageContext.getParameter("paramReceiptMethod").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"receiptMethodName",pageContext.getParameter("paramReceiptMethod")});
    //  pageContext.removeParameter("paramReceiptMethod");
    //}
    //if (pageContext.getParameter("paramReceiptMethodId") != null)
    //{
    //  oaReceiptMethodId.setValue(pageContext, pageContext.getParameter("paramReceiptMethodId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"receiptMethodId",pageContext.getParameter("paramReceiptMethodId")});
    //  pageContext.removeParameter("paramReceiptMethodId");
    //}
    //// ���ׁF����
    //if (pageContext.getParameter("paramLinesDepartment") != null)
    //{
    //  oaLinesDepartment.setValue(pageContext, pageContext.getParameter("paramLinesDepartment").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"linesDepartment",pageContext.getParameter("paramLinesDepartment")});
    //  pageContext.removeParameter("paramLinesDepartment");
    //}
    //// ���ׁF����Ȗ�
    //if (pageContext.getParameter("paramLinesAccountCode") != null)
    //{
    //  oaLinesAccountCode.setValue(pageContext, pageContext.getParameter("paramLinesAccountCode").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"linesAccountCode",pageContext.getParameter("paramLinesAccountCode")});
    //  pageContext.removeParameter("paramLinesAccountCode");
    //}
    //if (pageContext.getParameter("paramLinesAccountCodeId") != null)
    //{
    //  oaLinesAccountCodeId.setValue(pageContext, pageContext.getParameter("paramLinesAccountCodeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"lineAccountCodeId",pageContext.getParameter("paramLinesAccountCodeId")});
    //  pageContext.removeParameter("paramLinesAccountCodeId");
    //}
    //// ���ׁF�����Q��
    //if (pageContext.getParameter("paramReconReference") != null)
    //{
    //  oaReconReference.setValue(pageContext, pageContext.getParameter("paramReconReference").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"reconReference",pageContext.getParameter("paramReconReference")});
    //  pageContext.removeParameter("paramReconReference");
    //}

    //if (pageContext.getParameter("paramEntryDepartmentId") != null)
    //{
    //  oaEntryDepartmentId.setValue(pageContext, pageContext.getParameter("paramEntryDepartmentId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"entryDepartmentId",pageContext.getParameter("paramEntryDepartmentId")});
    //  pageContext.removeParameter("paramEntryDepartmentId");
    //}
    //if (pageContext.getParameter("paramSlipTypeCodeID") != null)
    //{
    //  oaSlipTypeCodeId.setValue(pageContext, pageContext.getParameter("paramSlipTypeCodeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"slipTypeCodeID",pageContext.getParameter("paramSlipTypeCodeId")});
    //  pageContext.removeParameter("paramSlipTypeCodeID");
    //}
    //if (pageContext.getParameter("paramApproverPersonId") != null)
    //{
    //  oaApproverPersonId.setValue(pageContext, new Integer(pageContext.getParameter("paramApproverPersonId")));
    //  am.invokeMethod("insertValue",new Serializable[]{"approverPersonId",pageContext.getParameter("paramApproverPersonId")});
    //  pageContext.removeParameter("paramApproverPersonId");
    //}

    //if (pageContext.getParameter("paramCustomerId") != null)
    //{
    //  oaCustomerId.setValue(pageContext, new Integer(pageContext.getParameter("paramCustomerId")));
    //  am.invokeMethod("insertValue",new Serializable[]{"customerId",pageContext.getParameter("paramCustomerId")});
    //  pageContext.removeParameter("paramCustomerId");
    //}

    //if (pageContext.getParameter("paramEntryPersonId") != null)
    //{
    // oaEntryPersonId.setValue(pageContext, new Integer(pageContext.getParameter("paramEntryPersonId")));
    // am.invokeMethod("insertValue",new Serializable[]{"entryPersonId",pageContext.getParameter("paramEntryPersonId")});
    //  pageContext.removeParameter("paramEntryPersonId");
    //}
    //if (pageContext.getParameter("paramLinesDepartmentId") != null)
    //{
    //  oaLinesDepartmentId.setValue(pageContext, pageContext.getParameter("paramLinesDepartmentId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"linesDepartmentId",pageContext.getParameter("paramLinesDepartmentId")});
    //  pageContext.removeParameter("paramLinesDepartmentId");
    //}
    //if (pageContext.getParameter("paramLinesAccountCodeId") != null)
    //{
    //  oaLinesAccountCodeId.setValue(pageContext, pageContext.getParameter("paramLinesAccountCodeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"linesAccountCodeId",pageContext.getParameter("paramLinesAccountCodeId")});
    //  pageContext.removeParameter("paramLinesAccountCodeId");
    //}
    //Ver11.5.10.1.6 Change End
  }

  //Ver11.5.10.1.6 Add Start
  /**
   * �Z�b�V�����ɕۑ����������������N���A����B
   * @param pageContext �y�[�W�R���e�L�X�g
   */
  private void removeSearchItem(OAPageContext pageContext) 
  {
    pageContext.removeTransientSessionValue("paramEntryDepartment");
    pageContext.removeTransientSessionValue("paramEntryPersonName");
    pageContext.removeTransientSessionValue("paramWfStatus");
    pageContext.removeTransientSessionValue("paramSlipType");
    pageContext.removeTransientSessionValue("paramSlipTypeId");
    pageContext.removeTransientSessionValue("paramReceivableNum");
    pageContext.removeTransientSessionValue("paramApprover");
    pageContext.removeTransientSessionValue("paramApproverId");
    pageContext.removeTransientSessionValue("paramCustomerName");
    pageContext.removeTransientSessionValue("paramInvoiceDateStart");
    pageContext.removeTransientSessionValue("paramInvoiceDateEnd");
    pageContext.removeTransientSessionValue("paramEntryDateStart");
    pageContext.removeTransientSessionValue("paramEntryDateEnd");
    pageContext.removeTransientSessionValue("paramGlDateStart");
    pageContext.removeTransientSessionValue("paramGlDateEnd");
    pageContext.removeTransientSessionValue("paramPaymentScheduledDateStart");
    pageContext.removeTransientSessionValue("paramPaymentScheduledDateEnd");
    pageContext.removeTransientSessionValue("paramReceiptMethod");
    pageContext.removeTransientSessionValue("paramReceiptMethodId");
    pageContext.removeTransientSessionValue("paramLinesDepartment");
    pageContext.removeTransientSessionValue("paramLinesAccountCode");
    pageContext.removeTransientSessionValue("paramLinesAccountCodeId");
    pageContext.removeTransientSessionValue("paramReconReference");
    pageContext.removeTransientSessionValue("paramEntryDepartmentId");
    pageContext.removeTransientSessionValue("paramSlipTypeCodeID");
    pageContext.removeTransientSessionValue("paramApproverPersonId");
    pageContext.removeTransientSessionValue("paramCustomerId");
    pageContext.removeTransientSessionValue("paramEntryPersonId");
    pageContext.removeTransientSessionValue("paramLinesDepartmentId");
    pageContext.removeTransientSessionValue("paramLinesAccountCodeId");
    pageContext.removeTransientSessionValue("searchShow");
    pageContext.removeTransientSessionValue("paramDetailShow");
  }
  //Ver11.5.10.1.6 Add End
}
