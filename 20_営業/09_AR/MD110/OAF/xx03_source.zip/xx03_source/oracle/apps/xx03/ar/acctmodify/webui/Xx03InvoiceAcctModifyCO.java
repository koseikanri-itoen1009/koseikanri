/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005. All rights reserved.
 * FILENAME     Xx03InvoiceAcctModifyCO.java
 * VERSION      11.5.10.1.6D
 * DATE         2006/02/16
 * HISTORY      2004/12/01  Ver1.0          �V�K�쐬
 *              2005/02/24  Ver1.1          �d�l�ύX�Ή��g��
 *              2005/07/11  Ver11.5.10.1.4  ����ł݂̂̌v�オ���{�ł���悤�ɏC��
 *              2005/11/11  Ver11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�
 *              2006/01/30  Ver11.5.10.1.6B �`�[��ʂ̕\���e�L�X�g�擾�@�C��
 *              2006/02/02  Ver11.5.10.1.6C �{�^���̃_�u���N���b�N�Ή�
 *              2006/02/16  Ver11.5.10.1.6D �قȂ�^�u�ŃG���[�������A�J�ڂł��Ȃ��Ή�
 *===========================================================================*/
package oracle.apps.xx03.ar.acctmodify.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import java.util.ArrayList;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASubTabLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.table.OAAdvancedTableBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;

import oracle.bali.share.util.BooleanUtils;

import oracle.jbo.domain.Number;

/**
 *
 * Xx03ReceivableAcctModifyPG�̃R���g���[��
 *
 * @version     11.5.10.1.6D
 */
public class Xx03InvoiceAcctModifyCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    // �A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    // �߂�{�^���ɂ����s�̏ꍇ
    if (pageContext.isBackNavigationFired(false))
    {
      am.invokeMethod("rollback");

      //ver11.5.10.1.6C Chg Start
      //OADialogPage dialogPage = new OADialogPage(STATE_LOSS_ERROR);
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );
      //ver11.5.10.1.6C Chg End

      pageContext.redirectToDialogPage(dialogPage);
    }
    // �߂�{�^���ɂ����s�łȂ��ꍇ
    else
    {
      try{
        //
        //************************************************************************
        // ���ʏ���
        //************************************************************************
        //
        // �p�����[�^�擾
        String pageStatus = pageContext.getParameter("pageStatus");
        String funcButton = pageContext.getParameter("funcButton");

        if (pageStatus == null)
        {
          pageStatus = Xx03ArCommonUtil.WINDOW_NAME_MENU;
        }
        
        // ���ו\�������̎擾
        OAAdvancedTableBean invoiceLinesDetail = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesDetailRN");
        OAAdvancedTableBean invoiceLinesJournal = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesJournalRN");
        Integer invoiceLinesDetailCnt = new Integer(invoiceLinesDetail.getNumberOfRowsDisplayed());
        Integer invoiceLinesJournalCnt = new Integer(invoiceLinesJournal.getNumberOfRowsDisplayed());
        Boolean forceFlag = BooleanUtils.getBoolean(false);

        // �^�u�������̌��؏����𖳌���
        OASubTabLayoutBean slipLine = (OASubTabLayoutBean)webBean.findChildRecursive("InvoiceLineRN");
        slipLine.setUnvalidated(true);
        //ver11.5.10.1.6D Add Start
        slipLine.setServerUnvalidated(true);
        //ver11.5.10.1.6D Add End

        // �O����t���O
        String strPrePayFlag = null;

        //**********************************************************************
        // �^�u
        //**********************************************************************
        // �^�u�ؑ֎��́A������
        if (Xx03ArCommonUtil.STR_YES.equals(pageContext.getTransactionValue("tab")))
        {
          pageContext.removeTransactionValue("tab");

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
        }
        //**********************************************************************
        // �m�F��ʂ���J��(�C��)
        //**********************************************************************
        else if ((Xx03ArCommonUtil.WINDOW_NAME_CONFIRM.equals(pageStatus)) &&
                  (Xx03ArCommonUtil.FUNC_NAME_MODIFY.equals(funcButton)))
        {
          //ver11.5.10.1.6 Chg Start
          // AM�������ŁAretainAM���Ă���ꍇ�A
          // createRow�������_�ŁA�Y��Row��ViewObject�̃J�����g�s�ɂȂ邽��
          // ��������K�v���Ȃ��B

          // �ύX�iretainAM FALSE�j
          // �`�[����
          Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
          Boolean executeQuery = BooleanUtils.getBoolean(true);
          Serializable[] methodParams = {receivableId, executeQuery};
          Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
          am.invokeMethod("initReceivableSlips", methodParams, methodParamTypes);
          //ver11.5.10.1.6 Chg End

          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          invoiceLinesDetail.queryData(pageContext, true);

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
        }
        //**********************************************************************
        // �ꌩ�ڋq���́A�O�����ʂ���J��
        //**********************************************************************
        else if ((Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER.equals(pageStatus))
                  || (Xx03ArCommonUtil.WINDOW_NAME_PREPAY.equals(pageStatus)))
        {
          // �`�[����
          Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
          Boolean executeQuery = BooleanUtils.getBoolean(true);
          Serializable[] methodParams = {receivableId, executeQuery};
          Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
          am.invokeMethod("initReceivableSlips", methodParams, methodParamTypes);

          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          invoiceLinesDetail.queryData(pageContext, true);
          invoiceLinesJournal.queryData(pageContext, true);

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
          
          // ��`�[���׃f�[�^�쐬
          Number detailCount = null;
          if (strPrePayFlag.equals("Y"))
          {
            // �O����̏ꍇ�͎d��P�s�̂�
            detailCount = new Number(1);
          }
          else
          {
            // ���̑��͖��אݒ�s��
            detailCount = new Number(invoiceLinesDetailCnt.intValue());
          }
          methodParams = new Serializable[]{detailCount};
          methodParamTypes = new Class[]{detailCount.getClass()};
          am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes);
        }

        //**********************************************************************
        // ���ʏ���
        //**********************************************************************
        // �`�[��ʂ̕\���e�L�X�g�ύX
        OAHeaderBean slipHeaderTitleBean = (OAHeaderBean)webBean.findIndexedChildRecursive("SlipHeaderTitleRN");
        //Ver11.5.10.1.6B Change Start
        //slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
        //  new OADataBoundValueViewObject(slipHeaderTitleBean, "SlipTypeName", "Xx03ReceivableSlipsVO1"));
        slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
          new OADataBoundValueViewObject(slipHeaderTitleBean, "Description", "Xx03SlipTypesLovVO1"));
        //Ver11.5.10.1.6B Change End

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");

        // �O����{�^���\���ؑ�
        OASubmitButtonBean prePaidMoney = (OASubmitButtonBean)webBean.findChildRecursive("PrePaidMoney");
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        OAMessageLovInputBean segment1Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment1Name1");
        OAMessageLovInputBean segment2Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment2Name1");
        OAMessageLovInputBean segment3Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment3Name1");
        OAMessageLovInputBean segment4Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment4Name1");
        OAMessageLovInputBean segment5Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment5Name1");
        OAMessageLovInputBean segment6Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment6Name1");
        OAMessageLovInputBean segment7Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment7Name1");
        OAMessageLovInputBean segment8Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment8Name1");
        OAMessageLovInputBean incrDecrReasonName1 = (OAMessageLovInputBean)webBean.findChildRecursive("IncrDecrReasonName1");
        OAWebBeanTextInput reconReference1 = (OAWebBeanTextInput)webBean.findChildRecursive("ReconReference1");
           if ((strPrePayFlag != null) && (strPrePayFlag.equals("Y")))
        {          
          // �O���
          prePaidMoney.setDisabled(false);
          slipLine.hideSubTab(0, true);
          commitmentNumber.setRendered(false);

          // AFF���ڕҏW�s��
          segment1Name1.setDisabled(true);
          segment2Name1.setDisabled(true);
          segment3Name1.setDisabled(true);
          segment4Name1.setDisabled(true);
          segment5Name1.setDisabled(true);
          segment6Name1.setDisabled(true);
          segment7Name1.setDisabled(true);
          segment8Name1.setDisabled(true);
        }
        else
        {
          // �O����ȊO
          prePaidMoney.setDisabled(true);
          slipLine.hideSubTab(0, false);
          commitmentNumber.setRendered(true);

          // AFF���ڕҏW��
          segment1Name1.setDisabled(false);
          segment2Name1.setDisabled(false);
          segment3Name1.setDisabled(false);
          segment4Name1.setDisabled(false);
          segment5Name1.setDisabled(false);
          segment6Name1.setDisabled(false);
          segment7Name1.setDisabled(false);
          segment8Name1.setDisabled(false);
        }

        // AFF�ADFF�v�����v�g�擾�A���̐ݒ�
        ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptArInput");
        segment1Name1.setPrompt((String)affPromptInfo.get(0));
        segment2Name1.setPrompt((String)affPromptInfo.get(1));
        segment3Name1.setPrompt((String)affPromptInfo.get(2));
        segment4Name1.setPrompt((String)affPromptInfo.get(3));
        segment5Name1.setPrompt((String)affPromptInfo.get(4));
        segment6Name1.setPrompt((String)affPromptInfo.get(5));
        segment7Name1.setPrompt((String)affPromptInfo.get(6));
        segment8Name1.setPrompt((String)affPromptInfo.get(7));
        incrDecrReasonName1.setPrompt((String)affPromptInfo.get(8));
        reconReference1.setLabel((String)affPromptInfo.get(9));
        
        // �ꌩ�ڋq�{�^���\���۔���
        // �e�[�u���̈ꌩ�ڋq�\���敪�擾
/*
 LOV����s��̈׃R�����g�A�E�g
        String firstCustomerFlag = (String)am.invokeMethod("getFirstCustomerFlag");
        setFirstCustomerRenderd(pageContext, webBean, firstCustomerFlag);
*/
      }
      catch(OAException ex)
      {
        throw OAException.wrapperException(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
        throw new OAException("XX03",
                              "APP-XX03-13008",
                              null,
                              OAException.ERROR,
                              null);
      }
    } // �߂�{�^���Ή�
  } // processRequest

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    try
    {
      //
      //**************************************************************************
      // ����
      //**************************************************************************
      //
      // ��ʑJ�ڃp�����[�^
      HashMap parameters = new HashMap(4);

      // �A�v���P�[�V�����E���W���[���̎擾
      OAApplicationModule am = pageContext.getApplicationModule(webBean);

      // ��ʍ��ڂ̎擾
      String receivableId = ((OAFormValueBean)webBean.findChildRecursive("ReceivableId")).getValue(pageContext).toString();
      String slipType = ((OAFormValueBean)webBean.findChildRecursive("SlipType")).getValue(pageContext).toString();

      // �^�u
      OASubTabLayoutBean slipLineRn = (OASubTabLayoutBean)webBean.findChildRecursive("InvoiceLineRN");

      if (slipLineRn.isSubTabClicked(pageContext))
      {
          pageContext.putTransactionValue("tab", Xx03ArCommonUtil.STR_YES);
          return;
      }
      
      // *************************************************************************
      // * LOV
      // *************************************************************************
/*
 �v���t�@�C���I�v�V�����F�uFND�F�t���[�����[�N�݊����[�h�v��11.5.10�łȂ���LOV���̓G���A
 ����Tab�����őJ�ڂ����ꍇ�ɓ���s�������̂ŃR�����g�A�E�g
      if (pageContext.isLovEvent())
      {
        // �C�x���g���N����LOV����肷��
        String lovInputId = pageContext.getLovInputSourceId();
        // �ڋqLOV�̏ꍇ
        if ("Customer".equals(lovInputId))
        {
          // LOVItem�p�����[�^�Z�b�g�㎩��ʑJ��
          java.util.Hashtable lovResult = pageContext.getLovResultsFromSession(lovInputId);
          String firstCustomerFlag = "";
          String autoTaxCalcFlagWkHeader = "";
          String taxRoundingRuleWkHeader = "";
          if (lovResult != null)
          {
            // �ꌩ�ڋq�敪�擾
            firstCustomerFlag =  (String)lovResult.get("FirstCustomerFlag");
          }

          parameters.put("paramFirstCustomer", firstCustomerFlag);
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
          pageContext.setForwardURLToCurrentPage(
            parameters, // parameter
            true,       // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
            OAException.INFORMATION);
        }
      }
*/

      //************************************************************************
      // �C���m�F
      // �_�C�A���O�����ǉ�
      //************************************************************************
      if (pageContext.getParameter("Confirm") != null)
      {


        //ver11.5.10.1.6 Add Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkSelfValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver11.5.10.1.6 Add End


        // �_�C�A���O�y�[�W�\��
        // ���b�Z�[�W�쐬
        OAException mainMessage = 
              new OAException("XX03", "APP-XX03-33502");
            
        // �_�C�A���O�E�I�u�W�F�N�g�쐬
        OADialogPage dialogPage = new OADialogPage(OAException.INFORMATION,
              mainMessage, null, "", "");
            
        //OK/NO�{�^�����x�����ݒ�
        dialogPage.setNoButtonLabel("NO");
        dialogPage.setOkButtonLabel("YES");
            
        // OK/NO�{�^���̃A�C�e��ID�ݒ�
        dialogPage.setNoButtonItemName("ConfirmNoButton");
        dialogPage.setOkButtonItemName("ConfirmYesButton");
            
        // OK/NO�{�^����L���ɂ��A�������̑J�ڐ�����̉�ʂɐݒ�
        dialogPage.setNoButtonToPost(true);
        dialogPage.setOkButtonToPost(true);
        dialogPage.setPostToCallingPage(true);
            
        try
        {
          // �_�C�A���O�E�y�[�W�Ƀ��_�C���N�g
          pageContext.redirectToDialogPage(dialogPage);
        }
        catch (Exception ex)
        {
          // OARedirectException������o��̂�catch���Ė���...
        }
      }
      else if (pageContext.getParameter("ConfirmYesButton") != null)
      {
        // �_�C�A���O�y�[�W��"OK"����
        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �o���C���t���O��ON
        am.invokeMethod("setAccountRevisionTemp");
        
        // �ۑ�
        am.invokeMethod("save");

        // �d��`�F�b�N�֐��̌ďo
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = new Serializable[]{checkReceivableId};
        Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msg = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msg.firstElement().toString();
        msg.removeElementAt(0);

        //Ver11.5.10.1.4 Modify Start
        //if (!Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode))
        if (!(Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode) ||
              Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode)))
        //Ver11.5.10.1.4 Modify End
        {
          throw OAException.getBundledOAException(msg);
        }

        // �o���C���t���O��ON
        am.invokeMethod("setAccountRevision");
        
        // �ۑ�
        am.invokeMethod("save");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_CONFIRM);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_CONFIRM,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          true,                                   // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
      //************************************************************************
      // �߂�
      //************************************************************************
      else if (pageContext.getParameter("Back") != null)
      {
        // �ύX���
        am.invokeMethod("rollback");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_CONFIRM);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_CONFIRM,    // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          true,                                   // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
      // *************************************************************************
      // * �ꌩ�ڋq����
      // *************************************************************************
      else if (pageContext.getParameter("FirstCustomerInput") != null)
      {
        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �o���C���t���O��ON
        am.invokeMethod("setAccountRevision");
        
        // �ۑ�
        am.invokeMethod("save");

        // �ꌩ�ڋq�敪�`�F�b�N
        Object firstCustomerFlag = ((OAFormValueBean)webBean.findChildRecursive("FirstCustomerFlag")).getValue(pageContext);
        if ((firstCustomerFlag != null) && (firstCustomerFlag.toString().equals(Xx03ArCommonUtil.STR_YES)))
        {
          // �ꌩ�ڋq�敪'Y'�̏ꍇ�͉�ʑJ��
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_FIRST_CUSTOMER);
          parameters.put("receivableId", receivableId);
          parameters.put("custType", Xx03ArCommonUtil.STR_YES);

          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_FIRST_CUSTOMER, // url
            null,                                       // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,       // menuContextAction
            null,                                       // menuName
            parameters,                                 // parameter
            false,                                      // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,      // addBreadCrumb
            OAException.INFORMATION                     // messagingLevel
          );
        }
        else
        {
          // �ꌩ�ڋq�敪'N'�̏ꍇ�̓G���[���b�Z�[�W�\��
          throw new OAException("XX03", "APP-XX03-13048");
        }
      }
      // *************************************************************************
      // * �O���
      // *************************************************************************
      else if (pageContext.getParameter("PrePaidMoney") != null)
      {      
        String num_type = Xx03ArCommonUtil.TEMP_SLIP_NUM_TYPE;
        Serializable[] methodParams = {num_type};
        Class[] methodParamTypes = {num_type.getClass()};

        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �o���C���t���O��ON
        am.invokeMethod("setAccountRevision");
        
        // �ۑ�
        am.invokeMethod("save");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_PREPAY);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_PREPAY,         // url
          null,                                       // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,       // menuContextAction
          null,                                       // menuName
          parameters,                                 // parameter
          false,                                      // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,      // addBreadCrumb
          OAException.INFORMATION                     // messagingLevel
        );
      }
      // *************************************************************************
      // * ������v
      // *************************************************************************
      else if (pageContext.getParameter("AutoAccounting") != null)
      {
        am.invokeMethod("getAutoAccounting");
      }
    }
    catch(OAException ex)
    {
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            null,
                            OAException.ERROR,
                            null);
    }
  } // processFormRequest


  /**
   * �ꌩ�ڋq�{�^���g�p�A�s�̐ݒ�
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   * @param tableFirstCustomerFlag �e�[�u���̈ꌩ�ڋq�敪
   */
  private void setFirstCustomerRenderd(OAPageContext pageContext, OAWebBean webBean,
    String tableFirstCustomerFlag)
  {
    // �ꌩ�ڋq�{�^���\���ؑ�
    OASubmitButtonBean FirstCustomerInput = 
      (OASubmitButtonBean)webBean.findChildRecursive("FirstCustomerInput");
    Object firstCustomer = Xx03ArCommonUtil.getParameterValue(pageContext, "paramFirstCustomer");
    if (firstCustomer != null)
    {
      // �p�����[�^�̈ꌩ�ڋq�敪������ꍇ
      if (firstCustomer.toString().equals("Y"))
      {
        // �p�����[�^�̈ꌩ�ڋq�敪��'Y'
        FirstCustomerInput.setDisabled(false);
      }
      else
      {
        // �p�����[�^�̈ꌩ�ڋq�敪��'Y'�ȊO
        FirstCustomerInput.setDisabled(true);
      }
    }
    else{
      // �p�����[�^�̈ꌩ�ڋq�敪���Ȃ��ꍇ�̓e�[�u���̒l���Q��
      if (tableFirstCustomerFlag != null)
      {
        if (tableFirstCustomerFlag.equals(Xx03ArCommonUtil.STR_YES))
        {
          // �e�[�u���̈ꌩ�ڋq�敪��'Y'
          FirstCustomerInput.setDisabled(false);
        }
        else
        {
          // �e�[�u���̈ꌩ�ڋq�敪��'Y'�ȊO
          FirstCustomerInput.setDisabled(true);
        }
      }
      else
      {
        // �p�����[�^�̒l���e�[�u���̒l���Ȃ�
        FirstCustomerInput.setDisabled(true);
      }
    }
  }
}
