/*===========================================================================
 * Copyright (c) Oracle Corporation Japan,2004-2005. All right reserved
 * FILENAME     XX03ApInvoiceAcctModifyCK.java
 * VERSION      1.2
 * DATE         2005/03/17
 * HISTORY      2005/02/03  Ver1.0  �V�K�쐬
 *              2005/03/10  Ver1.1  ��QNo.419�Ή�
 *              2005/03/17  Ver1.2  AFF,DFF�v�����v�g���I�擾�Ή�
 *===========================================================================*/
package oracle.apps.xx03.ap.webui;
import com.sun.java.util.collections.Vector;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

// Ver1.2 add start ---------------------------------------------------------
import oracle.apps.fnd.common.MessageToken;
// Ver1.2 add end -----------------------------------------------------------
/**
 * XX03ApInvoiceAcctModifyCK Checker
 * @author Oracle consulting
 */
public class XX03ApInvoiceAcctModifyCK extends OAControllerImpl
{
  public static final String RCS_ID =
    "$Header$: XX03ApInvoiceAcctModifyCK.java 2005/02/03 $";
  public static final boolean RCS_ID_RECORDED =
    VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.ap.webui");

 /**
  * �x���w�b�_���ڂ̕K�{�`�F�b�N���s��
  * @param webBean the web bean corresponding to the region
  * @param pageContext the current OA page context
  */
  public void doHeaderCheck (OAWebBean webBean, OAPageContext pageContext)
  {
    Vector errVec = new Vector();

    // �G���[���݃`�F�b�N�t���O
    boolean errFlag = false;
    // Exception
    OAException excep = null;

    // �d����`�F�b�N
    OAMessageLovInputBean vendorName =
      (OAMessageLovInputBean)webBean.findChildRecursive("vendorName");
    OAFormValueBean vendorId =
      (OAFormValueBean)webBean.findChildRecursive("vendorId");

    // Ver1.1 change start---------------------------------------------------------
    if (vendorName.getValue(pageContext) == null || 
      vendorName.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14102",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      vendorName.setValue(pageContext, "");
      vendorId.setValue(pageContext, "");
    }
    //    else
    //    {
    //      vendorName.setValue(pageContext,
    //                          vendorName.getValue(pageContext));
    //      vendorId.setValue(pageContext,
    //                        vendorId.getValue(pageContext));
    //    }
    // Ver1.1 change end---------------------------------------------------------

    // �d����T�C�g�`�F�b�N
    OAMessageLovInputBean vendorSiteName =
      (OAMessageLovInputBean)webBean.findChildRecursive("vendorSiteName");
    OAFormValueBean vendorSiteId =
      (OAFormValueBean)webBean.findChildRecursive("vendorSiteId");

    // Ver1.1 change start---------------------------------------------------------
    if (vendorSiteName.getValue(pageContext) == null || 
      vendorSiteName.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14103",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      vendorSiteName.setValue(pageContext, "");
    }
    //    else
    //    {
    //      vendorSiteName.setValue(pageContext,
    //                              pageContext.getRawParameter("vendorSiteName"));
    //      vendorSiteId.setValue(pageContext,
    //                            pageContext.getRawParameter("vendorSiteId"));
    //    }
    // Ver1.1 change end---------------------------------------------------------

    // ���������t�`�F�b�N
    OAMessageDateFieldBean invoiceDate =
      (OAMessageDateFieldBean)webBean.findChildRecursive("invoiceDate");

    // Ver1.1 change start---------------------------------------------------------
    if (invoiceDate.getValue(pageContext) == null ||
      invoiceDate.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14104",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      invoiceDate.setValue(pageContext, "");
    }
    // Ver1.1 change end---------------------------------------------------------

    // �v����`�F�b�N
    OAMessageDateFieldBean glDate =
      (OAMessageDateFieldBean)webBean.findChildRecursive("glDate");

    // Ver1.1 change start---------------------------------------------------------
    if (glDate.getValue(pageContext) == null || 
      glDate.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14105",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      glDate.setValue(pageContext, "");
    }
    // Ver1.1 change end---------------------------------------------------------

    // �x���O���[�v�`�F�b�N
    OAMessageLovInputBean payGroupLookupName =
      (OAMessageLovInputBean)webBean.findChildRecursive("payGroupLookupName");
    OAFormValueBean payGroupLookupCode =
      (OAFormValueBean)webBean.findChildRecursive("payGroupLookupCode");

    // Ver1.1 change start---------------------------------------------------------
    if (payGroupLookupName.getValue(pageContext) == null ||
      payGroupLookupName.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14106",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      payGroupLookupName.setValue(pageContext,"");
      payGroupLookupCode.setValue(pageContext,"");
    }
    //    else
    //    {
    //      payGroupLookupName.setValue(pageContext,
    //                                  pageContext.getRawParameter("payGroupLookupName"));
    //      payGroupLookupCode.setValue(pageContext,
    //                                  pageContext.getRawParameter("payGroupLookupCode"));
    //    }
    // Ver1.1 change end---------------------------------------------------------

    // �x�������`�F�b�N
    OAMessageLovInputBean termsName = 
      (OAMessageLovInputBean)webBean.findChildRecursive("termsName");
    OAFormValueBean termsId =
      (OAFormValueBean)webBean.findChildRecursive("termsId");

    // Ver1.1 change start---------------------------------------------------------
    if (termsName.getValue(pageContext) == null ||
      termsName.getValue(pageContext).equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14107",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      termsName.setValue(pageContext,"");
      termsId.setValue(pageContext,"");
    }
    //    else
    //    {
    //      termsName.setValue(pageContext,
    //                         pageContext.getRawParameter("termsName"));
    //      termsId.setValue(pageContext,
    //                       pageContext.getRawParameter("termsId"));
    //    }
    // Ver1.1 change end---------------------------------------------------------

    // Ver1.1 add start---------------------------------------------------------
    // Exception���܂Ƃ߂ďo��
    if (errFlag)
    {
      throw OAException.getBundledOAException(errVec);
    }
    // Ver1.1 add end---------------------------------------------------------
  }

 /**
  * �x�����׍��ڂ̕K�{�`�F�b�N���s��
  * @param webBean the web bean corresponding to the region
  * @param pageContext the current OA page context
  * @param calcFlag ����Ōv�Z���̂�'Y'/���̑���'N'
  */
  public void doLineCheck  (OAWebBean webBean, OAPageContext pageContext, String calcFlag)
  {
    Vector errVec = new Vector();

    // �G���[���݃`�F�b�N�t���O
    boolean errFlag = false;
    // Exception
    OAException excep = null;
    // ���
    OAMessageLovInputBean segment1Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment1Name");
    OAFormValueBean segment1 =
      (OAFormValueBean)webBean.findChildRecursive("segment1");

    if (pageContext.getRawParameter("segment1Name") == null ||
      pageContext.getRawParameter("segment1Name").equals(""))
    {
      errFlag = true;
      // Ver1.2 change start ------------------------------------------------------
      String segment1Prompt = segment1Name.getPrompt();
      if(segment1Prompt == null || segment1Prompt.equals(""))
      {
        segment1Prompt = "SEGMENT1";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT1", segment1Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14114",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment1Name.setValue(pageContext, "");
      segment1.setValue(pageContext, "");
    }
    else
    {
      segment1Name.setValue(pageContext,
                            pageContext.getRawParameter("segment1Name"));
      segment1.setValue(pageContext,
                        pageContext.getRawParameter("segment1"));
    }


    // ����
    OAMessageLovInputBean segment2Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment2Name");
    OAFormValueBean segment2 =
      (OAFormValueBean)webBean.findChildRecursive("segment2");

    if (pageContext.getRawParameter("segment2Name") == null ||
      pageContext.getRawParameter("segment2Name").equals(""))
    {
      errFlag = true;
      // Ver1.2 change start ------------------------------------------------------
      String segment2Prompt = segment2Name.getPrompt();
      if(segment2Prompt == null || segment2Prompt.equals(""))
      {
        segment2Prompt = "SEGMENT2";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT2", segment2Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14115",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment2Name.setValue(pageContext, "");
      segment2.setValue(pageContext, "");
    }
    else
    {
      segment2Name.setValue(pageContext,
                            pageContext.getRawParameter("segment2Name"));
      segment2.setValue(pageContext,
                        pageContext.getRawParameter("segment2"));
    }


    // ����Ȗ�
    OAMessageLovInputBean segment3Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment3Name");
    OAFormValueBean segment3 =
      (OAFormValueBean)webBean.findChildRecursive("segment3");

    if (pageContext.getRawParameter("segment3Name") == null ||
      pageContext.getRawParameter("segment3Name").equals(""))
    {
      errFlag = true;
      // Ver1.2 change start ------------------------------------------------------
      String segment3Prompt = segment3Name.getPrompt();
      if(segment3Prompt == null || segment3Prompt.equals(""))
      {
        segment3Prompt = "SEGMENT3";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT3", segment3Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14116",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment3Name.setValue(pageContext, "");
      segment3.setValue(pageContext, "");
    }
    else
    {
      segment3Name.setValue(pageContext,
                            pageContext.getRawParameter("segment3Name"));
      segment3.setValue(pageContext,
                            pageContext.getRawParameter("segment3"));
    }


    // �⏕�Ȗ�
    OAMessageLovInputBean segment4Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment4Name");
    OAFormValueBean segment4 =
      (OAFormValueBean)webBean.findChildRecursive("segment4");

    if (pageContext.getRawParameter("segment4Name") == null ||
      pageContext.getRawParameter("segment4Name").equals(""))
    {
      errFlag = true;
      // Ver1.2 change start ------------------------------------------------------
      String segment4Prompt = segment4Name.getPrompt();
      if(segment4Prompt == null || segment4Prompt.equals(""))
      {
        segment4Prompt = "SEGMENT4";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT4", segment4Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14117",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------

      errVec.addElement(excep);
      segment4Name.setValue(pageContext, "");
      segment4.setValue(pageContext, "");
    }
    else
    {
      segment4Name.setValue(pageContext,
                            pageContext.getRawParameter("segment4Name"));
      segment4.setValue(pageContext,
                            pageContext.getRawParameter("segment4"));
    }


    // �����
    OAMessageLovInputBean segment5Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment5Name");
    OAFormValueBean segment5 =
      (OAFormValueBean)webBean.findChildRecursive("segment5");

    if (pageContext.getRawParameter("segment5Name") == null ||
      pageContext.getRawParameter("segment5Name").equals(""))
    {
      errFlag = true;

      // Ver1.2 change start ------------------------------------------------------
      String segment5Prompt = segment5Name.getPrompt();
      if(segment5Prompt == null || segment5Prompt.equals(""))
      {
        segment5Prompt = "SEGMENT5";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT5", segment5Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14118",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment5Name.setValue(pageContext, "");
      segment5.setValue(pageContext, "");
    }
    else
    {
      segment5Name.setValue(pageContext,
                            pageContext.getRawParameter("segment5Name"));
      segment5.setValue(pageContext,
                            pageContext.getRawParameter("segment5"));
    }


    // ���Ƌ敪
    OAMessageLovInputBean segment6Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment6Name");
    OAFormValueBean segment6 =
      (OAFormValueBean)webBean.findChildRecursive("segment6");

    if (pageContext.getRawParameter("segment6Name") == null ||
      pageContext.getRawParameter("segment6Name").equals(""))
    {
      errFlag = true;

      // Ver1.2 change start ------------------------------------------------------
      String segment6Prompt = segment6Name.getPrompt();
      if(segment6Prompt == null || segment6Prompt.equals(""))
      {
        segment6Prompt = "SEGMENT6";
      }    
      MessageToken token = new MessageToken("TOK_SEGMENT6", segment6Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14119",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------

      errVec.addElement(excep);
      segment6Name.setValue(pageContext, "");
      segment6.setValue(pageContext, "");
    }
    else
    {
      segment6Name.setValue(pageContext,
                            pageContext.getRawParameter("segment6Name"));
      segment6.setValue(pageContext,
                            pageContext.getRawParameter("segment6"));
    }

    // �v���W�F�N�g
    OAMessageLovInputBean segment7Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment7Name");
    OAFormValueBean segment7 =
      (OAFormValueBean)webBean.findChildRecursive("segment7");

    if (pageContext.getRawParameter("segment7Name") == null ||
      pageContext.getRawParameter("segment7Name").equals(""))
    {
      errFlag = true;

      // Ver1.2 change start ------------------------------------------------------
      String segment7Prompt = segment7Name.getPrompt();
      if(segment7Prompt == null || segment7Prompt.equals(""))
      {
        segment7Prompt = "SEGMENT7";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT7", segment7Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14120",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.2 change end --------------------------------------------------------

      errVec.addElement(excep);
      segment7Name.setValue(pageContext, "");
      segment7.setValue(pageContext, "");
    }
    else
    {
      segment7Name.setValue(pageContext,
                            pageContext.getRawParameter("segment7Name"));
      segment7.setValue(pageContext,
                            pageContext.getRawParameter("segment7"));
    }

    // �\��1
    OAMessageLovInputBean segment8Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment8Name");
    OAFormValueBean segment8 =
      (OAFormValueBean)webBean.findChildRecursive("segment8");

    if (pageContext.getRawParameter("segment8Name") == null ||
      pageContext.getRawParameter("segment8Name").equals(""))
    {
      errFlag = true;
      // Ver1.1 change start ------------------------------------------------------
      String segment8Prompt = segment8Name.getPrompt();
      
      if(segment8Prompt == null || segment8Prompt.equals(""))
      {
        segment8Prompt = "SEGMENT8";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT8", segment8Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-12500",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.1 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment8Name.setValue(pageContext, "");
      segment8.setValue(pageContext, "");
    }
    else
    {
      segment8Name.setValue(pageContext,
                            pageContext.getRawParameter("segment8Name"));
      segment8.setValue(pageContext,
                            pageContext.getRawParameter("segment8"));
    }

    // �`�F�b�N�͂��Ȃ����A�l�̖��ߍ���
    // �������R
    OAMessageLovInputBean incrDecrReasonName =
      (OAMessageLovInputBean)webBean.findChildRecursive("incrDecrReasonName");
    OAFormValueBean incrDecrReasonCode =
      (OAFormValueBean)webBean.findChildRecursive("incrDecrReasonCode");

    if (pageContext.getRawParameter("incrDecrReasonName") == null ||
      pageContext.getRawParameter("incrDecrReasonName").equals(""))
    {
      incrDecrReasonName.setValue(pageContext, "");
      incrDecrReasonCode.setValue(pageContext, "");
    }
    else
    {
      incrDecrReasonName.setValue(pageContext,
                                  pageContext.getRawParameter("incrDecrReasonName"));
      incrDecrReasonCode.setValue(pageContext,
                                  pageContext.getRawParameter("incrDecrReasonCode"));
    }


    // Exception���܂Ƃ߂ďo��
    if (errFlag)
    {
      throw OAException.getBundledOAException(errVec);
    }
  }
}
