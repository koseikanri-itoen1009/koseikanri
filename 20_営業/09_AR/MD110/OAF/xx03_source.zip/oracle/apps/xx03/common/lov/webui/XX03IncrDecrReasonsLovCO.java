/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005  All rights reserved
 * FILENAME     XX03IncrDecrReasonsLovCO.java
 * VERSION      11.5.10.1.6
 * DATE         2005/09/22
 * HISTORY      2005/09/22 ver 11.5.10.1.5  �V�K�쐬�i�p�t�H�[�}���X���P�Ή��j
 *              2005/11/08 ver 11.5.10.1.6  ��QNo.854�Ή�
 *===========================================================================*/
package oracle.apps.xx03.common.lov.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Dictionary;
import oracle.cabo.ui.UIConstants;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;

/**
 *
 * XX03IncrDecrReasonsLovRN�̃R���g���[��
 *
 * @version     11.5.10.1.6
 */
public class XX03IncrDecrReasonsLovCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * lov�̌��������̎��s
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  private void preparedLovQuery(OAPageContext pageContext, OAWebBean webBean)
  {
    // get CriteriaValue
    Dictionary passiveCriteriaItems = pageContext.getLovCriteriaItems();
    String criteriaElement = (String)passiveCriteriaItems.get("ParentFlexValueLow");

    // Criteria Required True
    if((!"".equals(criteriaElement)) && (criteriaElement != null))
    {
      // get VO Name
      //Ver11.5.10.1.6 2005/11/08 Modify start
      //OAMessageStyledTextBean incrDecrReasonsCol =
      //  (OAMessageStyledTextBean)webBean.findChildRecursive("IncrDecrReasonsCol");
      OAMessageStyledTextBean incrDecrReasonsCol =
        (OAMessageStyledTextBean)webBean.findChildRecursive("incrDecrReasonsCol");
      //Ver11.5.10.1.6 2005/11/08 Modify end
      String colVoName = incrDecrReasonsCol.getViewUsageName();

      // get AM
      OAApplicationModule am   = pageContext.getApplicationModule(webBean);

      // get where clause
      String searchText        = pageContext.getParameter(UIConstants.LOV_SEARCH_TEXT);

      // set where clause
      Serializable[] methodParams     = {searchText,criteriaElement,colVoName};
      Class[]        methodParamTypes = {searchText.getClass(),criteriaElement.getClass(),colVoName.getClass()};
      am.invokeMethod("setWhereClauseOnLovQuery" ,methodParams ,methodParamTypes);
    }
    
  }

}
