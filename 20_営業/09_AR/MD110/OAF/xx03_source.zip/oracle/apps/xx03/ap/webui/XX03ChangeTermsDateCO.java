/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005. All rights reserved.
 * FILENAME     XX03ChangeTermsDateCO.java
 * VERSION      11.5.10.1.6
 * DATE         2006/02/02
 * HISTORY      2004/02/19  Ver1.0          �V�K�쐬
 *              2004/03/23  Ver1.1          �V�X�e���G���[���̏C��
 *              2006/02/02  Ver11.5.10.1.6  �{�^���̃_�u���N���b�N�Ή�
 *===========================================================================*/
package oracle.apps.xx03.ap.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanStyledText;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
// 2004.03.23 Add Start
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
// 2004.03.23 Add End
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;

//ver11.5.10.1.6 Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6 Add End

/**
 * XX03ChangeTermsDate Controller
 * @author ��؁@��
 */
public class XX03ChangeTermsDateCO extends OAControllerImpl
{
  public static final String RCS_ID =
    "$Header$: XX03ChangeTermsDateCO.java 2004/03/23 $";
  public static final boolean RCS_ID_RECORDED =
    VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.ap.webui");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //ver11.5.10.1.6 Add Start
    OAApplicationModule am = pageContext.getRootApplicationModule();
    
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button
    
      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6 Add End

    String changeFlag = pageContext.getParameter("changeFlag");

    OAFormValueBean changeFlagItem =
      (OAFormValueBean)webBean.findChildRecursive("changeFlag");


    // 2004.03.23 Add Start
    // �p�����[�^���s��
    if (changeFlag == null)
    {
      OAWebBeanStyledText termsDateDisp =
        (OAWebBeanStyledText)webBean.findChildRecursive("termsDateDisp");
      termsDateDisp.setRendered(false);

      OAMessageDateFieldBean termsDateInput =
        (OAMessageDateFieldBean)webBean.findChildRecursive("termsDateInput");
      termsDateInput.setRendered(false);

      OASubmitButtonBean termsDateButton =
        (OASubmitButtonBean)webBean.findChildRecursive("termsDateButton");
      termsDateButton.setRendered(false);

      // �V�X�e���G���[
      throw new OAException("XX03",
                            "APP-XX03-14999",
                            null,
                            OAException.ERROR,
                            null);
    }
    // 2004.03.23 Add End
    // �x���\����ύX�\�̏ꍇ
    else if (changeFlag.equals("Y"))
    {
      OAWebBeanStyledText termsDateDisp =
        (OAWebBeanStyledText)webBean.findChildRecursive("termsDateDisp");
      termsDateDisp.setRendered(false);
    }
    // �x���\����ύX�s�\�̏ꍇ
    else if (changeFlag.equals("N"))
    {
      OAMessageDateFieldBean termsDateInput =
        (OAMessageDateFieldBean)webBean.findChildRecursive("termsDateInput");
      termsDateInput.setRendered(false);
    }
    // 2004.03.23 Delete Start
    //    // �p�����[�^���s��
    //    else
    //    {
    //      OAWebBeanStyledText termsDateDisp =
    //        (OAWebBeanStyledText)webBean.findChildRecursive("termsDateDisp");
    //      termsDateDisp.setRendered(false);
    //
    //      OAMessageDateFieldBean termsDateInput =
    //        (OAMessageDateFieldBean)webBean.findChildRecursive("termsDateInput");
    //      termsDateInput.setRendered(false);
    //
    //      /* �V�X�e���G���[ */
    //      throw new OAException("XX03",
    //                            "APP-XX03-14999",
    //                            null,
    //                            OAException.ERROR,
    //                            null);
    //    }
    // 2004.03.23 Delete End

    // �ύX�t���O���Z�b�g
    changeFlagItem.setValue(pageContext, changeFlag);

    //ver11.5.10.1.6 Add Start
    }
    //ver11.5.10.1.6 Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    // ��ʃX�e�[�^�X�p�����[�^
    String pageStatus = "termDate";
    // ���s�@�\�p�����[�^
    String funcButton = "back";
    // �ړ�����
    String nextPage = null;
    // AM Retain
    boolean amRetain = false;

    // AM �C���X�^���X
    OAApplicationModule am = pageContext.getRootApplicationModule();

    OAFormValueBean changeFlag =
      (OAFormValueBean)webBean.findChildRecursive("changeFlag");
    String termsDate = null;

    // �߂�{�^��������
    if (pageContext.getParameter("termsDateButton") != null)
    {
      // �x���\������̓`�F�b�N
      // ���̓`�F�b�N */
      if (changeFlag.getValue(pageContext).equals("Y"))
      {
        OAMessageDateFieldBean termsDateInput =
          (OAMessageDateFieldBean)webBean.findChildRecursive("termsDateInput");

        if (termsDateInput.getValue(pageContext) == null)
        {
          throw new OAException("XX03",
                                "APP-XX03-14121",
                                null,
                                OAException.ERROR,
                                null);
        }
      }
      // �\�����ڂ̃`�F�b�N
      else if (changeFlag.getValue(pageContext).equals("N"))
      {
        OAWebBeanStyledText termsDateDisp =
          (OAWebBeanStyledText)webBean.findChildRecursive("termsDateDisp");

        if (termsDateDisp.getValue(pageContext) == null)
        {
          throw new OAException("XX03",
                                "APP-XX03-14121",
                                null,
                                OAException.ERROR,
                                null);
        }
      }

      // next Page
      nextPage = "XX03_APINVOICEINPUTPG";
      // AM Retain
      amRetain = true;

      // �p�����[�^���Z�b�g
      pageContext.putParameter("pageStatus", pageStatus);    
      pageContext.putParameter("funcButton", funcButton);

      // ��ʑJ��
      pageContext.setForwardURL(nextPage,
        KEEP_MENU_CONTEXT,
        null,
        null,
        amRetain, // Retain or Not Retain AM
        ADD_BREAD_CRUMB_NO,
        OAException.ERROR);
    }
  }
}
