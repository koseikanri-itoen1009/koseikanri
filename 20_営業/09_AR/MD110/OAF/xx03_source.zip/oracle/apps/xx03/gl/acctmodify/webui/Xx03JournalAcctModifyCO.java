/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005. All rights reserved.
 * FILENAME   Xx03JournalAcctModifyCO.java
 * VERSION    11.5.10.2.10
 * DATE       2007/09/14
 * HISTORY    2004/12/01 ver 1.0          �V�K�쐬
 *            2005/02/24 ver 1.1          �d�l�ύX�Ή��g��
 *            2005/07/07 ver 11.5.10.1.4  ����Ŋz�݂̂ł��v��ł���悤�ɏC��
 *            2005/11/11 ver 11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�
 *            2006/02/02 ver 11.5.10.1.6B �{�^���̃_�u���N���b�N�Ή�
 *            2006/02/28 ver 11.5.10.1.6C �}�X�^�`�F�b�N�̃^�C�~���O�ύX
 *            2007/09/14 ver 11.5.10.2.10 PL/SQL�ł̃`�F�b�N�ナ�t���b�V�������̒ǉ�
 *
 *===========================================================================*/
package oracle.apps.xx03.gl.acctmodify.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASubTabLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;
// import oracle.apps.fnd.framework.webui.beans.table.OAAdvancedTableBean;
import oracle.apps.xx03.util.Xx03CommonUtil;

import oracle.jbo.domain.Number;

// Ver1.1 add start ---------------------------------------------------
import java.util.ArrayList;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
// Ver1.1 add end -----------------------------------------------------

//ver11.5.10.1.6 Add Start
import oracle.bali.share.util.BooleanUtils;
//ver11.5.10.1.6 Add End

/**
 *
 * Xx03JournalAcctModifyPG�̃R���g���[��
 *
 * @version     11.5.10.1.6
 */
public class Xx03JournalAcctModifyCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    // �A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    // �߂�{�^���ɂ����s�̏ꍇ
    if (pageContext.isBackNavigationFired(false))
    {
      am.invokeMethod("rollback");

      //ver11.5.10.1.6B Chg Start
      //OADialogPage dialogPage = new OADialogPage(STATE_LOSS_ERROR);
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );
      //ver11.5.10.1.6B Chg End

      pageContext.redirectToDialogPage(dialogPage);
    }
    // �߂�{�^���ɂ����s�łȂ��ꍇ
    else
    {
      try{
        //
        //************************************************************************
        // ���ʏ���
        //************************************************************************
        //
        // �p�����[�^�擾
        String pageStatus = pageContext.getParameter("pageStatus");
        String funcButton = pageContext.getParameter("funcButton");

        // �^�u�������̌��؏����𖳌���
        OASubTabLayoutBean slipLine = (OASubTabLayoutBean)webBean.findChildRecursive("SlipLineRN");
        slipLine.setUnvalidated(true);

        //
        //**********************************************************************
        // �^�u
        //**********************************************************************
        //
        // �^�u�ؑ֎��́A������
        if (Xx03CommonUtil.STR_YES.equals(pageContext.getTransactionValue("tab")))
        {
          pageContext.removeTransactionValue("tab");
        }
        //ver11.5.10.1.6 Add Start
        else if (    (Xx03CommonUtil.WINDOW_NAME_CONFIRM.equals(pageStatus))
                  && (Xx03CommonUtil.FUNC_NAME_MODIFY.equals(funcButton)   ) )
        {
          Number journalId = new Number(Xx03CommonUtil.getParameterValue(pageContext, "journalId"));

          // �w�b�_�[�A���ׂ̌���
          Boolean executeQuery = BooleanUtils.getBoolean(false);
          Serializable[] methodParams = {journalId, executeQuery};
          Class[] methodParamTypes = {journalId.getClass(), executeQuery.getClass()};
      
          am.invokeMethod("initJournalSlips", methodParams, methodParamTypes);
        }
        //ver11.5.10.1.6 Add End
        //
        //**********************************************************************
        // ���ʏ���
        //**********************************************************************
        //
        // �`�[��ʂ̕\���e�L�X�g�ύX
        OAHeaderBean slipHeaderTitleBean = (OAHeaderBean)webBean.findIndexedChildRecursive("SlipHeaderTitleRN");
        //ver11.5.10.1.6 Chg Start
        //slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
        //  new OADataBoundValueViewObject(slipHeaderTitleBean, "SlipTypeName", "Xx03JournalSlipsVO1"));
        slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
          new OADataBoundValueViewObject(slipHeaderTitleBean, "Description", "Xx03SlipTypesLovVO1"));
        //ver11.5.10.1.6 Chg End

        // ver 1.1 Change Start
        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");
        // ver 1.1 Change End

        // Ver1.1 add start ---------------------------------------------------------
        //AFF�ADFF���ڂ̎擾(�ݕ�)
        OAMessageLovInputBean segment1Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment1Name1");
        OAMessageLovInputBean segment2Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment2Name1");
        OAMessageLovInputBean segment3Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment3Name1");
        OAMessageLovInputBean segment4Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment4Name1");
        OAMessageLovInputBean segment5Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment5Name1");
        OAMessageLovInputBean segment6Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment6Name1");
        OAMessageLovInputBean segment7Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment7Name1");
        OAMessageLovInputBean segment8Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment8Name1");
        OAMessageLovInputBean incrDecrReasonName1 = (OAMessageLovInputBean)webBean.findChildRecursive("IncrDecrReasonName1");

        //AFF�ADFF���ڂ̎擾(�ؕ�)
        OAMessageLovInputBean segment1Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment1Name");
        OAMessageLovInputBean segment2Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment2Name");
        OAMessageLovInputBean segment3Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment3Name");
        OAMessageLovInputBean segment4Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment4Name");
        OAMessageLovInputBean segment5Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment5Name");
        OAMessageLovInputBean segment6Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment6Name");
        OAMessageLovInputBean segment7Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment7Name");
        OAMessageLovInputBean segment8Name = (OAMessageLovInputBean)webBean.findChildRecursive("Segment8Name");
        OAMessageLovInputBean incrDecrReasonName = (OAMessageLovInputBean)webBean.findChildRecursive("IncrDecrReasonName");

        // AFF�ADFF�v�����v�g�擾�A���̐ݒ�
        ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptGlInput");
        segment1Name1.setPrompt((String)affPromptInfo.get(0));
        segment1Name.setPrompt((String)affPromptInfo.get(0));
        segment2Name1.setPrompt((String)affPromptInfo.get(1));
        segment2Name.setPrompt((String)affPromptInfo.get(1));
        segment3Name1.setPrompt((String)affPromptInfo.get(2));
        segment3Name.setPrompt((String)affPromptInfo.get(2));
        segment4Name1.setPrompt((String)affPromptInfo.get(3));
        segment4Name.setPrompt((String)affPromptInfo.get(3));
        segment5Name1.setPrompt((String)affPromptInfo.get(4));
        segment5Name.setPrompt((String)affPromptInfo.get(4));
        segment6Name1.setPrompt((String)affPromptInfo.get(5));
        segment6Name.setPrompt((String)affPromptInfo.get(5));
        segment7Name1.setPrompt((String)affPromptInfo.get(6));
        segment7Name.setPrompt((String)affPromptInfo.get(6));
        segment8Name1.setPrompt((String)affPromptInfo.get(7));
        segment8Name.setPrompt((String)affPromptInfo.get(7));
        incrDecrReasonName1.setPrompt((String)affPromptInfo.get(8));
        incrDecrReasonName.setPrompt((String)affPromptInfo.get(8));
        // Ver1.1 add end -----------------------------------------------------------
      }
      catch(OAException ex)
      {
        throw OAException.wrapperException(ex);
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
        throw new OAException("XX03",
                              "APP-XX03-11538",
                              null,
                              OAException.ERROR,
                              null);
      }
    } // �߂�{�^���Ή�
  } // processRequest

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    try
    {
      //
      //**************************************************************************
      // ����
      //**************************************************************************
      //
      // ��ʑJ�ڃp�����[�^
      HashMap parameters = new HashMap(4);

      // �A�v���P�[�V�����E���W���[���̎擾
      OAApplicationModule am = pageContext.getApplicationModule(webBean);

      // ��ʍ��ڂ̎擾
      String journalId = ((OAFormValueBean)webBean.findChildRecursive("JournalId")).getValue(pageContext).toString();
      String ignoreRateFlag = ((OAMessageCheckBoxBean)webBean.findChildRecursive("IgnoreRateFlag")).getValue(pageContext).toString();
      String slipType = ((OAFormValueBean)webBean.findChildRecursive("SlipType")).getValue(pageContext).toString();

      // �^�u
      OASubTabLayoutBean slipLineRn = (OASubTabLayoutBean)webBean.findChildRecursive("SlipLineRN");

      if (slipLineRn.isSubTabClicked(pageContext))
      {
          pageContext.putTransactionValue("tab", Xx03CommonUtil.STR_YES);
          return;
      }

      //
      //************************************************************************
      // �C���m�F
      // ver 1.1 �m�F�_�C�A���O�����ǉ�
      //************************************************************************
      //
      if (pageContext.getParameter("Confirm") != null)
      {

        //ver 11.5.10.1.6C Del Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkSelfValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver 11.5.10.1.6C Del End

        // �_�C�A���O�y�[�W�\��
        // ���b�Z�[�W�쐬
        OAException mainMessage = 
              new OAException("XX03", "APP-XX03-11558");
            
        // �_�C�A���O�E�I�u�W�F�N�g�쐬
        OADialogPage dialogPage = new OADialogPage(OAException.INFORMATION,
              mainMessage, null, "", "");
            
        //OK/NO�{�^�����x�����ݒ�
        dialogPage.setNoButtonLabel("NO");
        dialogPage.setOkButtonLabel("YES");
            
        // OK/NO�{�^���̃A�C�e��ID�ݒ�
        dialogPage.setNoButtonItemName("ConfirmNoButton");
        dialogPage.setOkButtonItemName("ConfirmYesButton");
            
        // OK/NO�{�^����L���ɂ��A�������̑J�ڐ�����̉�ʂɐݒ�
        dialogPage.setNoButtonToPost(true);
        dialogPage.setOkButtonToPost(true);
        dialogPage.setPostToCallingPage(true);
            
        try
        {
          // �_�C�A���O�E�y�[�W�Ƀ��_�C���N�g
          pageContext.redirectToDialogPage(dialogPage);
        }
        catch (Exception ex)
        {
          // OARedirectException������o��̂�catch���Ė���...
        }
      }
      else if (pageContext.getParameter("ConfirmYesButton") != null)
      {
        // �_�C�A���O�y�[�W��"OK"����
        // ver 1.1 add start
        // �o���C���ꎞ�t���O��ON
        am.invokeMethod("setAccountRevisionTemp");
        // ver 1.1 add end
        
        // �ۑ�
        am.invokeMethod("save");

        //ver11.5.10.1.6 Add Start
        //ver 11.5.10.1.6C Del Start
        //// �}�X�^�`�F�b�N
        //Vector error = (Vector)am.invokeMethod("checkSelfValidation");
        //if (!error.isEmpty())
        //{
        //  throw OAException.getBundledOAException(error);
        //}
        //ver 11.5.10.1.6C Del End
        //ver11.5.10.1.6 Add End

        // �d��`�F�b�N�֐��̌ďo
        Number checkJournalId = new Number(journalId);
        Serializable[] methodParams = {checkJournalId};
        Class[] methodParamTypes = {checkJournalId.getClass()};
        Vector msg = (Vector)am.invokeMethod("callDeptInputGl", methodParams, methodParamTypes);

        //ver 11.5.10.2.10 Add Start
        am.invokeMethod("refreshSlipsInput");
        //ver 11.5.10.2.10 Add End

        String retCode = msg.firstElement().toString();
        msg.removeElementAt(0);

        //Ver11.5.10.1.4 2005/07/11 Modify Start
        //�`�F�b�N���ʂ�Warning�̎��ł��\���ł���悤�ɕύX
        //if (!Xx03CommonUtil.RETCODE_SUCCESS.equals(retCode))
        if (!(Xx03CommonUtil.RETCODE_SUCCESS.equals(retCode) ||
              Xx03CommonUtil.RETCODE_WARNING.equals(retCode)))
        //Ver11.5.10.1.4 2005/07/11 Modify End
        {
          throw OAException.getBundledOAException(msg);
        }

        // �o���C���t���O��ON
        am.invokeMethod("setAccountRevision");

        // �ۑ�
        am.invokeMethod("save");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03CommonUtil.WINDOW_NAME_ACCTMODIFY);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03CommonUtil.FUNC_NAME_CONFIRM);
        parameters.put("journalId", journalId);

        pageContext.setForwardURL(
          Xx03CommonUtil.WINDOW_URL_CONFIRM,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          //ver11.5.10.1.6 Chg Start
          //true,                                   // ratainAM
          false,                                  // ratainAM
          //ver11.5.10.1.6 Chg End
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
      //
      //************************************************************************
      // �߂�
      //************************************************************************
      //
      else if (pageContext.getParameter("Back") != null)
      {
        // �ύX���
        am.invokeMethod("rollback");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03CommonUtil.WINDOW_NAME_ACCTMODIFY);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03CommonUtil.FUNC_NAME_BACK_TO_CONFIRM);
        parameters.put("journalId", journalId);

        pageContext.setForwardURL(
          Xx03CommonUtil.WINDOW_URL_CONFIRM,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          //ver11.5.10.1.6 Chg Start
          //true,                                   // ratainAM
          false,                                  // ratainAM
          //ver11.5.10.1.6 Chg End
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
    }
    catch(OAException ex)
    {
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      throw new OAException("XX03",
                            "APP-XX03-11538",
                            null,
                            OAException.ERROR,
                            null);
    }
  } // processFormRequest
}
