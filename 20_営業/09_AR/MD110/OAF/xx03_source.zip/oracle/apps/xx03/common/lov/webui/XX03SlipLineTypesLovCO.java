/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005  All rights reserved
 * FILENAME     XX03SlipLineTypesLovCO.java
 * VERSION      11.5.10.1.6C
 * DATE         2006/02/14
 * HISTORY      2005/11/21 ver 11.5.10.1.6  �V�K�쐬�i�p�t�H�[�}���X���P�Ή��j
 *              2005/12/22 ver 11.5.10.1.6B �ŋ敪�̗L���`�F�b�N�Ή�
 *              2006/02/14 Ver 11.5.10.1.6C ��Q910�ŋ敪�̓��t�i���݂���߂�
 *===========================================================================*/
package oracle.apps.xx03.common.lov.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Dictionary;
import oracle.cabo.ui.UIConstants;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;

//Ver11.5.10.1.6B 2005/12/22 Add Start
import oracle.jbo.domain.Date;
import oracle.apps.fnd.framework.OAException;
//Ver11.5.10.1.6B 2005/12/22 Add End

/**
 * Controller for ...
 */
public class XX03SlipLineTypesLovCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * lov�̌��������̎��s
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  private void preparedLovQuery(OAPageContext pageContext, OAWebBean webBean)
  {
    // get VO Name
    OAMessageStyledTextBean partnersCol =
      (OAMessageStyledTextBean)webBean.findChildRecursive("slipLineTypesCol");
    String colVoName = partnersCol.getViewUsageName();

    // get AM
    OAApplicationModule am   = pageContext.getApplicationModule(webBean);

    // get where clause
    String searchText        = pageContext.getParameter(UIConstants.LOV_SEARCH_TEXT);
    String lovCategoryChoice = pageContext.getParameter(OAWebBeanConstants.LOV_CATEGORY_CHOICE);

    //Ver11.5.10.1.6C Del Start
    ////Ver11.5.10.1.6B 2005/12/22 Add Start
    //// get CriteriaValue
    //Dictionary passiveCriteriaItems = pageContext.getLovCriteriaItems();
    //String parentDateTemp = passiveCriteriaItems.get("invDate").toString();
    //
    //Date parentDate = null;
    //try
    //{
    //  parentDate = new Date(oracle.sql.DATE.fromText(parentDateTemp,"YYYY/MM/DD",""));
    //}
    //catch (Exception ex)
    //{
    //  ex.printStackTrace();
    //    throw new OAException("XX03",
    //                          "APP-XX03-08014",
    //                          null,
    //                          OAException.ERROR,
    //                          null);
    //}
    ////Ver11.5.10.1.6B 2005/12/22 Add End
    //Ver11.5.10.1.6C Del End

    if (null == lovCategoryChoice)
    {
      // null�̏ꍇ�͌ڋq���������s��
      lovCategoryChoice = "slipLineTypesCol";
    }

    // setWhereClauseOnLovQuery
    //Ver11.5.10.1.6B 2005/12/22 Change Start
    //Serializable[] methodParams     = {searchText, lovCategoryChoice, colVoName};
    //Class[]        methodParamTypes = {searchText.getClass(), lovCategoryChoice.getClass(), colVoName.getClass()};

    //Ver11.5.10.1.6C Chg Start
    //Serializable[] methodParams     = {searchText, lovCategoryChoice, colVoName, parentDate};
    //Class[]        methodParamTypes = {searchText.getClass(), lovCategoryChoice.getClass(), colVoName.getClass(), parentDate.getClass()};
    Serializable[] methodParams     = {searchText, lovCategoryChoice, colVoName};
    Class[]        methodParamTypes = {searchText.getClass(), lovCategoryChoice.getClass(), colVoName.getClass()};
    //Ver11.5.10.1.6C Chg End

    am.invokeMethod("setWhereClauseOnLovQuery", methodParams, methodParamTypes);
    //Ver11.5.10.1.6B 2005/12/22 Change End  
  }

}
