/*============================================================================
 * Copyright (c) Oracle Corporation Japan, 2004 - 2005. All rights reserved.
 * FILENAME    Xx03InvoiceCancelCO.java
 * VERSION      11.5.10.1.6C
 * DATE         2006/02/02
 * HISTORY      2005/01/26  Ver1.0          �V�K�쐬
 *              2005/11/11  Ver11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�
 *              2006/01/10  Ver11.5.10.1.6B ��Q578 ���F�Ҕ���̏C��
 *              2006/02/02  Ver11.5.10.1.6C �{�^���̃_�u���N���b�N�Ή�
 *===========================================================================*/ 
package oracle.apps.xx03.ar.cancel.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;

import oracle.jbo.domain.Number;

//ver11.5.10.1.6C Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6C Add End

/**
  * Xx03InvoiceCancelCO �`�[�����ʂ�Controller
  * @version ver 11.5.10.1.6
  */
public class Xx03InvoiceCancelCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //�A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getRootApplicationModule();

    //ver11.5.10.1.6C Add Start
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6C Add End

    try{
      //�p�����[�^�擾
      String pageStatus = pageContext.getParameter("pageStatus");       //��ʃX�e�[�^�X                   
      String funcButton = pageContext.getParameter("funcButton");       //���s�@�\                  
      String receivableId  = pageContext.getParameter("receivableId");  //�`�[ID    
      //����^�C�vID�Ǝ���^�C�v���̎擾
      Number creditMemoTypeId = new Number(pageContext.getParameter("paramCreditMemoTypeId"));
      String creditMemoTypeName = pageContext.getParameter("paramCreditMemoTypeName");
     
      //�V�X�e���G���[����
      if (pageStatus == null || funcButton== null)
      {
        //�V�X�e���G���[
        throw new OAException("XX03",
                              "APP-XX03-13008",
                              null,
                              OAException.ERROR,
                              null);
      }
      //�`�[�폜�{�^��������
      else if (pageStatus.equals(Xx03ArCommonUtil.WINDOW_NAME_CONFIRM) && funcButton.equals(Xx03ArCommonUtil.FUNC_NAME_SLIP_CANCEL))
      {
        //�`�[ID�����Ƀf�[�^���擾
        Serializable[] methodParams = {receivableId, creditMemoTypeId, creditMemoTypeName};
        Class[] methodParamTypes = {receivableId.getClass(), creditMemoTypeId.getClass(), creditMemoTypeName.getClass()};
        am.invokeMethod("copyInvoiceData", methodParams, methodParamTypes);
      
        //���[�UID�ƐE��ID���擾
        Integer empId  = new Integer (pageContext.getEmployeeId());
        Integer respId = new Integer (pageContext.getResponsibilityId());

        //���[�U�[���A�f�t�H���g���F�҂̎擾
        am.invokeMethod("getEntryUser", new Serializable[]{empId.toString()});

        //ver 11.5.10.1.6C Chg Start
        //am.invokeMethod("getDefaultApprover", new Serializable[]{empId.toString(), respId.toString()});
        am.invokeMethod("getDefaultApprover");
        //ver 11.5.10.1.6C Chg End

        //����^�C�v���̕\��
        OAHeaderBean slipHeaderRN = (OAHeaderBean)webBean.findChildRecursive("SlipHeaderRN");
        slipHeaderRN.setText(pageContext, creditMemoTypeName);
      }
    }
    catch(Exception ex)
    {
      //debug
      ex.printStackTrace();
      //�V�X�e���G���[
      throw new OAException("XX03", "APP-XX03-13008", ex);
    }

    //ver11.5.10.1.6C Add Start
    }
    //ver11.5.10.1.6C Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    //��ʑJ�ڃp�����[�^
    HashMap parameters = new HashMap(4);
    
    //�A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getRootApplicationModule();

    //�p�����[�^������(�`�[ID)
    Serializable receivableId  = null;

    //�m�F�{�^��������
    if (pageContext.getParameter("Confirm") != null)
    {
      //�ύX����
      Serializable isDirty = am.invokeMethod("isDirty");
      if (!((Boolean)isDirty).booleanValue())
      {
        return;
      }    

      //ver11.5.10.1.6 Add Start
      // �}�X�^�`�F�b�N
      Vector error = (Vector)am.invokeMethod("checkSelfValidation");
      if (!error.isEmpty())
      {
        throw OAException.getBundledOAException(error);
      }
      //ver11.5.10.1.6 Add End

      //�f�[�^�̊m��
      receivableId = am.invokeMethod("saveInvoiceData");
  
      //�G���[�`�F�b�N�֐�
      Vector errCheckVec = (Vector)am.invokeMethod("checkDeptInputAr", new Serializable[]{receivableId.toString()});
      if (!(errCheckVec.lastElement().toString().equals("normal")) &&
          !(errCheckVec.lastElement().toString().equals("warn")))
      {
        throw OAException.getBundledOAException(errCheckVec);
      }

      //�p�����[�^���Z�b�g
      parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CANCEL);
      parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_CONFIRM);
      parameters.put("receivableId",  receivableId.toString());

      //��ʑJ��
       pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_CONFIRM,    // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
       );
    }
    //�߂�{�^��������
    else if (pageContext.getParameter("Back") != null)
    {
      //������`�[ID���擾
      receivableId = am.invokeMethod("getOldReceivableId");

      //�p�����[�^���Z�b�g
      parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CANCEL);    
      parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_CONFIRM);
      parameters.put("receivableId",  receivableId.toString());

      //��ʑJ��
      pageContext.setForwardURL(
         Xx03ArCommonUtil.WINDOW_URL_CONFIRM,    // url
         null,                                   // functinoName
         OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
         null,                                   // menuName
         parameters,                             // parameter
         false,                                  // ratainAM
         OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
         OAException.INFORMATION                 // messagingLevel
      );
    } 
  }
}
