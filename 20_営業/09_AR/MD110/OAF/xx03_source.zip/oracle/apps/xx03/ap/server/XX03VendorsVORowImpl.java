/*============================================================================
* �t�@�C���� : XX03VendorsVORowImpl
* �T�v����   : �d���於�A�x���O���[�v�������p�r���[�s�N���X
* �o�[�W���� : 1.1
*============================================================================
* �C������
* ���t       Ver. �S����       �C�����e
* ---------- ---- ------------ ----------------------------------------------
* 2023-01-26 1.0  SCSK�Ԓn�w     �V�K�쐬
* 2023-10-24 1.1  SCSK��R�m��   [E_�{�ғ�_19496]�O���[�v��Г����Ή�
*============================================================================
*/
package oracle.apps.xx03.ap.server;
import oracle.apps.fnd.framework.server.OAViewRowImpl;
import oracle.jbo.server.AttributeDefImpl;

/*******************************************************************************
 * �d���於�A�x���O���[�v���擾���邽�߂̃r���[�s�N���X�ł��B
 * @author  SCSK�Ԓn�w
 * @version 1.0
 *******************************************************************************
 */
public class XX03VendorsVORowImpl extends OAViewRowImpl 
{


  protected static final int VENDORNAME = 0;
  protected static final int PAYGROUPCODE = 1;
  protected static final int PAYGROUPMEANING = 2;
  protected static final int DRAFTINGCOMPANY = 3;
  /**
   * 
   * This is the default constructor (do not remove)
   */
  public XX03VendorsVORowImpl()
  {
  }

  /**
   * 
   * Gets the attribute value for the calculated attribute VendorName
   */
  public String getVendorName()
  {
    return (String)getAttributeInternal(VENDORNAME);
  }

  /**
   * 
   * Sets <code>value</code> as the attribute value for the calculated attribute VendorName
   */
  public void setVendorName(String value)
  {
    setAttributeInternal(VENDORNAME, value);
  }

  /**
   * 
   * Gets the attribute value for the calculated attribute PayGroupCode
   */
  public String getPayGroupCode()
  {
    return (String)getAttributeInternal(PAYGROUPCODE);
  }

  /**
   * 
   * Sets <code>value</code> as the attribute value for the calculated attribute PayGroupCode
   */
  public void setPayGroupCode(String value)
  {
    setAttributeInternal(PAYGROUPCODE, value);
  }

  /**
   * 
   * Gets the attribute value for the calculated attribute PayGroupMeaning
   */
  public String getPayGroupMeaning()
  {
    return (String)getAttributeInternal(PAYGROUPMEANING);
  }

  /**
   * 
   * Sets <code>value</code> as the attribute value for the calculated attribute PayGroupMeaning
   */
  public void setPayGroupMeaning(String value)
  {
    setAttributeInternal(PAYGROUPMEANING, value);
  }
  //  Generated method. Do not modify.

  protected Object getAttrInvokeAccessor(int index, AttributeDefImpl attrDef) throws Exception
  {
    switch (index)
      {
      case VENDORNAME:
        return getVendorName();
      case PAYGROUPCODE:
        return getPayGroupCode();
      case PAYGROUPMEANING:
        return getPayGroupMeaning();
      case DRAFTINGCOMPANY:
        return getDraftingCompany();
      default:
        return super.getAttrInvokeAccessor(index, attrDef);
      }
  }
  //  Generated method. Do not modify.

  protected void setAttrInvokeAccessor(int index, Object value, AttributeDefImpl attrDef) throws Exception
  {
    switch (index)
      {
      case VENDORNAME:
        setVendorName((String)value);
        return;
      case PAYGROUPCODE:
        setPayGroupCode((String)value);
        return;
      case PAYGROUPMEANING:
        setPayGroupMeaning((String)value);
        return;
      case DRAFTINGCOMPANY:
        setDraftingCompany((String)value);
        return;
      default:
        super.setAttrInvokeAccessor(index, value, attrDef);
        return;
      }
  }

  /**
   * 
   * Gets the attribute value for the calculated attribute DraftingCompany
   */
  public String getDraftingCompany()
  {
    return (String)getAttributeInternal(DRAFTINGCOMPANY);
  }

  /**
   * 
   * Sets <code>value</code> as the attribute value for the calculated attribute DraftingCompany
   */
  public void setDraftingCompany(String value)
  {
    setAttributeInternal(DRAFTINGCOMPANY, value);
  }
}