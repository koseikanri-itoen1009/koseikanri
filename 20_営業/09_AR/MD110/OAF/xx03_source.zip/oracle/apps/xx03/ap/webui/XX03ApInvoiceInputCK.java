/*===========================================================================
 * Copyright (c) Oracle Corporation 2004 - 2005. All rights reserved.
 * FILENAME   XX03ApInvoiceInputCK.java
 * VERSION    Ver11.5.10.2.10
 * Date       2007/08/14
 * HISTORY    2004/02/20 ver 1.0          �V�K�쐬
 *            2004/03/17 ver 1.1          ���F�҃`�F�b�N�̃o�O�C��
 *            2004/04/02 ver 1.2          �{�̋��z�̃`�F�b�N���W�b�N�̍폜
 *            2005/02/09 ver 1.3          AFF�g��(Segment8�\��)�Ή�
 *            2005/02/15 ver 1.4          ��Q150�Ή�
 *            2005/02/17 ver 1.5          ��Q152�Ή�
 *            2005/03/07 ver 1.6          ��Q223�Ή�
 *            2005/03/17 ver 1.7          AFF,DFF�v�����v�g���I�擾�Ή�
 *            2005/05/18 ver 11.5.10.1.2  �ŃR�[�h�̃`�F�b�N��ǉ�
 *            2005/08/08 ver 11.5.10.1.4  �ŃR�[�h�̃`�F�b�N�Œl�������Ă��Ȃ��ꍇ�ɑΉ�
 *            2005/12/26 ver 11.5.10.1.6  �ŋ敪�̗L���`�F�b�N�Ή�
 *            2007/08/14 ver 11.5.10.2.10 �ŋ��R�[�h�G���[(���������t���L�����͈͊O)����
 *                                        ���������t���C�����Ă��G���[�ƂȂ鎖�̏C��
 *
 *===========================================================================*/
package oracle.apps.xx03.ap.webui;
import com.sun.java.util.collections.Vector;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
// 2004.04.02 Delete Start
//import oracle.apps.fnd.framework.webui.beans.OAWebBeanStyledText;
// 2004.04.02 Delete End
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.OAApplicationModule;
import java.io.Serializable;
// Ver1.7 add start ---------------------------------------------------------
import oracle.apps.fnd.common.MessageToken;
// Ver1.7 add end -----------------------------------------------------------
/**
 * XX03ApInvoiceInputCK Checker
 * @author ��؁@��
 */
public class XX03ApInvoiceInputCK extends OAControllerImpl
{
  public static final String RCS_ID =
    "$Header$: XX03ChangeTermsDateCO.java 2004/04/02 $";
  public static final boolean RCS_ID_RECORDED =
    VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.ap.webui");

 /**
  * �x���w�b�_���ڂ̕K�{�`�F�b�N���s��
  * @param webBean the web bean corresponding to the region
  * @param pageContext the current OA page context
  */
  public void doHeaderCheck (OAWebBean webBean, OAPageContext pageContext)
  {
    // 2005.02.15 Add start
    // am���`(�ʉ݃`�F�b�N�p)
    OAApplicationModule am = pageContext.getRootApplicationModule();
    // 2005.02.15 Add end

    Vector errVec = new Vector();

    // �G���[���݃`�F�b�N�t���O
    boolean errFlag = false;
    // Exception
    OAException excep = null;

    // ���F�҃`�F�b�N
    OAMessageLovInputBean approverPersonName =
      (OAMessageLovInputBean)webBean.findChildRecursive("approverPersonName");
    OAFormValueBean approverPersonId =
      (OAFormValueBean)webBean.findChildRecursive("approverPersonId");

    if (approverPersonName.getValue(pageContext) == null)
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14122",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      approverPersonName.setValue(pageContext, "");
      approverPersonId.setValue(pageContext, "");
    }
    // 2004.03.18 Delete Start
    //    else
    //    {
    //      approverPersonId.setValue(pageContext,
    //                                pageContext.getRawParameter("vendorSiteName"));
    //    }
    // 2004.03.18 Delete End

    // �d����`�F�b�N
    OAMessageLovInputBean vendorName =
      (OAMessageLovInputBean)webBean.findChildRecursive("vendorName");
    OAFormValueBean vendorId =
      (OAFormValueBean)webBean.findChildRecursive("vendorId");

    // 2005.03.07 Modify Start
    //if (pageContext.getRawParameter("vendorName") == null || 
    //  pageContext.getRawParameter("vendorName").equals(""))
    if (pageContext.getRawParameter("vendorName") == null || 
      pageContext.getRawParameter("vendorName").equals("") ||
      pageContext.getRawParameter("vendorId") == null ||
      pageContext.getRawParameter("vendorId").equals(""))
    // 2005.03.07 Modify End
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14102",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      // 2005.03.07 Modify Start
      //vendorName.setValue(pageContext, "");
      vendorName.setValue(pageContext,
                                  pageContext.getRawParameter("vendorName"));
      // 2005.03.07 Modify End
      vendorId.setValue(pageContext, "");
    }
    else
    {
      vendorName.setValue(pageContext,
                          pageContext.getRawParameter("vendorName"));
      vendorId.setValue(pageContext,
                        pageContext.getRawParameter("vendorId"));
    }


    // �d����T�C�g�`�F�b�N
    OAMessageLovInputBean vendorSiteName =
      (OAMessageLovInputBean)webBean.findChildRecursive("vendorSiteName");
    OAFormValueBean vendorSiteId =
      (OAFormValueBean)webBean.findChildRecursive("vendorSiteId");

    // 2005.03.07 Modify Start
    //if (pageContext.getRawParameter("vendorSiteName") == null || 
    //  pageContext.getRawParameter("vendorSiteName").equals(""))
    if (pageContext.getRawParameter("vendorSiteName") == null || 
      pageContext.getRawParameter("vendorSiteName").equals("") ||
      pageContext.getRawParameter("vendorSiteId") == null ||
      pageContext.getRawParameter("vendorSiteId").equals(""))
    // 2005.03.07 Modify End
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14103",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      // 2005.03.07 Modify Start
      //vendorSiteName.setValue(pageContext, "");
      vendorSiteName.setValue(pageContext,
                                  pageContext.getRawParameter("vendorSiteName"));
      // 2005.03.07 Modify End
      vendorSiteId.setValue(pageContext,"");
    }
    else
    {
      vendorSiteName.setValue(pageContext,
                              pageContext.getRawParameter("vendorSiteName"));
      vendorSiteId.setValue(pageContext,
                            pageContext.getRawParameter("vendorSiteId"));
    }


    // ���������t�`�F�b�N
    OAMessageDateFieldBean invoiceDate =
      (OAMessageDateFieldBean)webBean.findChildRecursive("invoiceDate");

    if (pageContext.getRawParameter("invoiceDate") == null ||
      pageContext.getRawParameter("invoiceDate").equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14104",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      invoiceDate.setValue(pageContext, "");
    }


    // �v����`�F�b�N
    OAMessageDateFieldBean glDate =
      (OAMessageDateFieldBean)webBean.findChildRecursive("glDate");

    if (pageContext.getRawParameter("glDate") == null || 
      pageContext.getRawParameter("glDate").equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14105",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      glDate.setValue(pageContext, "");
    }

    // �x���O���[�v�`�F�b�N
    OAMessageLovInputBean payGroupLookupName =
      (OAMessageLovInputBean)webBean.findChildRecursive("payGroupLookupName");
    OAFormValueBean payGroupLookupCode =
      (OAFormValueBean)webBean.findChildRecursive("payGroupLookupCode");

    // 2005.02.15 Modify Start
    //if (pageContext.getRawParameter("payGroupLookupName") == null ||
    //  pageContext.getRawParameter("payGroupLookupName").equals(""))
    // payGroupLookupCode��NULL�`�F�b�N����
    if (pageContext.getRawParameter("payGroupLookupName") == null ||
      pageContext.getRawParameter("payGroupLookupName").equals("") ||
      pageContext.getRawParameter("payGroupLookupCode") == null ||
      pageContext.getRawParameter("payGroupLookupCode").equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14106",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      payGroupLookupName.setValue(pageContext,
                                  pageContext.getRawParameter("payGroupLookupName"));
      //      payGroupLookupName.setValue(pageContext,"");
      payGroupLookupCode.setValue(pageContext,"");
    }
    else
    {
      payGroupLookupName.setValue(pageContext,
                                  pageContext.getRawParameter("payGroupLookupName"));
      payGroupLookupCode.setValue(pageContext,
                                  pageContext.getRawParameter("payGroupLookupCode"));
    }


    // �x�������`�F�b�N 
    OAMessageLovInputBean termsName = 
      (OAMessageLovInputBean)webBean.findChildRecursive("termsName");
    OAFormValueBean termsId =
      (OAFormValueBean)webBean.findChildRecursive("termsId");

    if (pageContext.getRawParameter("termsName") == null ||
      pageContext.getRawParameter("termsName").equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14107",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      termsName.setValue(pageContext,"");
      termsId.setValue(pageContext,"");
    }
    else
    {
      termsName.setValue(pageContext,
                         pageContext.getRawParameter("termsName"));
      termsId.setValue(pageContext,
                       pageContext.getRawParameter("termsId"));
    }


    // �ʉ݃`�F�b�N 
    OAMessageLovInputBean invoiceCurrencyCode =
      (OAMessageLovInputBean)webBean.findChildRecursive("invoiceCurrencyCode");
    String currencyCode = pageContext.getRawParameter("invoiceCurrencyCode");
    if ( currencyCode == null || currencyCode.equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14108",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      invoiceCurrencyCode.setValue(pageContext,"");
    }
    else
    {
      // 2005.02.17 Modify start
      //invoiceCurrencyCode.setValue(pageContext, currencyCode);

      // �ʉ݃R�[�h�����������ǂ������`�F�b�N����
      Serializable currencyCheckResult = am.invokeMethod("ValideteCurrencyCode"
                                                    ,new Serializable[]{currencyCode});
      if ( currencyCheckResult == "Y")
      {
        invoiceCurrencyCode.setValue(pageContext, currencyCode);
      } else
      {
        errFlag = true;

        excep = new OAException("XX03",
                                "APP-XX03-14108",
                                null,
                                OAException.ERROR,
                                null);

        errVec.addElement(excep);
        invoiceCurrencyCode.setValue(pageContext, currencyCode);
        //        invoiceCurrencyCode.setValue(pageContext,"");
      }
      // 2005.02.17 Modify end
    }

    // Exception���܂Ƃ߂ďo�� 
    if (errFlag)
    {
      throw OAException.getBundledOAException(errVec);
    }
  }

  /**
   * �x�����׍��ڂ̕K�{�`�F�b�N���s��
   * @param webBean the web bean corresponding to the region
   * @param pageContext the current OA page context
   * @param calcFlag ����Ōv�Z���̂�'Y'/���̑���'N'
   */
  public void doLineCheck  (OAWebBean webBean, OAPageContext pageContext, String calcFlag)
  {
    // 2005.05.18 Ver11.5.10.1.2 Add Start
    // am���`(�ʉ݃`�F�b�N�p)
    OAApplicationModule am = pageContext.getRootApplicationModule();
    // 2005.05.18 Ver11.5.10.1.2 Add End

    Vector errVec = new Vector();

    // �G���[���݃`�F�b�N�t���O 
    boolean errFlag = false;
    // Exception 
    OAException excep = null;

    //ver 11.5.10.2.10 Add Start
    // AM����̕Ԃ�l��String�ɕϊ����Ď擾����ϐ�
    String strResult = null;
    //ver 11.5.10.2.10 Add End

    // �E�v�R�[�h 
    OAMessageLovInputBean slipLineTypeName =
      (OAMessageLovInputBean)webBean.findChildRecursive("slipLineTypeName");
    OAFormValueBean slipLineType =
      (OAFormValueBean)webBean.findChildRecursive("slipLineType");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("slipLineTypeName") == null ||
    //  pageContext.getRawParameter("slipLineTypeName").equals(""))
    if (pageContext.getRawParameter("slipLineTypeName") == null ||
        pageContext.getRawParameter("slipLineTypeName").equals("") ||
        pageContext.getRawParameter("slipLineType") == null ||
        pageContext.getRawParameter("slipLineType").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14109",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      slipLineTypeName.setValue(pageContext,
                                pageContext.getRawParameter("slipLineTypeName"));
      //      slipLineTypeName.setValue(pageContext, "");
      slipLineType.setValue(pageContext, "");
    }
    else
    {
      slipLineTypeName.setValue(pageContext,
                                pageContext.getRawParameter("slipLineTypeName"));
      slipLineType.setValue(pageContext,
                                pageContext.getRawParameter("slipLineType"));
    }


    // ���͋��z 
    OAWebBeanTextInput enteredAmount =
      (OAWebBeanTextInput)webBean.findChildRecursive("enteredAmount");

    if (pageContext.getRawParameter("enteredAmount") == null ||
      pageContext.getRawParameter("enteredAmount").equals(""))
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14110",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      enteredAmount.setValue(pageContext, "");
    }


    // �ŋ敪 
    OAMessageLovInputBean taxName =
      (OAMessageLovInputBean)webBean.findChildRecursive("taxName");
    OAFormValueBean taxCode =
      (OAFormValueBean)webBean.findChildRecursive("taxCode");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("taxName") == null ||
    //  pageContext.getRawParameter("taxName").equals(""))
    if (pageContext.getRawParameter("taxName") == null ||
        pageContext.getRawParameter("taxName").equals("") ||
        pageContext.getRawParameter("taxCode") == null ||
        pageContext.getRawParameter("taxCode").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;

      excep = new OAException("XX03",
                              "APP-XX03-14111",
                              null,
                              OAException.ERROR,
                              null);

      errVec.addElement(excep);
      taxName.setValue(pageContext,
                       pageContext.getRawParameter("taxName"));
      //      taxName.setValue(pageContext, "");
      taxCode.setValue(pageContext, "");
    }
    else
    {
      taxName.setValue(pageContext,
                       pageContext.getRawParameter("taxName"));
      taxCode.setValue(pageContext,
                       pageContext.getRawParameter("taxCode"));
      //Ver11.5.10.1.6 2005/12/26 Add Start
      Serializable apTaxCodeCheckResult = am.invokeMethod("apValideteTaxCode"
                     ,new Serializable[]{ pageContext.getRawParameter("taxName")
                                         ,pageContext.getRawParameter("taxCode")});
      //ver 11.5.10.2.10 Chg Start
      strResult = apTaxCodeCheckResult.toString();
      if (strResult.equals("Y"))
      //if ( apTaxCodeCheckResult == "Y")
      //ver 11.5.10.2.10 Chg End
      {
      //Ver11.5.10.1.6 2005/12/26 Add End

    // 2005/08/08 Ver11.5.10.1.4 MODIFY Start
    // else�̕��J�b�R�̈ʒu���ρB����if���̉��Ɉړ�
    //}
    // 2005/05/18 Ver11.5.10.1.2 ADD Start
    // �ŃR�[�h�ƌv�Z���x���̊֌W�����������ǂ����𒲂ׂ�
      Serializable taxCodeCheckResult = am.invokeMethod("ValideteTaxCode"
                     ,new Serializable[]{pageContext.getRawParameter("taxCode")});

      //ver 11.5.10.2.10 Chg Start
      strResult = taxCodeCheckResult.toString();
      if (!strResult.equals("Y"))
      {
        errFlag = true;

        excep = new OAException("XX03",
                                "APP-XX03-12503",
                                null,
                                OAException.ERROR,
                                null);

        errVec.addElement(excep);
      }
      //if ( taxCodeCheckResult == "Y")
      //{
      //  taxName.setValue(pageContext,
      //                   pageContext.getRawParameter("taxName"));
      //  taxCode.setValue(pageContext,
      //                   pageContext.getRawParameter("taxCode"));
      //} else
      //{
      //  errFlag = true;
      //
      //  excep = new OAException("XX03",
      //                          "APP-XX03-12503",
      //                          null,
      //                          OAException.ERROR,
      //                          null);
      //
      //  errVec.addElement(excep);
      //  taxName.setValue(pageContext,
      //                   pageContext.getRawParameter("taxName"));
      //  taxCode.setValue(pageContext, "");
      //}
      //ver 11.5.10.2.10 Chg End

      //Ver11.5.10.1.6 2005/12/26 Add Start
      } else
      {
        errFlag = true;

        excep = new OAException("XX03",
                                "APP-XX03-14111",
                                null,
                                OAException.ERROR,
                                null);

        errVec.addElement(excep);
        //ver 11.5.10.2.10 Del Start
        //taxName.setValue(pageContext,
        //                 pageContext.getRawParameter("taxName"));
        //taxCode.setValue(pageContext, "");
        //ver 11.5.10.2.10 Del End
      }
      //Ver11.5.10.1.6 2005/12/26 Add End
      
    // 2005/05/18 Ver11.5.10.1.2 ADD End
    //���else�̕��J�b�R���ړ�
    }
    // 2005/08/08 Ver11.5.10.1.4 MODIFY End
    // 2004.04.02 Delete Start
    //    // �{�̋��z 
    //    OAWebBeanStyledText enteredItemAmount =
    //      (OAWebBeanStyledText)webBean.findChildRecursive("enteredItemAmount");
    //
    //    // ����Ōv�Z���͎��s���Ȃ� 
    //    if (calcFlag.equals("N"))
    //    {
    //      if (enteredItemAmount.getValue(pageContext) == null ||
    //        enteredItemAmount.getValue(pageContext).equals(""))
    //      {
    //        errFlag = true;
    //
    //        excep = new OAException("XX03",
    //                                "APP-XX03-14112",
    //                                null,
    //                                OAException.ERROR,
    //                                null);
    //
    //        errVec.addElement(excep);
    //        enteredItemAmount.setValue(pageContext, "");
    //      }
    //    }
    // 2004.04.02 Delete End

    // ����Ŋz 
    OAWebBeanTextInput enteredTaxAmount =
      (OAWebBeanTextInput)webBean.findChildRecursive("enteredTaxAmount");

    // ����Ōv�Z���͎��s���Ȃ� 
    if (calcFlag.equals("N"))
    {
      if (pageContext.getRawParameter("enteredTaxAmount") == null ||
        pageContext.getRawParameter("enteredTaxAmount").equals(""))
      {
        errFlag = true;

        excep = new OAException("XX03",
                                "APP-XX03-14113",
                                null,
                                OAException.ERROR,
                                null);

        errVec.addElement(excep);
        enteredTaxAmount.setValue(pageContext, "");
      }
    }


    // ��� 
    OAMessageLovInputBean segment1Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment1Name");
    OAFormValueBean segment1 =
      (OAFormValueBean)webBean.findChildRecursive("segment1");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment1Name") == null ||
    //    pageContext.getRawParameter("segment1Name").equals(""))
    if (pageContext.getRawParameter("segment1Name") == null ||
        pageContext.getRawParameter("segment1Name").equals("") ||
        pageContext.getRawParameter("segment1") == null ||
        pageContext.getRawParameter("segment1").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment1Prompt = segment1Name.getPrompt();
      if(segment1Prompt == null || segment1Prompt.equals(""))
      {
        segment1Prompt = "SEGMENT1";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT1", segment1Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14114",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment1Name.setValue(pageContext,
                            pageContext.getRawParameter("segment1Name"));
      //      segment1Name.setValue(pageContext, "");
      segment1.setValue(pageContext, "");
    }
    else
    {
      segment1Name.setValue(pageContext,
                            pageContext.getRawParameter("segment1Name"));
      segment1.setValue(pageContext,
                        pageContext.getRawParameter("segment1"));
    }


    // ���� 
    OAMessageLovInputBean segment2Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment2Name");
    OAFormValueBean segment2 =
      (OAFormValueBean)webBean.findChildRecursive("segment2");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment2Name") == null ||
    //  pageContext.getRawParameter("segment2Name").equals(""))
    if (pageContext.getRawParameter("segment2Name") == null ||
        pageContext.getRawParameter("segment2Name").equals("") ||
        pageContext.getRawParameter("segment2") == null ||
        pageContext.getRawParameter("segment2").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment2Prompt = segment2Name.getPrompt();
      if(segment2Prompt == null || segment2Prompt.equals(""))
      {
        segment2Prompt = "SEGMENT2";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT2", segment2Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14115",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment2Name.setValue(pageContext,
                            pageContext.getRawParameter("segment2Name"));
      //      segment2Name.setValue(pageContext, "");
      segment2.setValue(pageContext, "");
    }
    else
    {
      segment2Name.setValue(pageContext,
                            pageContext.getRawParameter("segment2Name"));
      segment2.setValue(pageContext,
                        pageContext.getRawParameter("segment2"));
    }


    // ����Ȗ� 
    OAMessageLovInputBean segment3Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment3Name");
    OAFormValueBean segment3 =
      (OAFormValueBean)webBean.findChildRecursive("segment3");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment3Name") == null ||
    //  pageContext.getRawParameter("segment3Name").equals(""))
    if (pageContext.getRawParameter("segment3Name") == null ||
        pageContext.getRawParameter("segment3Name").equals("") ||
        pageContext.getRawParameter("segment3") == null ||
        pageContext.getRawParameter("segment3").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment3Prompt = segment3Name.getPrompt();
      if(segment3Prompt == null || segment3Prompt.equals(""))
      {
        segment3Prompt = "SEGMENT3";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT3", segment3Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14116",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment3Name.setValue(pageContext,
                            pageContext.getRawParameter("segment3Name"));
      //      segment3Name.setValue(pageContext, "");
      segment3.setValue(pageContext, "");
    }
    else
    {
      segment3Name.setValue(pageContext,
                            pageContext.getRawParameter("segment3Name"));
      segment3.setValue(pageContext,
                            pageContext.getRawParameter("segment3"));
    }


    // �⏕�Ȗ� 
    OAMessageLovInputBean segment4Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment4Name");
    OAFormValueBean segment4 =
      (OAFormValueBean)webBean.findChildRecursive("segment4");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment4Name") == null ||
    //  pageContext.getRawParameter("segment4Name").equals(""))
    if (pageContext.getRawParameter("segment4Name") == null ||
        pageContext.getRawParameter("segment4Name").equals("") ||
        pageContext.getRawParameter("segment4") == null ||
        pageContext.getRawParameter("segment4").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment4Prompt = segment4Name.getPrompt();
      if(segment4Prompt == null || segment4Prompt.equals(""))
      {
        segment4Prompt = "SEGMENT4";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT4", segment4Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14117",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment4Name.setValue(pageContext,
                            pageContext.getRawParameter("segment4Name"));
      //      segment4Name.setValue(pageContext, "");
      segment4.setValue(pageContext, "");
    }
    else
    {
      segment4Name.setValue(pageContext,
                            pageContext.getRawParameter("segment4Name"));
      segment4.setValue(pageContext,
                            pageContext.getRawParameter("segment4"));
    }


    // ����� 
    OAMessageLovInputBean segment5Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment5Name");
    OAFormValueBean segment5 =
      (OAFormValueBean)webBean.findChildRecursive("segment5");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment5Name") == null ||
    //  pageContext.getRawParameter("segment5Name").equals(""))
    if (pageContext.getRawParameter("segment5Name") == null ||
        pageContext.getRawParameter("segment5Name").equals("") ||
        pageContext.getRawParameter("segment5") == null ||
        pageContext.getRawParameter("segment5").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment5Prompt = segment5Name.getPrompt();
      if(segment5Prompt == null || segment5Prompt.equals(""))
      {
        segment5Prompt = "SEGMENT5";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT5", segment5Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14118",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment5Name.setValue(pageContext,
                            pageContext.getRawParameter("segment5Name"));
      //      segment5Name.setValue(pageContext, "");
      segment5.setValue(pageContext, "");
    }
    else
    {
      segment5Name.setValue(pageContext,
                            pageContext.getRawParameter("segment5Name"));
      segment5.setValue(pageContext,
                            pageContext.getRawParameter("segment5"));
    }


    // ���Ƌ敪 
    OAMessageLovInputBean segment6Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment6Name");
    OAFormValueBean segment6 =
      (OAFormValueBean)webBean.findChildRecursive("segment6");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment6Name") == null ||
    //  pageContext.getRawParameter("segment6Name").equals(""))
    if (pageContext.getRawParameter("segment6Name") == null ||
        pageContext.getRawParameter("segment6Name").equals("") ||
        pageContext.getRawParameter("segment6") == null ||
        pageContext.getRawParameter("segment6").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment6Prompt = segment6Name.getPrompt();
      if(segment6Prompt == null || segment6Prompt.equals(""))
      {
        segment6Prompt = "SEGMENT6";
      }    
      MessageToken token = new MessageToken("TOK_SEGMENT6", segment6Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14119",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment6Name.setValue(pageContext,
                            pageContext.getRawParameter("segment6Name"));
      //      segment6Name.setValue(pageContext, "");
      segment6.setValue(pageContext, "");
    }
    else
    {
      segment6Name.setValue(pageContext,
                            pageContext.getRawParameter("segment6Name"));
      segment6.setValue(pageContext,
                            pageContext.getRawParameter("segment6"));
    }

    // �v���W�F�N�g 
    OAMessageLovInputBean segment7Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment7Name");
    OAFormValueBean segment7 =
      (OAFormValueBean)webBean.findChildRecursive("segment7");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment7Name") == null ||
    //  pageContext.getRawParameter("segment7Name").equals(""))
    if (pageContext.getRawParameter("segment7Name") == null ||
        pageContext.getRawParameter("segment7Name").equals("") ||
        pageContext.getRawParameter("segment7") == null ||
        pageContext.getRawParameter("segment7").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment7Prompt = segment7Name.getPrompt();
      if(segment7Prompt == null || segment7Prompt.equals(""))
      {
        segment7Prompt = "SEGMENT7";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT7", segment7Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-14120",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment7Name.setValue(pageContext,
                            pageContext.getRawParameter("segment7Name"));
      //      segment7Name.setValue(pageContext, "");
      segment7.setValue(pageContext, "");
    }
    else
    {
      segment7Name.setValue(pageContext,
                            pageContext.getRawParameter("segment7Name"));
      segment7.setValue(pageContext,
                            pageContext.getRawParameter("segment7"));
    }

    // 2005.02.09AFF�g���Ή�(Segment8�\���Ή�) start
    // �\��1
    OAMessageLovInputBean segment8Name =
      (OAMessageLovInputBean)webBean.findChildRecursive("segment8Name");
    OAFormValueBean segment8 =
      (OAFormValueBean)webBean.findChildRecursive("segment8");

    // 2005.02.17 Modify Start
    // ���̂����łȂ��A�R�[�h��NULL�`�F�b�N�̑ΏۂƂ���
    //if (pageContext.getRawParameter("segment8Name") == null ||
    //  pageContext.getRawParameter("segment8Name").equals(""))
    if (pageContext.getRawParameter("segment8Name") == null ||
        pageContext.getRawParameter("segment8Name").equals("") ||
        pageContext.getRawParameter("segment8") == null ||
        pageContext.getRawParameter("segment8").equals(""))
    // 2005.02.17 Modify End
    {
      errFlag = true;
      // Ver1.7 change start ------------------------------------------------------
      String segment8Prompt = segment8Name.getPrompt();
      
      if(segment8Prompt == null || segment8Prompt.equals(""))
      {
        segment8Prompt = "SEGMENT8";
      }
      MessageToken token = new MessageToken("TOK_SEGMENT8", segment8Prompt);
      MessageToken[] tokens = new MessageToken[] {token};
      excep = new OAException("XX03",
                              "APP-XX03-12500",
                              tokens,
                              OAException.ERROR,
                              null);
      // Ver1.7 change end --------------------------------------------------------
      errVec.addElement(excep);
      segment8Name.setValue(pageContext,
                            pageContext.getRawParameter("segment8Name"));
      //      segment8Name.setValue(pageContext, "");
      segment8.setValue(pageContext, "");
    }
    else
    {
      segment8Name.setValue(pageContext,
                            pageContext.getRawParameter("segment8Name"));
      segment8.setValue(pageContext,
                            pageContext.getRawParameter("segment8"));
    }
    // 2005.02.09AFF�g���Ή�(Segment8�\���Ή�) end


    // �`�F�b�N�͂��Ȃ����A�l�̖��ߍ��� 
    // �������R 
    OAMessageLovInputBean incrDecrReasonName =
      (OAMessageLovInputBean)webBean.findChildRecursive("incrDecrReasonName");
    OAFormValueBean incrDecrReasonCode =
      (OAFormValueBean)webBean.findChildRecursive("incrDecrReasonCode");

    if (pageContext.getRawParameter("incrDecrReasonName") == null ||
      pageContext.getRawParameter("incrDecrReasonName").equals(""))
    {
      incrDecrReasonName.setValue(pageContext, "");
      incrDecrReasonCode.setValue(pageContext, "");
    }
    else
    {
      incrDecrReasonName.setValue(pageContext,
                                  pageContext.getRawParameter("incrDecrReasonName"));
      incrDecrReasonCode.setValue(pageContext,
                                  pageContext.getRawParameter("incrDecrReasonCode"));
    }


    // Exception���܂Ƃ߂ďo�� 
    if (errFlag)
    {
      throw OAException.getBundledOAException(errVec);
    }
  }
}
