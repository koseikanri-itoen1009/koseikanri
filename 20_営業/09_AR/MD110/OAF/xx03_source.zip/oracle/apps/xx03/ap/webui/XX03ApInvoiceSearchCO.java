/*===========================================================================
 * Copyright (c) Oracle Corporation 2004 - 2005. All rights reserved.
 * FILENAME XX03ApInvoiceSearchCO.java
 * VERSION  11.5.10.1.6B
 * Date     2006/02/02
 * HISTORY  2004/02/08  Ver1.0          �V�K�쐬
 *          2004/02/13  Ver1.1          ���t���̓`�F�b�N�̃R�[�h�C��
 *          2004/03/29  Ver1.2          �g�p���Ȃ�import���̍폜
 *          2004/04/09  Ver1.3          �R�[�h�̈ړ�
 *          2004/04/27  Ver1.4          �m�F��ʂ���u�߂�v�{�^���őJ�ڂ��ꂽ
 *                                      �ꍇ�̉�ʐ����ǉ�
 *          2004/05/21  Ver1.5          �o�����F���ɍs�����ʃG���[�`�F�b�N�@�\�̒ǉ�
 *          2005/03/04  Ver1.6          AFFDFF�擾�����ǉ�
 *          2005/04/12  Ver11.5.10.1.0  HEADER��DFF�v�����v�g�擾�����ǉ�
 *          2006/01/30  Ver11.5.10.1.6  ������ʂ̉�ʑJ�ڕύX�Ή�
 *          2006/02/02  Ver11.5.10.1.6B �{�^���̃_�u���N���b�N�Ή�
 *          2006/10/13  Ver11.5.10.2.6  �o���C�����o�R���Ė߂����ۂ̃p�����[�^�̍폜�ǉ�
 *===========================================================================*/
package oracle.apps.xx03.ap.webui;

import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import java.text.DateFormat;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OADefaultDoubleColumnBean;
import oracle.apps.fnd.framework.webui.beans.layout.OADefaultSingleColumnBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASeparatorBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASpacerBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
//2004.03.29 delete Start
//import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
//2004.03.29 delete End
import oracle.apps.fnd.framework.webui.beans.table.OATableBean;
//2004.04.27 add start
import oracle.apps.fnd.framework.webui.beans.layout.OADefaultHideShowBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.jbo.domain.Date;
//2004.04.27 add end

// Ver1.6 add start ---------------------------------------------------------
import java.util.ArrayList;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
// Ver1.6 add end -----------------------------------------------------------
// 2005.04.12 Ver11.5.10.1.0 Add Start
import oracle.apps.fnd.framework.webui.beans.OAWebBeanStyledText;
// 2005.04.12 Ver11.5.10.1.0 Add End
//Ver11.5.10.1.6 Add Start
import oracle.apps.xx03.util.Xx03CommonUtil;
import java.sql.SQLException;
//Ver11.5.10.1.6 Add End

//ver11.5.10.1.6B Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6B Add End

/**
 * Controller for ...
 */
public class XX03ApInvoiceSearchCO extends OAControllerImpl
{
  public static final String RCS_ID=
    "$Header$: XX03ApInvoiceSearchCO.java 2004/03/08";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.ap.webui");

  public OARawTextBean message;
  public OADefaultSingleColumnBean conditionRN;
  public OASeparatorBean separator1;
  public OASpacerBean spacer1;
  public OATableBean approverResult;
  public OATableBean approveConfirm;
  public OATableBean resultInvoice;
  public OADefaultDoubleColumnBean deleteConfirm;
  public OADefaultDoubleColumnBean approve;
  //2004.04.27 add start
  public OADefaultHideShowBean searchShow;
  public OADefaultHideShowBean detailShow;
  //2004.04.27 add end
  
  public static final String ITEM_MSG = "message";
  public static final String ITEM_CONDITION_RN = "ConditionRN";
  public static final String ITEM_SEPARATOR = "separator1";
  public static final String ITEM_SPACE = "spacer1";
  public static final String ITEM_APP_RESULT = "XX03ApproverResult";
  public static final String ITEM_APP_COMFIRM = "XX03ApproveConfirm";
  public static final String ITEM_RESULT_INVOICE = "XX03ResultInvoice";
  public static final String ITEM_DELETE_CONFIRM = "deleteConfirm";
  public static final String ITEM_APPROVE = "approve";
  public static final String ITEM_STATUS = "WfStatusS";
  public static final String ITEM_APP_BTN = "approveBtn";
  public static final String ITEM_APP_YES = "approveYes";
  public static final String ITEM_APP_NO = "approveNo";
  public static final String ITEM_SEARCH_KIND = "searchKind";
  public static final String ITEM_DEL_INVOICE_ID = "delInvoiceId";
  public static final String ITEM_DEL_INVOICE_NUM = "delInvoiceNum";
  public static final String ITEM_INVOICE_DATE_S = "InvoiceDateStart";
  public static final String ITEM_INVOICE_DATE_E = "InvoiceDateEnd";
  public static final String ITEM_ENTORY_DATE_S = "EntoryDateStart";
  public static final String ITEM_ENTORY_DATE_E = "EntoryDateEnd";
  public static final String ITEM_GL_DATE_S = "GlDateStart";
  public static final String ITEM_GL_DATE_E = "GlDateEnd";
  public static final String ITEM_TERMS_DATE_S = "TermsDateStart";
  public static final String ITEM_TERMS_DATE_E = "TermsDateEnd";

  public static final String PARAM_SEARCH = "search";
  public static final String PARAM_APPROVE_SEARCH = "approverSearch";
  public static final String PARAM_NO_APPROVE = "noApprover";
  public static final String PARAM_APPROVE = "approve";
  public static final String PARAM_INVOICE_NUM = "invoiceNum";
  public static final String PARAM_INVOICE_ID = "invoiceId";
  public static final String PARAM_SEARCH_KIND = "searchKind";
  public static final String PARAM_DEL_INVOICE_ID = "delInvoiceId";
  public static final String PARAM_PAGE_STATUS = "pageStatus";
  public static final String PARAM_FUNC_BTN = "funcButton";
  public static final String PARAM_TRANSACTION = "transaction";
  public static final String PARAM_ROW_COUNT = "rowCount";

  public static final String TRANS_RESULT = "result";
  public static final String TRANS_DEL_CONFIRM = "deleteConfirm";
  public static final String TRANS_DEL_OK = "deleteOK";
  public static final String TRANS_DEL_NG = "deleteNG";
  public static final String TRANS_BLANK = "";
  public static final String TRANS_APP_CONFIRM = "approveConfirm";
  public static final String TRANS_APP_OK = "approveOK";

  public static final String BTN_SEARCH = "SearchBtn";
  public static final String BTN_CONFIRM = "Confirm";
  public static final String BTN_APP_CONFIRM = "approveBtn";
  public static final String BTN_DEL_ICON = "datadelete";
  public static final String BTN_APP_YES = "approveYes";
  public static final String BTN_DEL_YES = "deleteYes";
  public static final String BTN_DEL_NO = "deleteNo";
  public static final String BTN_APP_NO = "approveNo";
  public static final String BTN_CREAR = "ClearBtn";

  public static final String METHOD_CREATE_ROW = "createSearchRow";
  public static final String METHOD_GET_INVOICE_RESULT = "getInvoiceResult";
  public static final String METHOD_SEARCH_APP = "searchApprove";
  public static final String METHOD_APP_TRANSACTION = "approveTransaction";
  public static final String METHOD_DEL_INVOICE = "deleteInvoice";

  public static final String VALUE_NO_APPLOVER = "noApprover";
  public static final String VALUE_APP_SEARCH = "approverSearch";
  public static final String VALUE_APP_WAITE_CODE = "60";
  public static final String VALUE_APP_NO_COUNT = "0";
  public static final String TRUE = "true";

  public static final String DISP_SEARCH = "XX03_APINVOICESEARCHPG";
  public static final String DISP_CONFIRM = "XX03_APINVOICECONFIRMPG";

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    
    //ver11.5.10.1.6B Add Start
    OAApplicationModule am = pageContext.getRootApplicationModule();
    //Ver11.5.10.2.6 add Start
    //�J�ڌ��p�����[�^���ݒ肳��Ă���ꍇ�͍폜����
    if(pageContext.getSessionValue("origPage") != null)
    {
      pageContext.removeSessionValue("origPage");
    }
    //Ver11.5.10.2.6 add End
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button
    
      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);      
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6B Add End
    
    // itemBean�̍쐬 
    // ���b�Z�[�W 
    message = (OARawTextBean)webBean.findChildRecursive(ITEM_MSG);
    // �������� 
    conditionRN = 
      (OADefaultSingleColumnBean)webBean.findChildRecursive(ITEM_CONDITION_RN);
    // �Z�p���[�^ 
    separator1 = (OASeparatorBean)webBean.findChildRecursive(ITEM_SEPARATOR);
    // �X�y�[�X 
    spacer1 = (OASpacerBean)webBean.findChildRecursive(ITEM_SPACE);
    // ���ʁi���F�p�j 
    approverResult = 
      (OATableBean)webBean.findChildRecursive(ITEM_APP_RESULT);
    // ���ʁi���F�C�m�F�p�j 
    approveConfirm = 
      (OATableBean)webBean.findChildRecursive(ITEM_APP_COMFIRM);
    // ���ʁi���[�U�����p�j 
    resultInvoice = (OATableBean)webBean.findChildRecursive(ITEM_RESULT_INVOICE);
    // �폜�m�F�{�^�� 
    deleteConfirm = 
      (OADefaultDoubleColumnBean)webBean.findChildRecursive(ITEM_DELETE_CONFIRM);
    // �ꊇ���F�A���F�A�߂�{�^�� 
    approve = 
      (OADefaultDoubleColumnBean)webBean.findChildRecursive(ITEM_APPROVE);

    // itemBean�̍쐬 
    // �X�e�[�^�X�̒l���Œ�ɂ��āA��ʔ�\���ɂ��� 
    OAMessageChoiceBean status = 
      (OAMessageChoiceBean)webBean.findChildRecursive(ITEM_STATUS);
    // �{�^���̕\����ύX���� 
    OASubmitButtonBean allApprove = 
      (OASubmitButtonBean)approve.findChildRecursive(ITEM_APP_BTN);
    OASubmitButtonBean approveYes = 
      (OASubmitButtonBean)approve.findChildRecursive(ITEM_APP_YES);
    OASubmitButtonBean approveNo = 
      (OASubmitButtonBean)approve.findChildRecursive(ITEM_APP_NO);

    //ver11.5.10.1.6B Del Start
    //OAApplicationModule am = pageContext.getRootApplicationModule();
    //ver11.5.10.1.6B Del End

    // ���j���[��������p���p�����[�^�����Z�b�g����A�C�e�� 
    OAFormValueBean searchKind = 
      (OAFormValueBean)webBean.findChildRecursive(ITEM_SEARCH_KIND);
    // �폜�̏ꍇ�A�폜����invoice ID���Z�b�g����A�C�e�� 
    OAFormValueBean delInvoiceId = 
      (OAFormValueBean)webBean.findChildRecursive(ITEM_DEL_INVOICE_ID);
    delInvoiceId.setValue(pageContext,null);
    OAFormValueBean delInvoiceNum = 
      (OAFormValueBean)webBean.findChildRecursive(ITEM_DEL_INVOICE_NUM);
    delInvoiceNum.setValue(pageContext,null);

    // Ver1.6 add start --------------------------------------------------------
    // ��������AFF,DFF�v�����v�g�ݒ�
    OAMessageLovInputBean linesDepartment = (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
    OAMessageLovInputBean linesAccountCode = (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
    OAWebBeanTextInput reconReference = (OAWebBeanTextInput)webBean.findChildRecursive("ReconReference");
    // 2005.04.12 Ver11.5.10.1.0 Add Start
    OAWebBeanTextInput VendorInvoiceNum = (OAWebBeanTextInput)webBean.findChildRecursive("VendorInvoiceNum");
    OAWebBeanStyledText VendorInvoiceNumA = (OAWebBeanStyledText)webBean.findChildRecursive("VendorInvoiceNumA");
    OAWebBeanStyledText VendorInvoiceNumC = (OAWebBeanStyledText)webBean.findChildRecursive("VendorInvoiceNumC");
    OAWebBeanStyledText VendorInvoiceNumR = (OAWebBeanStyledText)webBean.findChildRecursive("VendorInvoiceNumR");
    // 2005.04.12 Ver11.5.10.1.0 Add End
    ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptApSearch");
    String affSearchHeader = pageContext.getMessage("XX03", "APP-XX03-33503", null);
    linesDepartment.setPrompt(affSearchHeader + (String)affPromptInfo.get(1));
    linesAccountCode.setPrompt(affSearchHeader + (String)affPromptInfo.get(2));
    reconReference.setLabel(affSearchHeader + (String)affPromptInfo.get(9));
    // 2005.04.12 Ver11.5.10.1.0 Add Start
    VendorInvoiceNum.setLabel((String)affPromptInfo.get(10));
    VendorInvoiceNumA.setLabel((String)affPromptInfo.get(10));
    VendorInvoiceNumC.setLabel((String)affPromptInfo.get(10));
    VendorInvoiceNumR.setLabel((String)affPromptInfo.get(10));
    // 2005.04.12 Ver11.5.10.1.0 Add End
    // Ver1.6 add end ----------------------------------------------------------

    // ��ʕ\���ݒ�(�S�A�C�e�����\������\�����ʃG���[�ŕ\�������Ȃ�����) 
    unDispAll();

    String searchParam = null;
    String approveParam = null;
    String transaction = null;
    // �p�����[�^�̎擾 
    // ���� 
    searchParam = pageContext.getParameter(PARAM_SEARCH);
    // ���F 
    approveParam = pageContext.getParameter(PARAM_APPROVE_SEARCH);
    // �������e 
    transaction = pageContext.getParameter(PARAM_TRANSACTION);
   
    if (searchParam == null)
    {
      searchParam = "";
    }
    if (approveParam == null)
    {
      approveParam = "";
    }
    if (transaction == null)
    {
      transaction = "";
    }
   
    //Ver11.5.10.1.6 Add Start
    if("".equals(searchParam) && "".equals(approveParam))
    {
      searchParam=TRUE;
    }
    //Ver11.5.10.1.6 Add End

    // �����\���i�����j 
    if (searchParam.equals(TRUE))
    {
      // ���� 
      if (transaction.equals(TRANS_RESULT))
      {
        // ��ʐݒ� 
        result();

        // �B���t�B�[���h�ɒl�ݒ� 
        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);

        // ���������s���� 
        am.invokeMethod(METHOD_GET_INVOICE_RESULT);
      }
      // �폜�m�F��� 
      else if (transaction.equals(TRANS_DEL_CONFIRM))
      {
        // ��ʐݒ� 
        deleteConfirm();

        // �B���t�B�[���h�ɒl�ݒ� 
        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);


        String invoiceNum = pageContext.getParameter(PARAM_INVOICE_NUM);
        String invoiceId = pageContext.getParameter(PARAM_INVOICE_ID);

        delInvoiceId.setValue(pageContext,invoiceId);
        delInvoiceNum.setValue(pageContext,invoiceNum);
      
        pageContext.putParameter(PARAM_INVOICE_ID,invoiceId);

        // raw text�Ƀ��b�Z�[�W��ݒ肷�� 
        MessageToken msg = 
          new MessageToken("TOK_XX03_DELETE_SLIP",invoiceNum);
        OAException ex = new OAException("XX03","APP-XX03-34055",
                         new MessageToken[]{msg});
        ex.setApplicationModule(am);

        message.setText(ex.getMessage());
      }
      // �폜OK�|�|�폜�v���V�[�W���N�� 
      else if (transaction.equals(TRANS_DEL_OK))
      {
        // �p�����[�^���`�[�ԍ��̎擾 
        String invoiceNum = pageContext.getParameter(PARAM_INVOICE_NUM);
        String invoiceId = pageContext.getParameter(PARAM_INVOICE_ID);

        // ��ʐݒ� 
        result();

        //2004.04.09 add start
        // �B���t�B�[���h�ɒl�ݒ� 
        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);
        //2004.04.09 add end

        //2004.04.09 delete start
        //        // �폜����AM���\�b�h 
        //        Serializable[] param = new Serializable[]{invoiceId};
        //        Serializable[] returnValue = 
        //          new Serializable[]{am.invokeMethod(METHOD_DEL_INVOICE,param)};
        //        String errMsg = (String)returnValue[0];

        //        // �B���t�B�[���h�ɒl�ݒ� 
        //        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);
        //2004.04.09 delete end

        // �폜����AM���\�b�h 
        Serializable[] param = new Serializable[]{invoiceId};
        Serializable[] returnValue = 
          new Serializable[]{am.invokeMethod(METHOD_DEL_INVOICE,param)};
        //2004.04.09 add start
        String errMsg = (String)returnValue[0];
        //2004.04.09 add end

        // �Č������s�� 
        am.invokeMethod(METHOD_GET_INVOICE_RESULT);

        if (errMsg != null)
        {
          throw new OAException("XX03",
                                "APP-XX03-14999",
                                null,
                                OAException.ERROR,
                                null);
        }
        else
        {
          MessageToken msg = 
            new MessageToken("TOK_XX03_AP_DELETE",invoiceNum);
          throw new OAException("XX03","APP-XX03-14128",
            new MessageToken[]{msg},OAException.INFORMATION,null);
        }
      }
      // �폜NG�|�|���Ƃ̉�ʂ֖߂� 
      else if (transaction.equals(TRANS_DEL_NG))
      {
        // ��ʐݒ� 
        result();
        // �B���t�B�[���h�ɒl�ݒ� 
        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);
      }
      else if (transaction.equals(TRANS_BLANK))
      {
        // ��ʕ\���ݒ� 
        search();
        // �B���t�B�[���h�ɒl�ݒ� 
        searchKind.setValue(pageContext,VALUE_NO_APPLOVER);
      
        // ���Row���쐬���� 
        am.invokeMethod(METHOD_CREATE_ROW,new Serializable[]{PARAM_SEARCH});

        //2004.04.27 add start
        // �m�F��ʂ���A�u�߂�v�{�^�����������ꂽ��̉�ʐ��� 
        if (pageContext.getParameter("pageStatus") != null &&
            pageContext.getParameter("pageStatus").equals("confirm"))
        {
          // ��ʕ\���̐��� 
          result();

          // Row�ɁA�p�����[�^����󂯎�����l���Z�b�g���� 
          setSearchItem(pageContext,webBean);

          // �Č������s�� 
          am.invokeMethod(METHOD_GET_INVOICE_RESULT);
          //Ver11.5.10.1.6 Add Start
          String messageSpecified=pageContext.getParameter("messages");
          if(null!=messageSpecified && !"".equals(messageSpecified))
          {
            pageContext.putDialogMessage(Xx03CommonUtil.stringToBundledOAException(messageSpecified));
          }
          //Ver11.5.10.1.6 Add End
        }
        //2004.04.27 add end
        //Ver11.5.10.1.6 Add Start
        removeSearchItem(pageContext);
        //Ver11.5.10.1.6 Add End
      }
    }
    // �����\���i�o���ꊇ���F�j 
    else if (approveParam.equals(TRUE))
    {
      searchKind.setValue(pageContext,VALUE_APP_SEARCH);
      // �u�����v�{�^��,���F�m�F��ʂŁu�߂�v�{�^���������̉�ʐ��� 
      if (transaction.equals(TRANS_RESULT))
      {
        // ���[�W�����̕\���ύX 
        approveResult();
        allApprove.setRendered(true);
        approveYes.setRendered(false);
        approveNo.setRendered(false);
        status.setDefaultValue(VALUE_APP_WAITE_CODE);
        status.setDisabled(true);

        searchKind.setValue(pageContext,VALUE_APP_SEARCH);
        
        // ���������s���� 
        am.invokeMethod(METHOD_GET_INVOICE_RESULT);
      }
      // �ꊇ���F�m�F 
      else if (transaction.equals(TRANS_APP_CONFIRM))
      {
        // row count���p�����[�^���擾���� 
        String rowCount = pageContext.getParameter(PARAM_ROW_COUNT);

        // ���[�W�����̕\���ύX 
        approveConfirm();
        allApprove.setRendered(false);
        approveYes.setRendered(true);
        approveNo.setRendered(true);

        searchKind.setValue(pageContext,VALUE_APP_SEARCH);
      
        // raw text�Ƀ��b�Z�[�W��ݒ肷�� 
        MessageToken msg = 
          new MessageToken("TOK_XX03_APPLY_COUNT",rowCount.toString());
        OAException ex = new OAException("XX03","APP-XX03-34054",
                         new MessageToken[]{msg});
        ex.setApplicationModule(am);
        message.setText(ex.getMessage());       
      }
      // �ꊇ���FOK--���[�N�t���[�N�� 
      else if (transaction.equals(TRANS_APP_OK))
      {
        //2004.04.09 delete start
        //        // ���[�N�t���[���N��������AM���\�b�h 
        //        Serializable[] returnValue = 
        //          new Serializable[]{am.invokeMethod(METHOD_APP_TRANSACTION)};
        //
        //        // ���[�N�t���[���ŃG���[�����������ꍇ�́A�G���[���b�Z�[�W���擾����� 
        //        String errMsg = (String)returnValue[0];


        //        // �Č������s�� 
        //        am.invokeMethod(METHOD_GET_INVOICE_RESULT);
        //2004.04.09 delete end
        
        // ���[�W�����̕\���ύX 
        approveResult();
        allApprove.setRendered(true);
        approveYes.setRendered(false);
        approveNo.setRendered(false);
        status.setDisabled(true);

        searchKind.setValue(pageContext,VALUE_APP_SEARCH);

        //2004.04.09 add start
        // ���[�N�t���[���N��������AM���\�b�h 
        Serializable[] returnValue = 
          new Serializable[]{am.invokeMethod(METHOD_APP_TRANSACTION)};

        // ���[�N�t���[���ŃG���[�����������ꍇ�́A�G���[���b�Z�[�W���擾����� 
        String errMsg = (String)returnValue[0];

        // �Č������s�� 
        am.invokeMethod(METHOD_GET_INVOICE_RESULT);
        //2004.04.09 add end

        if (errMsg != null)
        {
          MessageToken msg = new MessageToken("TOK_XX03_APPROVE_ERR",errMsg);
          throw new OAException("XX03",
                                "APP-XX03-14141",
                                new MessageToken[]{msg},
                                OAException.ERROR,null);
        }
        else
        {
          throw new OAException
            ("XX03","APP-XX03-34056",null,OAException.INFORMATION,null);
        }
      }
      else if (transaction.equals(TRANS_BLANK))
      {
        // ��ʕ\���ݒ� 
        approverSearch();
        searchKind.setValue(pageContext,VALUE_APP_SEARCH);

        am.invokeMethod
          (METHOD_CREATE_ROW,new Serializable[]{PARAM_APPROVE_SEARCH});

        //2004.04.27 add start
        // �m�F��ʂ���A�u�߂�v�{�^�����������ꂽ��̉�ʐ��� 
        if (pageContext.getParameter("pageStatus") != null &&
            pageContext.getParameter("pageStatus").equals("confirm"))
        {
          // ��ʕ\���̐��� 
          approveResult();
          allApprove.setRendered(true);
          approveYes.setRendered(false);
          approveNo.setRendered(false);

          // Row�ɁA�p�����[�^����󂯎�����l���Z�b�g���� 
          setSearchItem(pageContext,webBean);

          // �Č������s�� 
          am.invokeMethod(METHOD_GET_INVOICE_RESULT);
        }
        //2004.04.27 add end
        
        status.setDefaultValue(VALUE_APP_WAITE_CODE);
        status.setDisabled(true);

      }
      //Ver11.5.10.1.6 Add Start
      removeSearchItem(pageContext);
      //Ver11.5.10.1.6 Add End
    }
    // �p�����[�^��������Ȃ��ꍇ 
    else
    {
      unDispAll();
      throw new OAException("XX03","APP-XX03-14999",null,OAException.ERROR,null);
    }

    //ver11.5.10.1.6B Add Start
    }
    //ver11.5.10.1.6B Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    OAApplicationModule am = pageContext.getRootApplicationModule();

    // �����{�^������ 
    if (pageContext.getParameter(BTN_SEARCH) != null)
    {
      //2004.3.18 delete start
      //      // ���t�A�C�e���̎擾 
      //      // ���������t�i���j 
      //      OAMessageDateFieldBean invoiceDS = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_INVOICE_DATE_S);
      //      String invoiceDateStart = (String)invoiceDS.getText(pageContext);
      //      // ���������t�i���j
      //      OAMessageDateFieldBean invoiceDE = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_INVOICE_DATE_E);
      //      String invoiceDateEnd = (String)invoiceDE.getText(pageContext);
      //      // �N�[���i���j 
      //      OAMessageDateFieldBean entoryDS = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_ENTORY_DATE_S);
      //      String entoryDateStart = (String)entoryDS.getText(pageContext);
      //      // �N�[���i���j 
      //      OAMessageDateFieldBean entoryDE = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_ENTORY_DATE_E);
      //      String entoryDateEnd = (String)entoryDE.getText(pageContext);
      //      //�v����i���j
      //      OAMessageDateFieldBean glDS = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_GL_DATE_S);
      //      String glDateStart = (String)glDS.getText(pageContext);
      //      // �v����i���j 
      //      OAMessageDateFieldBean glDE = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_GL_DATE_E);
      //      String glDateEnd = (String)glDE.getText(pageContext);
      //      // �x���\����i���j 
      //      OAMessageDateFieldBean termsDS = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_TERMS_DATE_S);
      //      String termsDateStart = (String)termsDS.getText(pageContext);
      //      // �x���\����i���j 
      //      OAMessageDateFieldBean termsDE = 
      //        (OAMessageDateFieldBean)webBean.findChildRecursive(ITEM_TERMS_DATE_E);
      //      String termsDateEnd = (String)termsDE.getText(pageContext);
      //
      //2004.3.18 delete End

      Vector vector = new Vector();

      //2004.3.18 delete start
      //      boolean err_flg = false;
      //
      //      // ���t�`�F�b�N 
      //      // ���������t 
      //      if (dateCheck(invoiceDateStart,invoiceDateEnd) == true)
      //      {
      //        err_flg = true;
      //
      //        OAException ex = new OAException
      //          ("XX03","APP-XX03-14137",null,OAException.ERROR,null);
      //
      //          vector.addElement(ex);
      //      }
      //      // �N�[�� 
      //      if (dateCheck(entoryDateStart,entoryDateEnd) == true)
      //      {
      //        err_flg = true;
      //
      //        OAException ex = new OAException
      //          ("XX03","APP-XX03-14138",null,OAException.ERROR,null);
      //        vector.addElement(ex);
      //      }
      //      // �v��� 
      //      if (dateCheck(glDateStart,glDateEnd) == true)
      //      {
      //        err_flg = true;
      //
      //        OAException ex = new OAException
      //          ("XX03","APP-XX03-14139",null,OAException.ERROR,null);
      //        vector.addElement(ex);
      //      }
      //      // �x���\��� 
      //      if(dateCheck(termsDateStart,termsDateEnd) == true)
      //      {
      //        err_flg = true;
      //
      //        OAException ex = new OAException
      //          ("XX03","APP-XX03-14140",null,OAException.ERROR,null);
      //        vector.addElement(ex);
      //      }
      //
      //      // ���t�`�F�b�N�ŃG���[�̏ꍇ��Exception 
      //      if (err_flg == true)
      //      {
      //        throw OAException.getBundledOAException(vector);
      //      }
      //2004.3.18 delete end

      //2004.3.18 add start
      // ���t�`�F�b�N��AM���\�b�h 
      Serializable[] returnValue = 
        new Serializable[]{am.invokeMethod("dateInputCheck")};
      vector = (Vector)returnValue[0];
      // �߂�l��null�ȊO�Ȃ�G���[���b�Z�[�W���o�͂��� 
      if (vector != null)
      {
        throw OAException.getBundledOAException(vector);
      }
      //2004.03.18 add end
      else
      {
        String kind = pageContext. getParameter(PARAM_SEARCH_KIND);

        // �o�����F�̏ꍇ�̃p�����[�^�Z�b�g 
        if (kind.equals(VALUE_APP_SEARCH))
        {
          pageContext.putParameter(PARAM_APPROVE_SEARCH,TRUE);
        }
        // �����̏ꍇ�̃p�����[�^�Z�b�g 
        else if (kind.equals(PARAM_NO_APPROVE))
        {

          pageContext.putParameter(PARAM_SEARCH,TRUE);
        }
        // �p�����[�^�ݒ� 
        pageContext.putParameter(PARAM_TRANSACTION,TRANS_RESULT);

        pageContext.setForwardURL(DISP_SEARCH,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  true, // Retain AM
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
    }
    // �m�F�{�^��(������͉�ʂ֑J�ڂ���) 
    else if (pageContext.getParameter(BTN_CONFIRM) != null)
    {
      //2004.04.27 add start
      // ���������̃A�C�e��Bean�𐶐�����B 
      //1.�N�[����
      OAMessageLovInputBean oaDepartment = 
        (OAMessageLovInputBean)webBean.findChildRecursive("Department");
      //2.�d����
      OAMessageLovInputBean oaVendorNames = 
        (OAMessageLovInputBean)webBean.findChildRecursive("VendorNames");
      //3.�`�[���͎�
      OAMessageLovInputBean oaEntryPersonName = 
        (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
      //4.�d���搿�����ԍ�
      OAMessageTextInputBean oaVendorInvoiceNum = 
        (OAMessageTextInputBean)webBean.findChildRecursive("VendorInvoiceNum");
      //5.�X�e�[�^�X
      OAMessageChoiceBean oaWfStatusS = 
        (OAMessageChoiceBean)webBean.findChildRecursive("WfStatusS");
      //6.���������t�i���j
      OAMessageDateFieldBean oaInvoiceDateStart = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateStart");
      //7.�`�[���
      OAMessageLovInputBean oaSlipTypeKind = 
        (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
      //8.���������t�i���j
      OAMessageDateFieldBean oaInvoiceDateEnd = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateEnd");
      //9.�`�[�ԍ�
      OAMessageTextInputBean oaInvoiceNumber = 
        (OAMessageTextInputBean)webBean.findChildRecursive("InvoiceNumber");
      //10.�N�[���i���j
      OAMessageDateFieldBean oaEntoryDateStart = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("EntoryDateStart");
      //11.���F��
      OAMessageLovInputBean oaApprover = 
        (OAMessageLovInputBean)webBean.findChildRecursive("Approver");
      //12.�N�[���i���j
      OAMessageDateFieldBean oaEntoryDateEnd = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("EntoryDateEnd");
      //13.�v����i���j
      OAMessageDateFieldBean oaGlDateStart = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
      //14.�x���O���[�v
      OAMessageLovInputBean oaPayGroupLookupCode = 
        (OAMessageLovInputBean)webBean.findChildRecursive("PayGroupLookupCode");
      //15.�v����i���j
      OAMessageDateFieldBean oaGlDateEnd = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
      //16.���ׁF����
      OAMessageLovInputBean oaLinesDepartment = 
        (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
      //17.�x���\����i���j
      OAMessageDateFieldBean oaTermsDateStart = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("TermsDateStart");
      //18.���ׁF����Ȗ�
      OAMessageLovInputBean oaLinesAccountCode = 
        (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
      //19.�x���\����i���j
      OAMessageDateFieldBean oaTermsDateEnd = 
        (OAMessageDateFieldBean)webBean.findChildRecursive("TermsDateEnd");
      //20.���ׁF�����Q��
      OAMessageTextInputBean oaReconReference = 
        (OAMessageTextInputBean)webBean.findChildRecursive("ReconReference");
      // 21.defaultSearch(������hideShow) 
      OADefaultHideShowBean searchShowItem = 
        (OADefaultHideShowBean)webBean.findChildRecursive("defaultSearch");
      // 22.details(�ڍׂ�hideShow) 
      OADefaultHideShowBean detailShowItem = 
        (OADefaultHideShowBean)webBean.findChildRecursive("details");  

      //Ver11.5.10.1.6 Add Start
      // �p�����[�^�̃Z�b�g(�l��null�ȊO�̏ꍇ�p�����[�^�Z�b�g) 
      // 1.�N�[���� 
      if(oaDepartment.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramDepartment",oaDepartment.getValue(pageContext));        
      }
      // 2.�d���� 
      if(oaVendorNames.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramVendorNames",oaVendorNames.getValue(pageContext));
      }
      // 3.�`�[���͎� 
      if(oaEntryPersonName.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramEntryPersonName",oaEntryPersonName.getValue(pageContext));
      }
      // 4.�d���搿�����ԍ� 
      if(oaVendorInvoiceNum.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramVendorInvoiceNum",oaVendorInvoiceNum.getValue(pageContext));
      }
      // 5.�X�e�[�^�X 
      if(oaWfStatusS.getSelectionValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramWfStatusS",oaWfStatusS.getSelectionValue(pageContext));
      }
      // 6.���������t�i���j 
      if(oaInvoiceDateStart.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramInvoiceDateStart",oaInvoiceDateStart.getValue(pageContext));
      }
      // 7.�`�[��� 
      if(oaSlipTypeKind.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramSlipTypeKind",oaSlipTypeKind.getValue(pageContext));
      }
      // 8.���������t�i���j 
      if(oaInvoiceDateEnd.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramInvoiceDateEnd",oaInvoiceDateEnd.getValue(pageContext));
      }
      // 9.�`�[�ԍ� 
      if(oaInvoiceNumber.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramInvoiceNumber",oaInvoiceNumber.getValue(pageContext));
      }
      // 10.�N�[���i���j 
      if(oaEntoryDateStart.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramEntoryDateStart",oaEntoryDateStart.getValue(pageContext));
      }
      // 11.���F�� 
      if(oaApprover.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramApprover",oaApprover.getValue(pageContext));
      }
      // 12.�N�[���i���j 
      if(oaEntoryDateEnd.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramEntoryDateEnd",oaEntoryDateEnd.getValue(pageContext));
      }
      // 13.�v����i���j 
      if(oaGlDateStart.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramGlDateStart",oaGlDateStart.getValue(pageContext));
      }
      // 14.�x���O���[�v 
      if(oaPayGroupLookupCode.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramPayGroupLookupCode",oaPayGroupLookupCode.getValue(pageContext));
      }
      // 15.�v����i���j 
      if(oaGlDateEnd.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramGlDateEnd",oaGlDateEnd.getValue(pageContext));
      }
      // 16.���ׁF���� 
      if(oaLinesDepartment.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramLinesDepartment",oaLinesDepartment.getValue(pageContext));
      }
      // 17.�x���\����i���j 
      if(oaTermsDateStart.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramTermsDateStart",oaTermsDateStart.getValue(pageContext));
      }
      // 18.���ׁF����Ȗ� 
      if(oaLinesAccountCode.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramLinesAccountCode",oaLinesAccountCode.getValue(pageContext));
      }
      // 19.�x���\����i���j 
      if(oaTermsDateEnd.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramTermsDateEnd",oaTermsDateEnd.getValue(pageContext));
      }
      // 20.���ׁF�����Q�� 
      if(oaReconReference.getValue(pageContext) != null)
      {
        pageContext.putTransientSessionValue
          ("paramReconReference",oaReconReference.getValue(pageContext));
      }
      // 21.�N�[����ID 
      if (pageContext.getParameter("DepartmentId") != null &&
          pageContext.getParameter("DepartmentId") != "")
      {
        pageContext.putTransientSessionValue("paramDepartmentId",
                                 pageContext.getParameter("DepartmentId"));
      }
      // 22.�`�[���ID 
      if (pageContext.getParameter("SlipTypeKindID") != null &&
          pageContext.getParameter("SlipTypeKindID") != "")
      {
        pageContext.putTransientSessionValue("paramSlipTypeKindID",
                                 pageContext.getParameter("SlipTypeKindID"));
      }
      // 23.���F��ID 
      if (pageContext.getParameter("ApproverId") != null &&
          pageContext.getParameter("ApproverId") != "")
      {
        pageContext.putTransientSessionValue("paramApproverId",
                                 pageContext.getParameter("ApproverId"));
      }
      // 24.�d����ID 
      if (pageContext.getParameter("VendorNameId") != null &&
          pageContext.getParameter("VendorNameId") != "")
      {
        pageContext.putTransientSessionValue("paramVendorNameId",
                                 pageContext.getParameter("VendorNameId"));
      }
      // 25.�`�[���͎�ID 
      if (pageContext.getParameter("EntryPersonId") != null &&
          pageContext.getParameter("EntryPersonId") != "")
      {
        pageContext.putTransientSessionValue("paramEntryPersonId",
                                 pageContext.getParameter("EntryPersonId"));
      }
      // 26.�x���O���[�vID 
      if (pageContext.getParameter("PayGroupLookupCodeId") != null &&
          pageContext.getParameter("PayGroupLookupCodeId") != "")
      {
        pageContext.putTransientSessionValue("paramPayGroupLookupCodeId",
                                 pageContext.getParameter("PayGroupLookupCodeId"));
      }
      // 27.���ׁF����R�[�h 
      if (pageContext.getParameter("LinesDepartmentId") != null &&
          pageContext.getParameter("LinesDepartmentId") != "")
      {
        pageContext.putTransientSessionValue("paramLinesDepartmentId",
                                 pageContext.getParameter("LinesDepartmentId"));
      }
      // 28.���ׁF����ȖڃR�[�h 
      if (pageContext.getParameter("LinesAccountCodeId") != null &&
          pageContext.getParameter("LinesAccountCodeId") != "")
      {
        pageContext.putTransientSessionValue("paramLinesAccountCodeId",
                                 pageContext.getParameter("LinesAccountCodeId"));
      }
      
      // �����A�ꊇ���F�𔻕ʂ��� 
      String kind = pageContext. getParameter(PARAM_SEARCH_KIND);
      // 30.�o�����F�̏ꍇ�̃p�����[�^�Z�b�g 
      if (kind.equals(VALUE_APP_SEARCH))
      {
        pageContext.putParameter("approverSearch",TRUE);
      }
      // 31.�����̏ꍇ�̃p�����[�^�Z�b�g 
      else if (kind.equals(PARAM_NO_APPROVE))
      {
        pageContext.putParameter("search",TRUE);
      }
      
      // 32.hide show(����)�̏�Ԃ��擾���� 
      if (searchShowItem.isDisclosed(pageContext) == true)
      {
        pageContext.putTransientSessionValue("searchShow","true");
      }
      else
      {
        pageContext.putTransientSessionValue("paramSearchShow","false");
      }
      // 33.hide show(�ڍ�)�̏�Ԃ��擾���� 
      if (detailShowItem.isDisclosed(pageContext) == true)
      {
        pageContext.putTransientSessionValue("paramDetailShow","true");
      }
      else
      {
        pageContext.putTransientSessionValue("paramDetailShow","false");
      }
      // 34.�����ԍ�(invoiceId) 

      //// �p�����[�^�̃Z�b�g(�l��null�ȊO�̏ꍇ�p�����[�^�Z�b�g) 
      //// 1.�N�[���� 
      //if(oaDepartment.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramDepartment",oaDepartment.getValue(pageContext));        
      //}
      //// 2.�d���� 
      //if(oaVendorNames.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramVendorNames",oaVendorNames.getValue(pageContext));
      //}
      //// 3.�`�[���͎� 
      //if(oaEntryPersonName.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramEntryPersonName",oaEntryPersonName.getValue(pageContext));
      //}
      //// 4.�d���搿�����ԍ� 
      //if(oaVendorInvoiceNum.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramVendorInvoiceNum",oaVendorInvoiceNum.getValue(pageContext));
      //}
      //// 5.�X�e�[�^�X 
      //if(oaWfStatusS.getSelectionValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramWfStatusS",oaWfStatusS.getSelectionValue(pageContext));
      //}
      //// 6.���������t�i���j 
      //if(oaInvoiceDateStart.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramInvoiceDateStart",oaInvoiceDateStart.getValue(pageContext));
      //}
      //// 7.�`�[��� 
      //if(oaSlipTypeKind.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramSlipTypeKind",oaSlipTypeKind.getValue(pageContext));
      //}
      //// 8.���������t�i���j 
      //if(oaInvoiceDateEnd.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramInvoiceDateEnd",oaInvoiceDateEnd.getValue(pageContext));
      //}
      //// 9.�`�[�ԍ� 
      //if(oaInvoiceNumber.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramInvoiceNumber",oaInvoiceNumber.getValue(pageContext));
      //}
      //// 10.�N�[���i���j 
      //if(oaEntoryDateStart.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramEntoryDateStart",oaEntoryDateStart.getValue(pageContext));
      //}
      //// 11.���F�� 
      //if(oaApprover.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramApprover",oaApprover.getValue(pageContext));
      //}
      //// 12.�N�[���i���j 
      //if(oaEntoryDateEnd.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramEntoryDateEnd",oaEntoryDateEnd.getValue(pageContext));
      //}
      //// 13.�v����i���j 
      //if(oaGlDateStart.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramGlDateStart",oaGlDateStart.getValue(pageContext));
      //}
      //// 14.�x���O���[�v 
      //if(oaPayGroupLookupCode.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramPayGroupLookupCode",oaPayGroupLookupCode.getValue(pageContext));
      //}
      //// 15.�v����i���j 
      //if(oaGlDateEnd.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramGlDateEnd",oaGlDateEnd.getValue(pageContext));
      //}
      //// 16.���ׁF���� 
      //if(oaLinesDepartment.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramLinesDepartment",oaLinesDepartment.getValue(pageContext));
      //}
      //// 17.�x���\����i���j 
      //if(oaTermsDateStart.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramTermsDateStart",oaTermsDateStart.getValue(pageContext));
      //}
      //// 18.���ׁF����Ȗ� 
      //if(oaLinesAccountCode.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramLinesAccountCode",oaLinesAccountCode.getValue(pageContext));
      //}
      //// 19.�x���\����i���j 
      //if(oaTermsDateEnd.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramTermsDateEnd",oaTermsDateEnd.getValue(pageContext));
      //}
      //// 20.���ׁF�����Q�� 
      //if(oaReconReference.getValue(pageContext) != null)
      //{
      //  pageContext.putParameter
      //    ("paramReconReference",oaReconReference.getValue(pageContext));
      //}
      //// 21.�N�[����ID 
      //if (pageContext.getParameter("DepartmentId") != null &&
      //    pageContext.getParameter("DepartmentId") != "")
      //{
      //  pageContext.putParameter("paramDepartmentId",
      //                           pageContext.getParameter("DepartmentId"));
      //}
      //// 22.�`�[���ID 
      //if (pageContext.getParameter("SlipTypeKindID") != null &&
      //    pageContext.getParameter("SlipTypeKindID") != "")
      //{
      //  pageContext.putParameter("paramSlipTypeKindID",
      //                           pageContext.getParameter("SlipTypeKindID"));
      //}
      //// 23.���F��ID 
      //if (pageContext.getParameter("ApproverId") != null &&
      //    pageContext.getParameter("ApproverId") != "")
      //{
      //  pageContext.putParameter("paramApproverId",
      //                           pageContext.getParameter("ApproverId"));
      //}
      //// 24.�d����ID 
      //if (pageContext.getParameter("VendorNameId") != null &&
      //    pageContext.getParameter("VendorNameId") != "")
      //{
      //  pageContext.putParameter("paramVendorNameId",
      //                           pageContext.getParameter("VendorNameId"));
      //}
      //// 25.�`�[���͎�ID 
      //if (pageContext.getParameter("EntryPersonId") != null &&
      //    pageContext.getParameter("EntryPersonId") != "")
      //{
      //  pageContext.putParameter("paramEntryPersonId",
      //                           pageContext.getParameter("EntryPersonId"));
      //}
      //// 26.�x���O���[�vID 
      //if (pageContext.getParameter("PayGroupLookupCodeId") != null &&
      //    pageContext.getParameter("PayGroupLookupCodeId") != "")
      //{
      //  pageContext.putParameter("paramPayGroupLookupCodeId",
      //                           pageContext.getParameter("PayGroupLookupCodeId"));
      //}
      //// 27.���ׁF����R�[�h 
      //if (pageContext.getParameter("LinesDepartmentId") != null &&
      //    pageContext.getParameter("LinesDepartmentId") != "")
      //{
      //  pageContext.putParameter("paramLinesDepartmentId",
      //                           pageContext.getParameter("LinesDepartmentId"));
      //}
      //// 28.���ׁF����ȖڃR�[�h 
      //if (pageContext.getParameter("LinesAccountCodeId") != null &&
      //    pageContext.getParameter("LinesAccountCodeId") != "")
      //{
      //  pageContext.putParameter("paramLinesAccountCodeId",
      //                           pageContext.getParameter("LinesAccountCodeId"));
      //}
      
      //// �����A�ꊇ���F�𔻕ʂ��� 
      //String kind = pageContext. getParameter(PARAM_SEARCH_KIND);
      //// 30.�o�����F�̏ꍇ�̃p�����[�^�Z�b�g 
      //if (kind.equals(VALUE_APP_SEARCH))
      //{
      //  pageContext.putParameter("approverSearch",TRUE);
      //}
      //// 31.�����̏ꍇ�̃p�����[�^�Z�b�g 
      //else if (kind.equals(PARAM_NO_APPROVE))
      //{
      //  pageContext.putParameter("search",TRUE);
      //}
      
      //// 32.hide show(����)�̏�Ԃ��擾���� 
      //if (searchShowItem.isDisclosed(pageContext) == true)
      //{
      //  pageContext.putParameter("searchShow","true");
      //}
      //else
      //{
      //  pageContext.putParameter("paramSearchShow","false");
      //}
      //// 33.hide show(�ڍ�)�̏�Ԃ��擾���� 
      //if (detailShowItem.isDisclosed(pageContext) == true)
      //{
      //  pageContext.putParameter("paramDetailShow","true");
      //}
      //else
      //{
      //  pageContext.putParameter("paramDetailShow","false");
      //}
      //// 34.�����ԍ�(invoiceId) 
      //Ver11.5.10.1.6 Add End
      //2004.04.27 add end

      String invoiceId = pageContext.getParameter(PARAM_INVOICE_ID);

      pageContext.putParameter(PARAM_INVOICE_ID,invoiceId);
      pageContext.putParameter(PARAM_PAGE_STATUS,"search");
      pageContext.putParameter(PARAM_FUNC_BTN,"confirm");

      //2004.04.27 Modify start
      // AM�����e�C�������ɑJ�ڂ��s�� 
      pageContext.setForwardURL(DISP_CONFIRM,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
      //                                true,
                                false,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
      //2004.04.27 Modify end
    }
    // �ꊇ���F�{�^�������������ꍇ�̏���(�f�[�^�i�荞�݁A�m�F��ʑJ��) 
    else if (pageContext.getParameter(BTN_APP_CONFIRM) != null)
    {
      String invoiceId = pageContext.getParameter(PARAM_INVOICE_ID);
      // 2004.05.24 Add Start
      // �`�F�b�N�̂���f�[�^�̍����ԍ����擾����
      Vector markedInvoiceVec = (Vector)am.invokeMethod("getMarkedInvoiceId");
      String checkElm = (String)markedInvoiceVec.firstElement();
      Vector excepVec = new Vector();
      if(!checkElm.equals("0")) 
      {
        Vector errCheckVec;
        for(int i=0; i<markedInvoiceVec.size() ;i++) 
        {
          // �G���[�`�F�b�N�֐� 
          errCheckVec = (Vector)am.invokeMethod("checkDeptInputAp",
            new Serializable[]{(String)markedInvoiceVec.elementAt(i)});

          // �G���[������ 
          if (!(errCheckVec.lastElement().toString().equals("normal")) &&
            !(errCheckVec.lastElement().toString().equals("warn")))
          {
            for(int j=0; j<errCheckVec.size() ;j++)
            {
              // ���������G���[�̂ݏW�߂�
              excepVec.addElement((OAException)errCheckVec.elementAt(j));
            }
          }
        }
        // �G���[���������Ă����throw 
        if(excepVec.size() >= 1)
        {
          throw OAException.getBundledOAException(excepVec);
        }
      }
      // 2004.05.24 Add End

      // �`�F�b�N�̂���f�[�^�̂ݍi���݂��s�� 
      Serializable[] returnObj = 
        new Serializable[]{am.invokeMethod(METHOD_SEARCH_APP)};
      Integer rowCount = (Integer)returnObj[0];

      // �o�����F���I������Ă��Ȃ��ꍇ�̓G���[ 
      if (rowCount.equals(new Integer(VALUE_APP_NO_COUNT)))
      {
        throw new OAException("XX03","APP-XX03-14136",null,OAException.ERROR,null);
      }

      // �p�����[�^�̃Z�b�g 
      pageContext.putParameter(PARAM_APPROVE_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_APP_CONFIRM);
      pageContext.putParameter(PARAM_INVOICE_ID,invoiceId);
      pageContext.putParameter(PARAM_ROW_COUNT,rowCount.toString());

      // ��ʑJ�� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // [�폜]�A�C�R���N���b�N�� 
    else if (pageContext.getParameter(BTN_DEL_ICON) != null)
    {
      String invoiceId = pageContext.getParameter(PARAM_INVOICE_ID);
      String invoiceNum = pageContext.getParameter(PARAM_INVOICE_NUM);

      // �p�����[�^�̃Z�b�g 
      pageContext.putParameter(PARAM_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_DEL_CONFIRM);
      pageContext.putParameter(PARAM_INVOICE_ID,invoiceId);
      pageContext.putParameter(PARAM_INVOICE_NUM,invoiceNum);

      // ��ʑJ�� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // ���F�m�F��AOK�{�^�����������ꂽ�ꍇ 
    else if (pageContext.getParameter(BTN_APP_YES) != null)
    {
      // �p�����[�^�̃Z�b�g 
      pageContext.putParameter(PARAM_APPROVE_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_APP_OK);

      // ��ʑJ�� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // �폜�m�F��AOK�{�^�������� 
    else if (pageContext.getParameter(BTN_DEL_YES) != null)
    {
      // invoiceId�̎擾 
      String invoiceId = pageContext.getParameter(PARAM_DEL_INVOICE_ID);
      // invoiceNum�擾 
      String invoiceNum = pageContext.getParameter(ITEM_DEL_INVOICE_NUM);

      // �p�����[�^�̃Z�b�g 
      pageContext.putParameter(PARAM_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_DEL_OK);

      pageContext.putParameter(PARAM_INVOICE_NUM,invoiceNum);
      pageContext.putParameter(PARAM_INVOICE_ID,invoiceId);
      // ��ʕ\�� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // �폜�m�F��A�߂�{�^�������� 
    else if (pageContext.getParameter(BTN_DEL_NO) != null)
    {
      // �p�����[�^ 
      pageContext.putParameter(PARAM_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_DEL_NG);

      // ����-���ʉ�ʂɖ߂� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // ���F�m�F��ʂ�[�߂�]�{�^�������|���F�����ɑO��ʂ֖߂� 
    else if (pageContext.getParameter(BTN_APP_NO) != null)
    {
      String searchKind = pageContext.getParameter(PARAM_SEARCH_KIND);
      // �p�����[�^ 
      pageContext.putParameter(PARAM_APPROVE_SEARCH,TRUE);
      pageContext.putParameter(PARAM_TRANSACTION,TRANS_RESULT);
          
      // ����-���ʉ�ʂɖ߂� 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // [�N���A]�{�^������ 
    else if (pageContext.getParameter(BTN_CREAR) != null)
    {
      String kind = pageContext.getParameter(PARAM_SEARCH_KIND);

      // �������邽�߂�Row���쐬���� 
      if (kind.equals(PARAM_NO_APPROVE))
      {
        pageContext.putParameter(PARAM_SEARCH,TRUE);
        pageContext.putParameter(PARAM_TRANSACTION,TRANS_BLANK);
      }
      else if (kind.equals(VALUE_APP_SEARCH))
      {
        pageContext.putParameter(PARAM_APPROVE_SEARCH,TRUE);
        pageContext.putParameter(PARAM_TRANSACTION,TRANS_BLANK);
      }

      // ��ʃN���A 
      pageContext.setForwardURL(DISP_SEARCH,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,  // AM���e�C������ 
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
  }

  // ��ʕ\�����e�̐ݒ� 
  /**
   * �S���\������ 
   */
  private void dispAll()
  {
    message.setRendered(true);
    conditionRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    approverResult.setRendered(true);
    approveConfirm.setRendered(true);
    resultInvoice.setRendered(true);
    deleteConfirm.setRendered(true);
    approve.setRendered(true);
  }
  /**
   * ���ׂẴ��[�W�������\���ɂ��� 
   */
  private void unDispAll()
  {
    message.setRendered(false);
    conditionRN.setRendered(false);
    separator1.setRendered(false);
    spacer1.setRendered(false);
    approverResult.setRendered(false);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(false);
    deleteConfirm.setRendered(false);
    approve.setRendered(false);
  }
  /**
   * ������̌��ʕ\���p�i�o���ȊO�j 
   */
  private void search()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    approverResult.setRendered(false);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(true);
    deleteConfirm.setRendered(false);
    approve.setRendered(false);
  }
  /**
   * �ŏ��̉��(�o�����F�p) 
   */
  private void approverSearch()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    approverResult.setRendered(true);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(false);
    deleteConfirm.setRendered(false);
    approve.setRendered(false);
  }
  /**
   * �o�����F�҂̌��ʕ\���p 
   */
  private void approveResult()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    approverResult.setRendered(true);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(false);
    deleteConfirm.setRendered(false);
    approve.setRendered(true);
  }

  /**
   * ���ʕ\���p(���F�ȊO)
   */
  private void result()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    approverResult.setRendered(false);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(true);
    deleteConfirm.setRendered(false);
    approve.setRendered(false);
  }
  
  /**
   * ���F���m�F�����ʂł̃��b�Z�[�W�ƈꗗ�\���p 
   */
  private void approveConfirm()
  {
    message.setRendered(true);
    conditionRN.setRendered(false);
    separator1.setRendered(false);
    spacer1.setRendered(false);
    approverResult.setRendered(false);
    approveConfirm.setRendered(true);
    resultInvoice.setRendered(false);
    deleteConfirm.setRendered(false);
    approve.setRendered(true);
  }
  /**
   * �폜���m�F�����ʂł̃��b�Z�[�W�\���p 
   */
  private void deleteConfirm()
  {
    message.setRendered(true);
    conditionRN.setRendered(false);
    separator1.setRendered(false);
    spacer1.setRendered(false);
    approverResult.setRendered(false);
    approveConfirm.setRendered(false);
    resultInvoice.setRendered(false);
    deleteConfirm.setRendered(true);
    approve.setRendered(false);
  }
  
  /**
   * ���̓G���[�`�F�b�N�E�E�E���t�m�F
   * @param strStartDate ���t�i���j
   * @param strEndDate ���t�i���j
   * @return �G���[�Ȃ�:false
   *         �G���[:true
   */
  private boolean dateCheck(String strStartDate,String strEndDate)
  {
    DateFormat format = DateFormat.getDateInstance();

    if (strStartDate == null || strEndDate == null)
    {
      return false;
    }
    else if (strStartDate.equals("") || strEndDate.equals(""))
    {
      return false;
    }
    else
    {
      try
      {
        java.util.Date startDate = format.parse(strStartDate);
        java.util.Date endDate = format.parse(strEndDate);
        if (startDate.after(endDate))
        {
          return true;
        }
        else
        {
          return false;
        }
      }
      catch(Exception e)
      {
        return true;
      }
    }
  }

  //2004.04.27 add start  
  /**
   * �m�F�{�^������J�ڌ�ɁA�����������Z�b�g����B
   * @param pageContext OAPageContext
   * @param webBean OAWebBean
   */
  private void setSearchItem(OAPageContext pageContext, OAWebBean webBean)
  {
    // am�C���X�^���X 
    OAApplicationModule am = pageContext.getRootApplicationModule();
    
    // ���������̃A�C�e��Bean�𐶐�����B 
    //�N�[����
    OAMessageLovInputBean oaDepartment = 
      (OAMessageLovInputBean)webBean.findChildRecursive("Department");
    //�d����
    OAMessageLovInputBean oaVendorNames = 
      (OAMessageLovInputBean)webBean.findChildRecursive("VendorNames");
    //�`�[���͎�
    OAMessageLovInputBean oaEntryPersonName = 
      (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
    //�d���搿�����ԍ�
    OAMessageTextInputBean oaVendorInvoiceNum = 
      (OAMessageTextInputBean)webBean.findChildRecursive("VendorInvoiceNum");
    //�X�e�[�^�X
    OAMessageChoiceBean oaWfStatusS = 
      (OAMessageChoiceBean)webBean.findChildRecursive("WfStatusS");
    //���������t�i���j
    OAMessageDateFieldBean oaInvoiceDateStart = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateStart");
    //�`�[���
    OAMessageLovInputBean oaSlipTypeKind = 
      (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
    //���������t�i���j
    OAMessageDateFieldBean oaInvoiceDateEnd = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDateEnd");
    //�`�[�ԍ�
    OAMessageTextInputBean oaInvoiceNumber = 
      (OAMessageTextInputBean)webBean.findChildRecursive("InvoiceNumber");
    //�N�[���i���j
    OAMessageDateFieldBean oaEntoryDateStart = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("EntoryDateStart");
    //���F��
    OAMessageLovInputBean oaApprover = 
      (OAMessageLovInputBean)webBean.findChildRecursive("Approver");
    //�N�[���i���j
    OAMessageDateFieldBean oaEntoryDateEnd = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("EntoryDateEnd");
    //�v����i���j
    OAMessageDateFieldBean oaGlDateStart = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
    //�x���O���[�v
    OAMessageLovInputBean oaPayGroupLookupCode = 
      (OAMessageLovInputBean)webBean.findChildRecursive("PayGroupLookupCode");
    //�v����i���j
    OAMessageDateFieldBean oaGlDateEnd = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
    //���ׁF����
    OAMessageLovInputBean oaLinesDepartment = 
      (OAMessageLovInputBean)webBean.findChildRecursive("LinesDepartment");
    //�x���\����i���j
    OAMessageDateFieldBean oaTermsDateStart = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("TermsDateStart");
    //���ׁF����Ȗ�
    OAMessageLovInputBean oaLinesAccountCode = 
      (OAMessageLovInputBean)webBean.findChildRecursive("LinesAccountCode");
    //�x���\����i���j
    OAMessageDateFieldBean oaTermsDateEnd = 
      (OAMessageDateFieldBean)webBean.findChildRecursive("TermsDateEnd");
    //���ׁF�����Q��
    OAMessageTextInputBean oaReconReference = 
      (OAMessageTextInputBean)webBean.findChildRecursive("ReconReference");
    //defaultSearch(������hideShow) 
    OADefaultHideShowBean searchShowItem = 
      (OADefaultHideShowBean)webBean.findChildRecursive("defaultSearch");
    // details(�ڍׂ�hideShow) 
    OADefaultHideShowBean detailShowItem = 
      (OADefaultHideShowBean)webBean.findChildRecursive("details");  

    // �N�[����ID 
    OAFormValueBean oaDepartmentId = 
      (OAFormValueBean)webBean.findChildRecursive("DepartmentId");
    // �`�[���ID 
    OAFormValueBean oaSlipTypeKindID = 
     (OAFormValueBean)webBean.findChildRecursive("SlipTypeKindID");
    // ���F��ID 
    OAFormValueBean oaApproverId = 
      (OAFormValueBean)webBean.findChildRecursive("ApproverId");
    // �d���搿�����ԍ�ID 
    OAFormValueBean oaVendorNameId = 
     (OAFormValueBean)webBean.findChildRecursive("VendorNameId");
    // �x���O���[�v�R�[�h 
    OAFormValueBean oaPayGroupLookupCodeId = 
      (OAFormValueBean)webBean.findChildRecursive("PayGroupLookupCodeId");
    // �N�[����ID 
    OAFormValueBean oaLinesDepartmentId = 
      (OAFormValueBean)webBean.findChildRecursive("LinesDepartmentId");
    // ����ȖڃR�[�h 
    OAFormValueBean oaLinesAccountCodeId = 
      (OAFormValueBean)webBean.findChildRecursive("LinesAccountCodeId");
    // �`�[���͎�ID 
    OAFormValueBean oaEntryPersonId = 
      (OAFormValueBean)webBean.findChildRecursive("EntryPersonId");

    //Ver11.5.10.1.6 Add Start
    // �A�C�e����Row�ɒl��ݒ肷��B 
    try
    {
      // �N�[���� 
      if (pageContext.getTransientSessionValue("paramDepartment") != null)
      {
        // �A�C�e�� 
        oaDepartment.setValue(pageContext,
                          pageContext.getTransientSessionValue("paramDepartment").toString());
        // row 
        am.invokeMethod("insertValue",new Serializable[]
                       {"department",(String)pageContext.getTransientSessionValue("paramDepartment")});
      }
      // �d���� 
      if (pageContext.getTransientSessionValue("paramVendorNames") != null)
      {
        oaVendorNames.setValue(pageContext,
                         pageContext.getTransientSessionValue("paramVendorNames").toString());
        am.invokeMethod("insertValue",new Serializable[]
                   {"vendorNames",(String)pageContext.getTransientSessionValue("paramVendorNames")});
      }
      // �`�[���͎� 
      if (pageContext.getTransientSessionValue("paramEntryPersonName") != null)
      {
        oaEntryPersonName.setValue(pageContext,
                    pageContext.getTransientSessionValue("paramEntryPersonName").toString());
        am.invokeMethod("insertValue",new Serializable[]
           {"entryPersonName",(String)pageContext.getTransientSessionValue("paramEntryPersonName")});
      }
      // �d���搿�����ԍ� 
      if (pageContext.getTransientSessionValue("paramVendorInvoiceNum") != null)
      {
        oaVendorInvoiceNum.setValue(pageContext,
                   pageContext.getTransientSessionValue("paramVendorInvoiceNum").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"vendorInvoiceNum",(String)pageContext.getTransientSessionValue("paramVendorInvoiceNum")});
      }
      // �X�e�[�^�X 
      if (pageContext.getTransientSessionValue("paramWfStatusS") != null)
      {
        oaWfStatusS.setDefaultValue
          (pageContext.getTransientSessionValue("paramWfStatusS").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"wfStatusS",(String)pageContext.getTransientSessionValue("paramWfStatusS")});
      }
      // ���������t�i���j 
      if (pageContext.getTransientSessionValue("paramInvoiceDateStart") != null)
      {
        oaInvoiceDateStart.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramInvoiceDateStart").toString()));
        am.invokeMethod("insertValue",new Serializable[]
          {"invoiceDateStart",pageContext.getTransientSessionValue("paramInvoiceDateStart").toString()});
      }
      // �`�[��� 
      if (pageContext.getTransientSessionValue("paramSlipTypeKind") != null)
      {
        oaSlipTypeKind.setValue(pageContext,
                        pageContext.getTransientSessionValue("paramSlipTypeKind").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"slipTypeKind",(String)pageContext.getTransientSessionValue("paramSlipTypeKind")});
      }
      // ���������t�i���j 
      if (pageContext.getTransientSessionValue("paramInvoiceDateEnd") != null)
      {

        oaInvoiceDateEnd.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramInvoiceDateEnd")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"invoiceDateEnd",pageContext.getTransientSessionValue("paramInvoiceDateEnd").toString()});
      }
      // �`�[�ԍ� 
      if (pageContext.getTransientSessionValue("paramInvoiceNumber") != null)
      {
        oaInvoiceNumber.setValue(pageContext,
                pageContext.getTransientSessionValue("paramInvoiceNumber").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"invoiceNumber",(String)pageContext.getTransientSessionValue("paramInvoiceNumber")});
      }
      // �N�[���i���j 
      if (pageContext.getTransientSessionValue("paramEntoryDateStart") != null)
      {
        oaEntoryDateStart.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramEntoryDateStart")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"entoryDateStart",pageContext.getTransientSessionValue("paramEntoryDateStart").toString()});
      }
      // ���F�� 
      if (pageContext.getTransientSessionValue("paramApprover") != null)
      {
        oaApprover.setValue(pageContext,
          pageContext.getTransientSessionValue("paramApprover").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"approver",(String)pageContext.getTransientSessionValue("paramApprover")});
      }
      // �N�[���i���j 
      if (pageContext.getTransientSessionValue("paramEntoryDateEnd") != null)
      {
        oaEntoryDateEnd.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramEntoryDateEnd")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"entoryDateEnd",pageContext.getTransientSessionValue("paramEntoryDateEnd").toString()});
      }
      // �v����i���j 
      if (pageContext.getTransientSessionValue("paramGlDateStart") != null)
      {
        oaGlDateStart.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramGlDateStart")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"glDateStart",pageContext.getTransientSessionValue("paramGlDateStart").toString()});
      }
      // �x���O���[�v 
      if (pageContext.getTransientSessionValue("paramPayGroupLookupCode") != null)
      {
        oaPayGroupLookupCode.setValue(pageContext,
          pageContext.getTransientSessionValue("paramPayGroupLookupCode").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"payGroupLookupCode",(String)pageContext.getTransientSessionValue("paramPayGroupLookupCode")});
      }
      // �v����i���j 
      if (pageContext.getTransientSessionValue("paramGlDateEnd") != null)
      {
        oaGlDateEnd.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramGlDateEnd")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"glDateEnd",pageContext.getTransientSessionValue("paramGlDateEnd").toString()});
      }
      // ���ׁF���� 
      if (pageContext.getTransientSessionValue("paramLinesDepartment") != null)
      {
        oaLinesDepartment.setValue(pageContext,
          pageContext.getTransientSessionValue("paramLinesDepartment").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"linesDepartment",(String)pageContext.getTransientSessionValue("paramLinesDepartment")});
      }
      // �x���\����i���j 
      if (pageContext.getTransientSessionValue("paramTermsDateStart") != null)
      {
        oaTermsDateStart.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramTermsDateStart")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"termsDateStart",pageContext.getTransientSessionValue("paramTermsDateStart").toString()});
      }
      // ���ׁF����Ȗ� 
      if (pageContext.getTransientSessionValue("paramLinesAccountCode") != null)
      {
        oaLinesAccountCode.setValue(pageContext,
          pageContext.getTransientSessionValue("paramLinesAccountCode").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"linesAccountCode",(String)pageContext.getTransientSessionValue("paramLinesAccountCode")});
      }
      // �x���\����i���j 
      if (pageContext.getTransientSessionValue("paramTermsDateEnd") != null)
      {
        oaTermsDateEnd.setValue(pageContext,
          new Date(pageContext.getTransientSessionValue("paramTermsDateEnd")).toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"termsDateEnd",pageContext.getTransientSessionValue("paramTermsDateEnd").toString()});
      }
      // ���ׁF�����Q�� 
      if (pageContext.getTransientSessionValue("paramReconReference") != null)
      {
        oaReconReference.setValue(pageContext,
          pageContext.getTransientSessionValue("paramReconReference").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"reconReference",(String)pageContext.getTransientSessionValue("paramReconReference")});
      }
      // �N�[����ID 
      if (pageContext.getTransientSessionValue("paramDepartmentId") != null)
      {
        oaDepartmentId.setValue(pageContext,
          pageContext.getTransientSessionValue("paramDepartmentId").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"departmentId",(String)pageContext.getTransientSessionValue("paramDepartmentId")});
      }
      // �`�[���ID 
      if (pageContext.getTransientSessionValue("paramSlipTypeKindID") != null)
      {
        oaSlipTypeKindID.setValue(pageContext,
          pageContext.getTransientSessionValue("paramSlipTypeKindID").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"slipTypeKindID",(String)pageContext.getTransientSessionValue("paramSlipTypeKindID")});
      }
      // ���F��ID 
      if (pageContext.getTransientSessionValue("paramApproverId") != null)
      {
        oaApproverId.setValue(pageContext,
          new Integer(pageContext.getTransientSessionValue("paramApproverId").toString()));
        am.invokeMethod("insertValue",new Serializable[]
          {"approverId",(String)pageContext.getTransientSessionValue("paramApproverId")});
      }
      // �d����ID 
      if (pageContext.getTransientSessionValue("paramVendorNameId") != null)
      {
        oaVendorNameId.setValue(pageContext,
          new Integer(pageContext.getTransientSessionValue("paramVendorNameId").toString()));
        am.invokeMethod("insertValue",new Serializable[]
          {"vendorNameId",(String)pageContext.getTransientSessionValue("paramVendorNameId")});
      }
      // �`�[���͎�ID 
      if (pageContext.getTransientSessionValue("paramEntryPersonId") != null)
      {
         oaEntryPersonId.setValue(pageContext,
           new Integer(pageContext.getTransientSessionValue("paramEntryPersonId").toString()));
         am.invokeMethod("insertValue",new Serializable[]
           {"entryPersonId",(String)pageContext.getTransientSessionValue("paramEntryPersonId")});
      }
      // �x���O���[�vID 
      if (pageContext.getTransientSessionValue("paramPayGroupLookupCodeId") != null)
      {
        oaPayGroupLookupCodeId.setValue(pageContext,
          pageContext.getTransientSessionValue("paramPayGroupLookupCodeId").toString());
        am.invokeMethod("insertValue",new Serializable[]{"payGroupLookupCodeId",
          pageContext.getTransientSessionValue("paramPayGroupLookupCodeId").toString()});
      }
      // ���ׁF����ID 
      if (pageContext.getTransientSessionValue("paramLinesDepartmentId") != null)
      {
        oaLinesDepartmentId.setValue(pageContext,
          pageContext.getTransientSessionValue("paramLinesDepartmentId").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"linesDepartmentId",(String)pageContext.getTransientSessionValue("paramLinesDepartmentId")});
      }
      // ���ׁF����Ȗ�ID 
      if (pageContext.getTransientSessionValue("paramLinesAccountCodeId") != null)
      {
        oaLinesAccountCodeId.setValue(pageContext,
          pageContext.getTransientSessionValue("paramLinesAccountCodeId").toString());
        am.invokeMethod("insertValue",new Serializable[]
          {"linesAccountCodeId",(String)pageContext.getTransientSessionValue("paramLinesAccountCodeId")});
      }
    }
    catch(SQLException e)
    {
      throw OAException.wrapperException(e);
    }

    //// �A�C�e����Row�ɒl��ݒ肷��B 
    //// �N�[���� 
    //if (pageContext.getParameter("paramDepartment") != null)
    //{
    //  // �A�C�e�� 
    //  oaDepartment.setValue(pageContext,
    //                    pageContext.getParameter("paramDepartment").toString());
    //  // row 
    //  am.invokeMethod("insertValue",new Serializable[]
    //                 {"department",pageContext.getParameter("paramDepartment")});
    //}
    //// �d���� 
    //if (pageContext.getParameter("paramVendorNames") != null)
    //{
    //  oaVendorNames.setValue(pageContext,
    //                   pageContext.getParameter("paramVendorNames").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //             {"vendorNames",pageContext.getParameter("paramVendorNames")});
    //}
    //// �`�[���͎� 
    //if (pageContext.getParameter("paramEntryPersonName") != null)
    //{
    //  oaEntryPersonName.setValue(pageContext,
    //              pageContext.getParameter("paramEntryPersonName").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //     {"entryPersonName",pageContext.getParameter("paramEntryPersonName")});
    //}
    //// �d���搿�����ԍ� 
    //if (pageContext.getParameter("paramVendorInvoiceNum") != null)
    //{
    //  oaVendorInvoiceNum.setValue(pageContext,
    //             pageContext.getParameter("paramVendorInvoiceNum").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"vendorInvoiceNum",pageContext.getParameter("paramVendorInvoiceNum")});
    //}
    //// �X�e�[�^�X 
    //if (pageContext.getParameter("paramWfStatusS") != null)
    //{
    //  oaWfStatusS.setDefaultValue
    //    (pageContext.getParameter("paramWfStatusS").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"wfStatusS",pageContext.getParameter("paramWfStatusS")});
    //}
    //// ���������t�i���j 
    //if (pageContext.getParameter("paramInvoiceDateStart") != null)
    //{
    //  oaInvoiceDateStart.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramInvoiceDateStart").toString()));
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"invoiceDateStart",pageContext.getParameter("paramInvoiceDateStart")});
    //}
    //// �`�[��� 
    //if (pageContext.getParameter("paramSlipTypeKind") != null)
    //{
    //  oaSlipTypeKind.setValue(pageContext,
    //                  pageContext.getParameter("paramSlipTypeKind").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"slipTypeKind",pageContext.getParameter("paramSlipTypeKind")});
    //}
    //// ���������t�i���j 
    //if (pageContext.getParameter("paramInvoiceDateEnd") != null)
    //{

    //  oaInvoiceDateEnd.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramInvoiceDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"invoiceDateEnd",pageContext.getParameter("paramInvoiceDateEnd")});
    //}
    //// �`�[�ԍ� 
    //if (pageContext.getParameter("paramInvoiceNumber") != null)
    //{
    //  oaInvoiceNumber.setValue(pageContext,
    //          pageContext.getParameter("paramInvoiceNumber").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"invoiceNumber",pageContext.getParameter("paramInvoiceNumber")});
    //}
    //// �N�[���i���j 
    //if (pageContext.getParameter("paramEntoryDateStart") != null)
    //{
    //  oaEntoryDateStart.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramEntoryDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"entoryDateStart",pageContext.getParameter("paramEntoryDateStart")});
    //}
    //// ���F�� 
    //if (pageContext.getParameter("paramApprover") != null)
    //{
    //  oaApprover.setValue(pageContext,
    //    pageContext.getParameter("paramApprover").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"approver",pageContext.getParameter("paramApprover")});
    //}
    //// �N�[���i���j 
    //if (pageContext.getParameter("paramEntoryDateEnd") != null)
    //{
    //  oaEntoryDateEnd.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramEntoryDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"entoryDateEnd",pageContext.getParameter("paramEntoryDateEnd")});
    //}
    //// �v����i���j 
    //if (pageContext.getParameter("paramGlDateStart") != null)
    //{
    //  oaGlDateStart.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramGlDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"glDateStart",pageContext.getParameter("paramGlDateStart")});
    //}
    //// �x���O���[�v 
    //if (pageContext.getParameter("paramPayGroupLookupCode") != null)
    //{
    //  oaPayGroupLookupCode.setValue(pageContext,
    //    pageContext.getParameter("paramPayGroupLookupCode").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"payGroupLookupCode",pageContext.getParameter("paramPayGroupLookupCode")});
    //}
    //// �v����i���j 
    //if (pageContext.getParameter("paramGlDateEnd") != null)
    //{
    //  oaGlDateEnd.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramGlDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"glDateEnd",pageContext.getParameter("paramGlDateEnd")});
    //}
    //// ���ׁF���� 
    //if (pageContext.getParameter("paramLinesDepartment") != null)
    //{
    //  oaLinesDepartment.setValue(pageContext,
    //    pageContext.getParameter("paramLinesDepartment").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"linesDepartment",pageContext.getParameter("paramLinesDepartment")});
    //}
    //// �x���\����i���j 
    //if (pageContext.getParameter("paramTermsDateStart") != null)
    //{
    //  oaTermsDateStart.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramTermsDateStart")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"termsDateStart",pageContext.getParameter("paramTermsDateStart")});
    //}
    //// ���ׁF����Ȗ� 
    //if (pageContext.getParameter("paramLinesAccountCode") != null)
    //{
    //  oaLinesAccountCode.setValue(pageContext,
    //    pageContext.getParameter("paramLinesAccountCode").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"linesAccountCode",pageContext.getParameter("paramLinesAccountCode")});
    //}
    //// �x���\����i���j 
    //if (pageContext.getParameter("paramTermsDateEnd") != null)
    //{
    //  oaTermsDateEnd.setValue(pageContext,
    //    new Date(pageContext.getParameter("paramTermsDateEnd")).toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"termsDateEnd",pageContext.getParameter("paramTermsDateEnd")});
    //}
    //// ���ׁF�����Q�� 
    //if (pageContext.getParameter("paramReconReference") != null)
    //{
    //  oaReconReference.setValue(pageContext,
    //    pageContext.getParameter("paramReconReference").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"reconReference",pageContext.getParameter("paramReconReference")});
    //}
    //// �N�[����ID 
    //if (pageContext.getParameter("paramDepartmentId") != null)
    //{
    //  oaDepartmentId.setValue(pageContext,
    //    pageContext.getParameter("paramDepartmentId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"departmentId",pageContext.getParameter("paramDepartmentId")});
    //}
    //// �`�[���ID 
    //if (pageContext.getParameter("paramSlipTypeKindID") != null)
    //{
    //  oaSlipTypeKindID.setValue(pageContext,
    //    pageContext.getParameter("paramSlipTypeKindID").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"slipTypeKindID",pageContext.getParameter("paramSlipTypeKindID")});
    //}
    //// ���F��ID 
    //if (pageContext.getParameter("paramApproverId") != null)
    //{
    //  oaApproverId.setValue(pageContext,
    //    new Integer(pageContext.getParameter("paramApproverId")));
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"approverId",pageContext.getParameter("paramApproverId")});
    //}
    //// �d����ID 
    //if (pageContext.getParameter("paramVendorNameId") != null)
    //{
    //  oaVendorNameId.setValue(pageContext,
    //    new Integer(pageContext.getParameter("paramVendorNameId")));
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"vendorNameId",pageContext.getParameter("paramVendorNameId")});
    //}
    //// �`�[���͎�ID 
    //if (pageContext.getParameter("paramEntryPersonId") != null)
    //{
    //   oaEntryPersonId.setValue(pageContext,
    //     new Integer(pageContext.getParameter("paramEntryPersonId")));
    //   am.invokeMethod("insertValue",new Serializable[]
    //     {"entryPersonId",pageContext.getParameter("paramEntryPersonId")});
    //}
    //// �x���O���[�vID 
    //if (pageContext.getParameter("paramPayGroupLookupCodeId") != null)
    //{
    //  oaPayGroupLookupCodeId.setValue(pageContext,
    //    pageContext.getParameter("paramPayGroupLookupCodeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]{"payGroupLookupCodeId",
    //    pageContext.getParameter("paramPayGroupLookupCodeId")});
    //}
    //// ���ׁF����ID 
    //if (pageContext.getParameter("paramLinesDepartmentId") != null)
    //{
    //  oaLinesDepartmentId.setValue(pageContext,
    //    pageContext.getParameter("paramLinesDepartmentId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"linesDepartmentId",pageContext.getParameter("paramLinesDepartmentId")});
    //}
    //// ���ׁF����Ȗ�ID 
    //if (pageContext.getParameter("paramLinesAccountCodeId") != null)
    //{
    //  oaLinesAccountCodeId.setValue(pageContext,
    //    pageContext.getParameter("paramLinesAccountCodeId").toString());
    //  am.invokeMethod("insertValue",new Serializable[]
    //    {"linesAccountCodeId",pageContext.getParameter("paramLinesAccountCodeId")});
    //}
    //Ver11.5.10.1.6 Add End
  }
  //2004.04.27 add end

  //Ver11.5.10.1.6 Add Start
  /**
   * �Z�b�V�����Ɋi�[���������������폜����B
   */
  private void removeSearchItem(OAPageContext pageContext) 
  {
        pageContext.removeTransientSessionValue("paramDepartment");
        pageContext.removeTransientSessionValue("paramVendorNames");
        pageContext.removeTransientSessionValue("paramEntryPersonName");
        pageContext.removeTransientSessionValue("paramVendorInvoiceNum");
        pageContext.removeTransientSessionValue("paramWfStatusS");
        pageContext.removeTransientSessionValue("paramInvoiceDateStart");
        pageContext.removeTransientSessionValue("paramSlipTypeKind");
        pageContext.removeTransientSessionValue("paramInvoiceDateEnd");
        pageContext.removeTransientSessionValue("paramInvoiceNumber");
        pageContext.removeTransientSessionValue("paramEntoryDateStart");
        pageContext.removeTransientSessionValue("paramApprover");
        pageContext.removeTransientSessionValue("paramEntoryDateEnd");
        pageContext.removeTransientSessionValue("paramGlDateStart");
        pageContext.removeTransientSessionValue("paramPayGroupLookupCode");
        pageContext.removeTransientSessionValue("paramGlDateEnd");
        pageContext.removeTransientSessionValue("paramLinesDepartment");
        pageContext.removeTransientSessionValue("paramTermsDateStart");
        pageContext.removeTransientSessionValue("paramLinesAccountCode");
        pageContext.removeTransientSessionValue("paramTermsDateEnd");
        pageContext.removeTransientSessionValue("paramReconReference");
        pageContext.removeTransientSessionValue("paramDepartmentId");
        pageContext.removeTransientSessionValue("paramSlipTypeKindID");
        pageContext.removeTransientSessionValue("paramApproverId");
        pageContext.removeTransientSessionValue("paramVendorNameId");
        pageContext.removeTransientSessionValue("paramEntryPersonId");
        pageContext.removeTransientSessionValue("paramPayGroupLookupCodeId");
        pageContext.removeTransientSessionValue("paramLinesDepartmentId");
        pageContext.removeTransientSessionValue("paramLinesAccountCodeId");
        pageContext.removeTransientSessionValue("paramSearchShow");
        pageContext.removeTransientSessionValue("paramDetailShow");     
  }
  //Ver11.5.10.1.6 Add End
}

