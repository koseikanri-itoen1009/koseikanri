/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005  All rights reserved
 * FILENAME   XX03InvoiceInputCO.java
 * VERSION    11.5.10.2.6
 * DATE       2006/10/20
 * HISTORY    2004/12/17                  �V�K�쐬
 *            2005/02/24 ver 1.1          �d�l�ύX�Ή��g��
 *            2005/03/03 ver 1.2          �s��C��
 *            2005/03/18 ver 1.3          �O����̖�������`�F�b�N�����ǉ�
 *                                        �x�����@�̗L�����`�F�b�N�����ǉ�
 *            2005/04/12 ver 11.5.10.1    �`�[�ԍ��\���s���Ή� 
 *            2005/07/07 ver 11.5.10.4    ����Ŋz�݂̂ł��v��ł���悤�ɏC��
 *            2005/08/05 ver 11.5.10.1.4B �x�����@�̗L�����`�F�b�N�s��Ή�
 *            2005/09/07 ver 11.5.10.1.5  �w�b�_�[�݂̂̐\���ŃG���[�ɂȂ�悤�ɕύX
 *            2005/11/10 ver 11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�
 *            2005/12/27 ver 11.5.10.1.6B ���j���[���疳���ȓ`�[��ʂ�I�������ۂ̃G���[�Ή�
 *            2006/01/12 ver 11.5.10.1.6C �������׃^�u�\�����Ɏd��^�u�̍��ڂŃG���[��
 *                                        �N�����ꍇ�̃��b�Z�[�W�𐳂������̂ɂ���
 *            2006/01/18 ver 11.5.10.1.6D ����Ŋz�����͂���Ă��Ȃ��ꍇ��
 *                                        ����Ŋz���Z�o����悤�ɏC��
 *            2006/01/27 ver 11.5.10.1.6E ���ׂ̍ő匏���`�F�b�N�Ή�
 *            2006/02/02 ver 11.5.10.1.6F �{�^���̃_�u���N���b�N�Ή�
 *            2006/02/16 ver 11.5.10.1.6G �قȂ�^�u�ŃG���[�������A�J�ڂł��Ȃ��Ή�
 *            2006/10/20 ver 11.5.10.2.6  ���ׂ̓��̓`�F�b�N���@�̌��Ή�
 *                                        AM��VO���`�F�b�N����悤�ɏC��
 *
 *===========================================================================*/
package oracle.apps.xx03.ar.input.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import java.util.ArrayList;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanStyledText;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASubTabLayoutBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageCheckBoxBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.table.OAAdvancedTableBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;

import oracle.bali.share.util.BooleanUtils;

import oracle.jbo.domain.Number;

// ver1.4 delete start ------------------------------------------------------
// ver1.3 add start ---------------------------------------------------------
//import oracle.jbo.domain.Date;
//import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
// ver1.3 add end -----------------------------------------------------------
// ver1.4 delete end --------------------------------------------------------

//Ver11.5.10.1.6E Add Start
import oracle.apps.xx03.util.Xx03CommonUtil;
//Ver11.5.10.1.6E Add End

/**
 *
 * Xx03InvoiceInputPG�̃R���g���[��
 *
 * @version     11.5.10.1.6G
 */
public class Xx03InvoiceInputCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    // �A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    // �߂�{�^���ɂ����s�̏ꍇ
    if (pageContext.isBackNavigationFired(false))
    {
      am.invokeMethod("rollback");

      //ver11.5.10.1.6F Add Start
      //OADialogPage dialogPage = new OADialogPage(STATE_LOSS_ERROR);
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );
      //ver11.5.10.1.6F Add End

      pageContext.redirectToDialogPage(dialogPage);
    }
    // �߂�{�^���ɂ����s�łȂ��ꍇ
    else
    {
      try{    
        // *************************************************************************
        // * ���ʏ���
        // *************************************************************************
        // �p�����[�^�擾
        String pageStatus = null;   // �J�ڌ���ʖ�
        String funcButton = null;   // �����{�^����

        Object tmpPageStatus = Xx03ArCommonUtil.getParameterValue(pageContext, "pageStatus");
        Object tmpFuncButton = Xx03ArCommonUtil.getParameterValue(pageContext, "funcButton");

        // �p�����[�^�̑J�ڌ���ʖ����Ȃ������j���[����̑J��
        if (tmpPageStatus == null)
        {
          pageStatus = Xx03ArCommonUtil.WINDOW_NAME_MENU;
        }
        // �p�����[�^�̑J�ڌ���ʖ����ϐ��̑J�ڌ���ʖ�
        else
        {
          pageStatus = tmpPageStatus.toString();
        }

        // �p�����[�^�̉����{�^����Null���ϐ��̉����{�^����Null
        if (tmpFuncButton == null)
        {
          funcButton = null;
        }
        // �p�����[�^�̉����{�^�������ϐ��̉����{�^����
        else
        {
          funcButton = tmpFuncButton.toString();
        }

        // ���ו\�������̎擾
        OAAdvancedTableBean invoiceLinesDetail = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesDetailRN");
        OAAdvancedTableBean invoiceLinesJournal = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesJournalRN");
        Integer invoiceLinesDetailCnt = new Integer(invoiceLinesDetail.getNumberOfRowsDisplayed());
        Integer invoiceLinesJournalCnt = new Integer(invoiceLinesJournal.getNumberOfRowsDisplayed());
        Boolean forceFlag = BooleanUtils.getBoolean(false);

        // �^�u�������̌��؏����𖳌���
        OASubTabLayoutBean slipLine = (OASubTabLayoutBean)webBean.findChildRecursive("InvoiceLineRN");
        slipLine.setUnvalidated(true);
        //ver11.5.10.1.6G Add Start
        slipLine.setServerUnvalidated(true);
        //ver11.5.10.1.6G Add End


        // �O����t���O
        String strPrePayFlag = null;

        // ***********************************************************************
        // * �^�u
        // ***********************************************************************
        // �^�u�ؑ֎��́A������
        if (Xx03ArCommonUtil.STR_YES.equals(pageContext.getTransactionValue("tab")))
        {
          pageContext.removeTransactionValue("tab");            

          // ��\��(�`�[�ԍ��A�C�����`�[�ԍ�)
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          OAWebBeanStyledText origReceivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("OrigReceivableNum");
          //2005.04.12 change start Ver11.5.10.1
          if (receivableNum.getValue(pageContext) == null)
          {
            receivableNum.setRendered(false);
            origReceivableNum.setRendered(false);
          }
          //2005.04.12 change end Ver11.5.10.1

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
        }

        // ***********************************************************************
        // * ���j���[����J��
        // * �m�F��ʂ���J��(�V�K)
        // ***********************************************************************
        else if ((Xx03ArCommonUtil.WINDOW_NAME_MENU.equals(pageStatus))
          || (Xx03ArCommonUtil.WINDOW_NAME_CONFIRM.equals(pageStatus))
            && (Xx03ArCommonUtil.FUNC_NAME_NEW.equals(funcButton)))
        {
          // �`�[��ʎ擾
          String slipType = Xx03ArCommonUtil.getParameterValue(pageContext, "slipType").toString();
//          String slipType = "83080";

          // �w�b�_�[�A���ׂ̍쐬
          Serializable[] methodParams = {slipType};
          Class[] methodParamTypes = {slipType.getClass()};

          // ��`�[�w�b�_�f�[�^�쐬
          am.invokeMethod("createReceivableSlips", methodParams, methodParamTypes); 

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
          
          // ��`�[���׃f�[�^�쐬
          Number detailCount = null;
          if (strPrePayFlag.equals("Y"))
          {
            // �O����̏ꍇ�͎d��P�s�̂�
            detailCount = new Number(1);
          }
          else
          {
            // ���̑��͖��אݒ�s��
            detailCount = new Number(invoiceLinesDetailCnt.intValue());
          }
          methodParams = new Serializable[]{detailCount};
          methodParamTypes = new Class[]{detailCount.getClass()};
          am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes);            

          // ��\��(�`�[�ԍ��A�C�����`�[�ԍ�)
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          OAWebBeanStyledText origReceivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("OrigReceivableNum");
          receivableNum.setRendered(false);
          origReceivableNum.setRendered(false);
        }
        // ***********************************************************************
        // * �m�F��ʂ���J��(�X�V)
        // * �ꌩ�ڋq�A�O�����ʂ���J��(�ĕ\��)
        // ***********************************************************************
        else if (((Xx03ArCommonUtil.WINDOW_NAME_CONFIRM.equals(pageStatus))
          && (Xx03ArCommonUtil.FUNC_NAME_UPDATE.equals(funcButton)))
          || (Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER.equals(pageStatus))
          || (Xx03ArCommonUtil.WINDOW_NAME_PREPAY.equals(pageStatus)))
        {
          Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));

          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          Boolean executeQuery = BooleanUtils.getBoolean(false);

          // �w�b�_�[�A���ׂ̌���
          Serializable[] methodParams = {receivableId, executeQuery};
          Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
      
          am.invokeMethod("initReceivableSlips", methodParams, methodParamTypes);

          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          invoiceLinesDetail.queryData(pageContext, true);
          invoiceLinesJournal.queryData(pageContext, true);

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
          
          // ��`�[���׃f�[�^�쐬
          Number detailCount = null;
          if (strPrePayFlag.equals("Y"))
          {
            // �O����̏ꍇ�͎d��P�s�̂�
            detailCount = new Number(1);
          }
          else
          {
            // ���̑��͖��אݒ�s��
            detailCount = new Number(invoiceLinesDetailCnt.intValue());
          }
          methodParams = new Serializable[]{detailCount};
          methodParamTypes = new Class[]{detailCount.getClass()};
          am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes); 

          // �Čv�Z
          am.invokeMethod("recalculate");  
        }
        // ***********************************************************************
        // * �m�F��ʂ���J��(�R�s�[)
        // ***********************************************************************
        else if ((Xx03ArCommonUtil.WINDOW_NAME_CONFIRM.equals(pageStatus))
          && (Xx03ArCommonUtil.FUNC_NAME_COPY.equals(funcButton)))
        {
          Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));

          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          Boolean executeQuery = BooleanUtils.getBoolean(false);

          // �w�b�_�[�A���ׂ̌���
          Serializable[] methodParams = {receivableId, executeQuery};
          Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
      
          am.invokeMethod("initReceivableSlips", methodParams, methodParamTypes);
          
          // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
          invoiceLinesDetail.queryData(pageContext, true);
          invoiceLinesJournal.queryData(pageContext, true);

          // �`�[�R�s�[
          Number newReceivableId = (Number)am.invokeMethod("copy");

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
          
          // ��`�[���׃f�[�^�쐬
          Number detailCount = null;
          if (strPrePayFlag.equals("Y"))
          {
            // �O����̏ꍇ�͎d��P�s�̂�
            detailCount = new Number(1);
          }
          else
          {
            // ���̑��͖��אݒ�s��
            detailCount = new Number(invoiceLinesDetailCnt.intValue());
          }
          methodParams = new Serializable[]{detailCount};
          methodParamTypes = new Class[]{detailCount.getClass()};
          am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes);

          //2005.04.12 add start Ver11.5.10.1
          // ��\��(�`�[�ԍ��A�C�����`�[�ԍ�)
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          OAWebBeanStyledText origReceivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("OrigReceivableNum");
          receivableNum.setRendered(false);
          origReceivableNum.setRendered(false);
          //2005.04.12 add end Ver11.5.10.1
        }
        // ***********************************************************************
        // * ����ʑJ��
        // ***********************************************************************
        else if (Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus))
        {
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          OAWebBeanStyledText origReceivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("OrigReceivableNum");

          // �ۑ��{�^���������ȊO���`�[�ԍ����莞�͓`�[�ԍ��͔�\��
          if ((!Xx03ArCommonUtil.FUNC_NAME_SAVE.equals(funcButton))
              && receivableNum.getValue(pageContext) == null)
          {
            // ��\��(�`�[�ԍ��A�C�����`�[�ԍ�)
            receivableNum.setRendered(false);
            origReceivableNum.setRendered(false);
          }

          // �O����\���敪�擾
          strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
        }
        
        // ***********************************************************************
        // * ���ʏ���
        // ***********************************************************************
        // �`�[��ʂ̕\���e�L�X�g�ύX
        OAHeaderBean slipHeaderTitleBean = (OAHeaderBean)webBean.findIndexedChildRecursive("SlipHeaderTitleRN");

        //Ver11.5.10.1.6B 2005/12/27 Change Start
        //slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
        //  new OADataBoundValueViewObject(slipHeaderTitleBean, "SlipTypeName", "Xx03ReceivableSlipsVO1"));
        slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
          new OADataBoundValueViewObject(slipHeaderTitleBean, "Description", "Xx03SlipTypesLovVO1"));
        //Ver11.5.10.1.6B 2005/12/27 Change End

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");

        // �O����{�^���\���ؑ�
        OASubmitButtonBean prePaidMoney = (OASubmitButtonBean)webBean.findChildRecursive("PrePaidMoney");
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        OAMessageLovInputBean segment1Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment1Name1");
        OAMessageLovInputBean segment2Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment2Name1");
        OAMessageLovInputBean segment3Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment3Name1");
        OAMessageLovInputBean segment4Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment4Name1");
        OAMessageLovInputBean segment5Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment5Name1");
        OAMessageLovInputBean segment6Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment6Name1");
        OAMessageLovInputBean segment7Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment7Name1");
        OAMessageLovInputBean segment8Name1 = (OAMessageLovInputBean)webBean.findChildRecursive("Segment8Name1");
        OAMessageLovInputBean incrDecrReasonName1 = (OAMessageLovInputBean)webBean.findChildRecursive("IncrDecrReasonName1");
        OAWebBeanTextInput reconReference1 = (OAWebBeanTextInput)webBean.findChildRecursive("ReconReference1");
        if ((strPrePayFlag != null) && (strPrePayFlag.equals("Y")))
        {
          // �O���
          prePaidMoney.setDisabled(false);
          slipLine.hideSubTab(0, true);
          commitmentNumber.setRendered(false);

          // AFF���ڕҏW�s��
          segment1Name1.setDisabled(true);
          segment2Name1.setDisabled(true);
          segment3Name1.setDisabled(true);
          segment4Name1.setDisabled(true);
          segment5Name1.setDisabled(true);
          segment6Name1.setDisabled(true);
          segment7Name1.setDisabled(true);
          segment8Name1.setDisabled(true);
        }
        else
        {
          // �O����ȊO
          prePaidMoney.setDisabled(true);
          slipLine.hideSubTab(0, false);
          commitmentNumber.setRendered(true);

          // AFF���ڕҏW��
          segment1Name1.setDisabled(false);
          segment2Name1.setDisabled(false);
          segment3Name1.setDisabled(false);
          segment4Name1.setDisabled(false);
          segment5Name1.setDisabled(false);
          segment6Name1.setDisabled(false);
          segment7Name1.setDisabled(false);
          segment8Name1.setDisabled(false);
        }

        // AFF�ADFF�v�����v�g�擾�A���̐ݒ�
        ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptArInput");
        segment1Name1.setPrompt((String)affPromptInfo.get(0));
        segment2Name1.setPrompt((String)affPromptInfo.get(1));
        segment3Name1.setPrompt((String)affPromptInfo.get(2));
        segment4Name1.setPrompt((String)affPromptInfo.get(3));
        segment5Name1.setPrompt((String)affPromptInfo.get(4));
        segment6Name1.setPrompt((String)affPromptInfo.get(5));
        segment7Name1.setPrompt((String)affPromptInfo.get(6));
        segment8Name1.setPrompt((String)affPromptInfo.get(7));
        incrDecrReasonName1.setPrompt((String)affPromptInfo.get(8));
        reconReference1.setLabel((String)affPromptInfo.get(9));

        //Ver11.5.10.1.6C Add Start
        OAWebBean segment1NameDummy =(OAWebBean)webBean.findChildRecursive("Segment1NameDummy");
        OAWebBean segment2NameDummy =(OAWebBean)webBean.findChildRecursive("Segment2NameDummy");
        OAWebBean segment3NameDummy =(OAWebBean)webBean.findChildRecursive("Segment3NameDummy");
        OAWebBean segment4NameDummy =(OAWebBean)webBean.findChildRecursive("Segment4NameDummy");
        OAWebBean segment5NameDummy =(OAWebBean)webBean.findChildRecursive("Segment5NameDummy");
        OAWebBean segment6NameDummy =(OAWebBean)webBean.findChildRecursive("Segment6NameDummy");
        OAWebBean segment7NameDummy =(OAWebBean)webBean.findChildRecursive("Segment7NameDummy");
        OAWebBean segment8NameDummy =(OAWebBean)webBean.findChildRecursive("Segment8NameDummy");
        OAWebBean incrDecrNameDummy =(OAWebBean)webBean.findChildRecursive("IncrDecrReasonNameDummy");

        segment1NameDummy.setLabel((String)affPromptInfo.get(0));
        segment2NameDummy.setLabel((String)affPromptInfo.get(1));
        segment3NameDummy.setLabel((String)affPromptInfo.get(2));
        segment4NameDummy.setLabel((String)affPromptInfo.get(3));
        segment5NameDummy.setLabel((String)affPromptInfo.get(4));
        segment6NameDummy.setLabel((String)affPromptInfo.get(5));
        segment7NameDummy.setLabel((String)affPromptInfo.get(6));
        segment8NameDummy.setLabel((String)affPromptInfo.get(7));
        incrDecrNameDummy.setLabel((String)affPromptInfo.get(8));
        //Ver11.5.10.1.6C Add End

/*
 LOV����s��̈׃R�����g�A�E�g
        // �ꌩ�ڋq�{�^���\���۔���
        // �e�[�u���̈ꌩ�ڋq�\���敪�擾
        String firstCustomerFlag = (String)am.invokeMethod("getFirstCustomerFlag");
        setFirstCustomerRenderd(pageContext, webBean, firstCustomerFlag);
        
        // ����Ōv�Z���x���A����Œ[�������ݒ�
        OAFormValueBean autoTaxCalcFlag = (OAFormValueBean)webBean.findChildRecursive("AutoTaxCalcFlag");
        OAFormValueBean taxRoundingRule = (OAFormValueBean)webBean.findChildRecursive("TaxRoundingRule");
        Object paramAutoTaxCalcFlag = Xx03ArCommonUtil.getParameterValue(pageContext, "paramAutoTaxCalcFlag");
        Object paramTaxRoundingRule = Xx03ArCommonUtil.getParameterValue(pageContext, "paramTaxRoundingRule");
        // �p�����[�^�̏���Ōv�Z���x���A����Œ[������������ꍇ
        if (paramAutoTaxCalcFlag != null && paramTaxRoundingRule != null)
        {
          // �p�����[�^�̒l��Item�ɃZ�b�g
          autoTaxCalcFlag.setValue(pageContext, paramAutoTaxCalcFlag.toString().substring(0,1));
          taxRoundingRule.setValue(pageContext, paramTaxRoundingRule.toString().substring(0,1));
        }
*/

        //Ver11.5.10.1.6B 2005/12/27 Add Start
        //�`�[��ʗL������������擾
        Serializable enaSlipType    = am.invokeMethod("retEnableSlipType2");
        String       strEnaSlipType = enaSlipType.toString();
        
        if (strEnaSlipType.equals("N") == true)
        {
          //�`�[��ʖ����G���[
          throw new OAException("XX03", "APP-XX03-14152");
        }
        else if (strEnaSlipType.equals("A") == true)
        {
          //�A�v���P�[�V�������o�^�̓`�[��ʃG���[
          throw new OAException("XX03", "APP-XX03-14153");
        }
        //Ver11.5.10.1.6B 2005/12/27 Add End

      }
      //Ver11.5.10.1.6B 2005/12/27 Add Start
      catch(OAException ex)
      {
        throw OAException.wrapperException(ex);
      }
      //Ver11.5.10.1.6B 2005/12/27 Add End
      catch(Exception ex)
      {
        // debug
        ex.printStackTrace();
      
        // �V�X�e���G���[
        throw new OAException("XX03",
                              "APP-XX03-13008",
                              ex);
      }
    } // �߂�{�^���Ή�
  } // processRequest

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    
    try
    {
      // ***************************************************************************
      // * ����
      // ***************************************************************************
      // ��ʑJ�ڃp�����[�^
      HashMap parameters = new HashMap(4);

      // �A�v���P�[�V�����E���W���[���̎擾 
      OAApplicationModule am = pageContext.getApplicationModule(webBean);

      // ��ʍ��ڂ̎擾
      // �����ԍ�
      String receivableId = ((OAFormValueBean)webBean.findChildRecursive("ReceivableId")).getValue(pageContext).toString();
      OASubTabLayoutBean invoiceLineRN = (OASubTabLayoutBean)webBean.findChildRecursive("InvoiceLineRN");

// ver 1.2 Add Start Submit���A������Ńt���O��ŃR�[�h����擾���Ȃ���
      // ���Ńt���O�̐ݒ�
      am.invokeMethod("setIncludesTaxFlag");
// ver 1.2 Add End

      // *************************************************************************
      // * �^�u
      // *************************************************************************
      if (invoiceLineRN.isSubTabClicked(pageContext))
      {
        // ������v�擾(�d���������\������f�[�^�̂ݎ��s)
        am.invokeMethod("getAutoAccountingTab");
          
        pageContext.putTransactionValue("tab", Xx03ArCommonUtil.STR_YES);
        return;
      }
      
      // *************************************************************************
      // * LOV
      // *************************************************************************
/*
 �v���t�@�C���I�v�V�����F�uFND�F�t���[�����[�N�݊����[�h�v��11.5.10�łȂ���LOV���̓G���A
 ����Tab�����őJ�ڂ����ꍇ�ɓ���s�������̂ŃR�����g�A�E�g
      if (pageContext.isLovEvent())
      {
        // �C�x���g���N����LOV����肷��
        String lovInputId = pageContext.getLovInputSourceId();
        // �ڋqLOV�̏ꍇ
        if ("Customer".equals(lovInputId))
        {
          // LOVItem�p�����[�^�Z�b�g�㎩��ʑJ��
          java.util.Hashtable lovResult = pageContext.getLovResultsFromSession(lovInputId);
          String firstCustomerFlag = "N";
          String autoTaxCalcFlagWkHeader = "";
          String taxRoundingRuleWkHeader = "";
          if (lovResult != null)
          {
            // �ꌩ�ڋq�敪�擾
            firstCustomerFlag =  (String)lovResult.get("FirstCustomerFlag");
            // ����Ōv�Z���x���擾
            autoTaxCalcFlagWkHeader =  (String)lovResult.get("AutoTaxCalcFlagWkHeader");
            // ����Œ[�������擾
            taxRoundingRuleWkHeader =  (String)lovResult.get("TaxRoundingRuleWkHeader");
          }

          parameters.put("paramFirstCustomer", firstCustomerFlag);
          parameters.put("paramAutoTaxCalcFlagWkHeader", autoTaxCalcFlagWkHeader);
          parameters.put("paramTaxRoundingRuleWkHeader", taxRoundingRuleWkHeader);
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
          pageContext.setForwardURLToCurrentPage(
            parameters, // parameter
            true,       // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
            OAException.INFORMATION);
        }
        // �ڋq���Ə�LOV�̏ꍇ
        else if("CustomerLocation".equals(lovInputId))
        {
          // �u�㏑�̋��v�I�v�V�����擾
          String strTaxOverride = (String)am.invokeMethod("getTaxOverride");

          // �u�㏑�̋��v��'Y'�̏ꍇ
          if (strTaxOverride.equals("Y"))
          {
            // �ڋq���Ə��̏���Ōv�Z���x���A�[���������擾
            java.util.Hashtable lovResult = pageContext.getLovResultsFromSession(lovInputId);
            String autoTaxCalcFlagWk = null;
            String taxRoundingRuleWk = null;
            if (lovResult != null)
            {
              // ���Ə��̏���Ōv�Z���x���A�[�������擾
              autoTaxCalcFlagWk =  (String)lovResult.get("AutoTaxCalcFlagWkDetail");
              taxRoundingRuleWk =  (String)lovResult.get("TaxRoundingRuleWkDetail");
            }

            // ���Ə��̏���Ōv�Z���x���A�[���������ݒ肳��Ă��Ȃ��ꍇ
            if ((autoTaxCalcFlagWk == null || autoTaxCalcFlagWk.equals(""))
                 || (taxRoundingRuleWk == null || taxRoundingRuleWk.equals("")))
            {
              // �ڋq�̏���Ōv�Z���x���A�[�������擾
              autoTaxCalcFlagWk = (String)Xx03ArCommonUtil.getParameterValue(pageContext, "paramAutoTaxCalcFlagWkHeader");
              taxRoundingRuleWk = (String)Xx03ArCommonUtil.getParameterValue(pageContext, "paramTaxRoundingRuleWkHeader");
            }

            // �㏑�̋���'Y'�A�����Ə����ڋq�̏���Ōv�Z���x���A�[���������ݒ��
            if ((autoTaxCalcFlagWk != null && !autoTaxCalcFlagWk.equals(""))
                 && (taxRoundingRuleWk != null && !taxRoundingRuleWk.equals("")))
            {
              // �g�p�������Ōv�Z���x���A�[���������p�����[�^�ɃZ�b�g������ʑJ��
              parameters.put("paramAutoTaxCalcFlag", autoTaxCalcFlagWk);
              parameters.put("paramTaxRoundingRule", taxRoundingRuleWk);
              parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
              pageContext.setForwardURLToCurrentPage(
                parameters, // parameter
                true,       // ratainAM
                OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
                OAException.INFORMATION);
              // Item�ɒl���Z�b�g���Ă��Z�b�g�����l���m�肳��Ȃ��̂Ŏ���ʑJ�ڂ���
              //OAFormValueBean autoTaxCalcFlag = (OAFormValueBean)webBean.findChildRecursive("AutoTaxCalcFlag");
              //OAFormValueBean taxRoundingRule = (OAFormValueBean)webBean.findChildRecursive("TaxRoundingRule");
              //autoTaxCalcFlag.setValue(pageContext, autoTaxCalcFlagWk);
              //taxRoundingRule.setValue(pageContext, taxRoundingRuleWk);
            }
          }
        }
      }
*/

      // ���ו\�������̎擾
      OAAdvancedTableBean invoiceLinesDetail = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesDetailRN");
      OAAdvancedTableBean invoiceLinesJournal = (OAAdvancedTableBean)webBean.findIndexedChildRecursive("InvoiceLinesJournalRN");
      Integer invoiceLinesDetailCnt = new Integer(invoiceLinesDetail.getNumberOfRowsDisplayed());
      Integer invoiceLinesJournalCnt = new Integer(invoiceLinesJournal.getNumberOfRowsDisplayed());
      Boolean forceFlag = BooleanUtils.getBoolean(false);

      // *************************************************************************
      // * �ۑ�
      // *************************************************************************
      if (pageContext.getParameter("Save") != null)
      {
        // Ver11.5.10.1.5 add start
        // ���ד��̓`�F�b�N
        //ver11.5.10.2.6 Chg Start
        //checkLineInput(pageContext, webBean);
        am.invokeMethod("checkLineInput");
        //ver11.5.10.2.6 Chg Start
        // Ver11.5.10.1.5 add end

        Serializable[] methodParams = null;
        Class[] methodParamTypes = null;
          
        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");
        
        // �O��[���`�[�g�p�`�F�b�N
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        if (commitmentNumber.getValue(pageContext) != null)
        {
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          String strCommitmentNumber = (String)commitmentNumber.getValue(pageContext);
          String strReceivableNum = (String)receivableNum.getValue(pageContext);
          if (strReceivableNum == null)
          {
            strReceivableNum = "";
          }
          methodParams = new Serializable[]{strCommitmentNumber, strReceivableNum};
          methodParamTypes = new Class[]{strCommitmentNumber.getClass(), strReceivableNum.getClass()};
          String useCommitmentNumber = (String)am.invokeMethod("checkCommitmentNumber", methodParams, methodParamTypes);
          if (useCommitmentNumber != null)
          {
            // �O��[���`�[
            MessageToken[] tokens = {new MessageToken("TRX_NUMBER", useCommitmentNumber)};
            throw new OAException("XX03","APP-XX03-13052", tokens);
          }
          // ver1.3 add start ---------------------------------------------------------
          else
          {
            //�O����̖�������`�F�b�N
            // ver1.4 add start ---------------------------------------------------------
            //�O����̖�������`�F�b�N���s��AM���Ăяo���B
            am.invokeMethod("checkCommitmentDate");
            // ver1.4 add end -----------------------------------------------------------

// ver1.4 delete start ------------------------------------------------------
//            OAFormValueBean startDateCommitment = (OAFormValueBean)webBean.findChildRecursive("StartDateCommitment");
//            OAFormValueBean endDateCommitment = (OAFormValueBean)webBean.findChildRecursive("EndDateCommitment");
//            OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//            Date startDate = null;
//            Date endDate = null;
//            Date invDate = null;
//
//            invDate = new Date(invoiceDate.getValue(pageContext));
//            startDate = new Date(startDateCommitment.getValue(pageContext));
//            if(endDateCommitment.getValue(pageContext) != null)
//            {
//              endDate = new Date(endDateCommitment.getValue(pageContext));
//            }
//            else
//            {
//              endDate = invDate;
//            }                 
//            methodParams = new Serializable[]{startDate, endDate, invDate};
//            methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//            am.invokeMethod("checkCommitmentDate", methodParams, methodParamTypes);
// ver1.4 delete end --------------------------------------------------------
          }            
        }

// ver1.4 delete start ------------------------------------------------------
        // �x�����@�̗L�����`�F�b�N
//        OAMessageLovInputBean paymentWay = (OAMessageLovInputBean)webBean.findChildRecursive("PaymentWay");
//        if (paymentWay.getValue(pageContext) != null)
//        {
//          OAFormValueBean startDatePayment = (OAFormValueBean)webBean.findChildRecursive("StartDatePaymentWay");
//          OAFormValueBean endDatePayment = (OAFormValueBean)webBean.findChildRecursive("EndDatePaymentWay");
//          OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//          Date startDate = null;
//          Date endDate = null;
//          Date invDate = null;
//
//          invDate = new Date(invoiceDate.getValue(pageContext));
//          startDate = new Date(startDatePayment.getValue(pageContext));
//          if(endDatePayment.getValue(pageContext) != null)
//          {
//            endDate = new Date(endDatePayment.getValue(pageContext));
//          }
//          else
//          {
//            endDate = invDate;
//          }                 
//          methodParams = new Serializable[]{startDate, endDate, invDate};
//          methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//          am.invokeMethod("checkPaymentDate", methodParams, methodParamTypes);              
//        }  
// ver1.4 delete end -------------------------------------------------------- */      
        // ver1.3 add end -----------------------------------------------------------

        // �̔�
        String num_type = Xx03ArCommonUtil.TEMP_SLIP_NUM_TYPE;
        String requestEnableFlag = Xx03ArCommonUtil.STR_NO;
        methodParams = new Serializable[]{num_type, requestEnableFlag};
        methodParamTypes = new Class[]{num_type.getClass(), requestEnableFlag.getClass()};
        am.invokeMethod("publishNum", methodParams, methodParamTypes);

        // �ۑ�
        am.invokeMethod("save");

        // ��ʑJ�� ���������ԍ��̕\��/��\���؂�ւ����������׎���ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_SAVE);

        pageContext.setForwardURLToCurrentPage(
          parameters, // parameter
          true,       // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
          OAException.INFORMATION);
      }
      // *************************************************************************
      // * ����Ŏ����v�Z
      // *************************************************************************
      else if (pageContext.getParameter("CalculateTax") != null)
      {
        // Ver11.5.10.1.5 add start
        //Ver11.5.10.1.6D 2006/01/18 Delete Start
        // // ���ד��̓`�F�b�N
        //checkLineInput(pageContext, webBean);
        //Ver11.5.10.1.6D 2006/01/18 Delete End
        // Ver11.5.10.1.5 add end

        // ���͋��z�Z�o
        am.invokeMethod("calculateInput");
        
        // ����ōČv�Z
        //Ver11.5.10.1.6D 2006/01/18 Change Start
        //am.invokeMethod("calculateTax");
        Vector msg = (Vector)am.invokeMethod("calculateTax");
        if ((msg != null) && (msg.size() > 0))
        {
          throw OAException.getBundledOAException(msg);
        }
        //Ver11.5.10.1.6D 2006/01/18 Change End

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");
      }
      // *************************************************************************
      // * �m�F
      // *************************************************************************
      else if (pageContext.getParameter("Confirm") != null)
      {
        // Ver11.5.10.1.5 add start
        // ���ד��̓`�F�b�N
        //ver11.5.10.2.6 Chg Start
        //checkLineInput(pageContext, webBean);
        am.invokeMethod("checkLineInput");
        //ver11.5.10.2.6 Chg Start
        // Ver11.5.10.1.5 add end
        // Ver11.5.10.1.5 add end

        Serializable[] methodParams = null;
        Class[] methodParamTypes = null;
        
        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");

        // �O��[���`�[�g�p�`�F�b�N
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        //Ver11.5.10.1.4B 2005/08/05 Add Start
        OAMessageLovInputBean paymentWay = (OAMessageLovInputBean)webBean.findChildRecursive("PaymentWay");
        //Ver11.5.10.1.4B 2005/08/05 Add End
        
        if (commitmentNumber.getValue(pageContext) != null)
        {
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          String strCommitmentNumber = (String)commitmentNumber.getValue(pageContext);
          String strReceivableNum = (String)receivableNum.getValue(pageContext);
          if (strReceivableNum == null)
          {
            strReceivableNum = "";
          }
          methodParams = new Serializable[]{strCommitmentNumber, strReceivableNum};
          methodParamTypes = new Class[]{strCommitmentNumber.getClass(), strReceivableNum.getClass()};
          String useCommitmentNumber = (String)am.invokeMethod("checkCommitmentNumber", methodParams, methodParamTypes);
          if (useCommitmentNumber != null)
          {
            // �O��[���`�[
            MessageToken[] tokens = {new MessageToken("TRX_NUMBER", useCommitmentNumber)};
            throw new OAException("XX03","APP-XX03-13052", tokens);
          }
          // ver1.3 add start ---------------------------------------------------------
          else
          {
            //�O����̖�������`�F�b�N
            // ver1.4 add start ---------------------------------------------------------
            //�O����̖�������`�F�b�N���s��AM���Ăяo���B
            am.invokeMethod("checkCommitmentDate");
            // ver1.4 add end -----------------------------------------------------------
// ver1.4 delete start ------------------------------------------------------
//            OAFormValueBean startDateCommitment = (OAFormValueBean)webBean.findChildRecursive("StartDateCommitment");
//            OAFormValueBean endDateCommitment = (OAFormValueBean)webBean.findChildRecursive("EndDateCommitment");
//            OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//            Date startDate = null;
//            Date endDate = null;
//            Date invDate = null;
//
//            invDate = new Date(invoiceDate.getValue(pageContext));
//            startDate = new Date(startDateCommitment.getValue(pageContext));
//            if(endDateCommitment.getValue(pageContext) != null)
//            {
//              endDate = new Date(endDateCommitment.getValue(pageContext));
//            }
//            else
//            {
//              endDate = invDate;
//            }                 
//            methodParams = new Serializable[]{startDate, endDate, invDate};
//            methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//            am.invokeMethod("checkCommitmentDate", methodParams, methodParamTypes); 
// ver1.4 delete end --------------------------------------------------------
          }            
        }

        //ver11.5.10.1.6 Del Start
        //// �x�����@�̗L�����`�F�b�N
        //// ver1.4 add start ---------------------------------------------------------
        //// �x�����@�̗L�����`�F�b�N���s��AM���Ăяo���B
        ////Ver11.5.10.1.4B 2005/08/05 Modify Start
        //if (paymentWay.getValue(pageContext) != null)
        //{
        //  am.invokeMethod("checkPaymentDate");
        //}
        ////Ver11.5.10.1.4B 2005/08/05 Modify End
        //ver11.5.10.1.6 Del End

        
        // ver1.4 add end -----------------------------------------------------------
// ver1.4 delete start ------------------------------------------------------
//        OAMessageLovInputBean paymentWay = (OAMessageLovInputBean)webBean.findChildRecursive("PaymentWay");
//        if (paymentWay.getValue(pageContext) != null)
//        {
//          OAFormValueBean startDatePayment = (OAFormValueBean)webBean.findChildRecursive("StartDatePaymentWay");
//          OAFormValueBean endDatePayment = (OAFormValueBean)webBean.findChildRecursive("EndDatePaymentWay");
//          OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//          Date startDate = null;
//          Date endDate = null;
//          Date invDate = null;
//
//          invDate = new Date(invoiceDate.getValue(pageContext));
//          startDate = new Date(startDatePayment.getValue(pageContext));
//          if(endDatePayment.getValue(pageContext) != null)
//          {
//            endDate = new Date(endDatePayment.getValue(pageContext));
//          }
//          else
//          {
//            endDate = invDate;
//          }                 
//          methodParams = new Serializable[]{startDate, endDate, invDate};
//          methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//          am.invokeMethod("checkPaymentDate", methodParams, methodParamTypes);              
//        }
// ver1.4 delete end --------------------------------------------------------
        // ver1.3 add end -----------------------------------------------------------

        //ver11.5.10.1.6 Add Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkSelfValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver11.5.10.1.6 Add End

        // �̔�
        String num_type = Xx03ArCommonUtil.TEMP_SLIP_NUM_TYPE;
        String requestEnableFlag = Xx03ArCommonUtil.STR_YES;
        methodParams = new Serializable[]{num_type, requestEnableFlag};
        methodParamTypes = new Class[]{num_type.getClass(), requestEnableFlag.getClass()};
        am.invokeMethod("publishNum", methodParams, methodParamTypes);
        
        // �ۑ�
        am.invokeMethod("save");

        // �d��`�F�b�N�֐��̌ďo
        Number checkReceivableId = new Number(receivableId);
        methodParams = new Serializable[]{checkReceivableId};
        methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msg = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msg.firstElement().toString();
        msg.removeElementAt(0);

        //Ver11.5.10.1.4 2005/07/07 Modify Start
        //if (!Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode))
        if (!(Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode) ||
              Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode)))
        //Ver11.5.10.1.4 2005/07/07 Modify End
        {
          throw OAException.getBundledOAException(msg);
        }

        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_CONFIRM);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_CONFIRM,    // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );     
      }
      // *************************************************************************
      // * �Čv�Z
      // *************************************************************************
      else if (pageContext.getParameter("Recalculate") != null)
      {
        // Ver11.5.10.1.5 add start
        // ���ד��̓`�F�b�N
        //ver11.5.10.2.6 Chg Start
        //checkLineInput(pageContext, webBean);
        am.invokeMethod("checkLineInput");
        //ver11.5.10.2.6 Chg Start
        // Ver11.5.10.1.5 add end
        // Ver11.5.10.1.5 add end

        // ���͋��z�Z�o
        am.invokeMethod("calculateInput"); 

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �ʉ݂ɂ����z�t�H�[�}�b�g
        am.invokeMethod("formatAmount");
      }
      // *************************************************************************
      // * ���׃R�s�[
      // *************************************************************************
      else if (pageContext.getParameter("CopyLine") != null)
      {      
        //Ver11.5.10.1.6E Change Start
        // �r���ŗ�O�����������ꍇ�ł��A�Ō�܂ŏ�������B
        //am.invokeMethod("copyLine");
        // // ���אݒ�s���擾
        //Number detailCount = new Number(invoiceLinesDetailCnt.intValue());
        //Serializable[] methodParams = {detailCount};
        //Class[] methodParamTypes = {detailCount.getClass()};
        //am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes); 
        //am.invokeMethod("resetLineNumber");

        ArrayList exceptions=new ArrayList();
        try
        {
          // �R�s�[
          am.invokeMethod("copyLine");
        }
        catch(Exception e)
        {
          exceptions.add(OAException.wrapperException(e));
        }
        try
        {
          // ���`
          Number detailCount = new Number(invoiceLinesDetailCnt.intValue());
          Serializable[] methodParams = {detailCount};
          Class[] methodParamTypes = {detailCount.getClass()};
          am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes); 
        }
        catch(Exception e)
        {
          exceptions.add(OAException.wrapperException(e));
        }
        try
        {
          am.invokeMethod("resetLineNumber");
        }
        catch(Exception e)
        {
          exceptions.add(OAException.wrapperException(e));
        }
        Xx03CommonUtil.raiseBundledOAException(exceptions);
        //Ver11.5.10.1.6E Change End
      }
      // *************************************************************************
      // * ���׍폜
      // *************************************************************************
      else if (pageContext.getParameter("DeleteLine") != null)
      {
        am.invokeMethod("deleteLine");
        // ���אݒ�s���擾
        Number detailCount = new Number(invoiceLinesDetailCnt.intValue());
        Serializable[] methodParams = {detailCount};
        Class[] methodParamTypes = {detailCount.getClass()};
        am.invokeMethod("createReceivableSlipLines", methodParams, methodParamTypes); 
        am.invokeMethod("resetLineNumber");      
      }
      // *************************************************************************
      // * ���גǉ�
      // *************************************************************************
      else if (pageContext.getParameter("AddLine") != null)
      {
        // AdvancedTable���[�W�����g�p���̃��[��(Develper's Guide P942)
        invoiceLinesDetail.queryData(pageContext, true);
        invoiceLinesJournal.queryData(pageContext, true);

        // ���גǉ�
        am.invokeMethod("addReceivableSlipLines");
      }
      // *************************************************************************
      // * ������v
      // *************************************************************************
      else if (pageContext.getParameter("AutoAccounting") != null)
      {
        am.invokeMethod("getAutoAccounting");
      }
      // *************************************************************************
      // * �ꌩ�ڋq����
      // *************************************************************************
      else if (pageContext.getParameter("FirstCustomerInput") != null)
      {
        Serializable[] methodParams = null;
        Class[] methodParamTypes = null;

        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �O��[���`�[�g�p�`�F�b�N
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        if (commitmentNumber.getValue(pageContext) != null)
        {
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          String strCommitmentNumber = (String)commitmentNumber.getValue(pageContext);
          String strReceivableNum = (String)receivableNum.getValue(pageContext);
          if (strReceivableNum == null)
          {
            strReceivableNum = "";
          }
          methodParams = new Serializable[]{strCommitmentNumber, strReceivableNum};
          methodParamTypes = new Class[]{strCommitmentNumber.getClass(), strReceivableNum.getClass()};
          String useCommitmentNumber = (String)am.invokeMethod("checkCommitmentNumber", methodParams, methodParamTypes);
          if (useCommitmentNumber != null)
          {
            // �O��[���`�[
            MessageToken[] tokens = {new MessageToken("TRX_NUMBER", useCommitmentNumber)};
            throw new OAException("XX03","APP-XX03-13052", tokens);
          }
          // ver1.3 add start ---------------------------------------------------------
          else
          {
            //�O����̖�������`�F�b�N
            // ver1.4 add start ---------------------------------------------------------
            //�O����̖�������`�F�b�N���s��AM���Ăяo���B
            am.invokeMethod("checkCommitmentDate");
            // ver1.4 add end -----------------------------------------------------------
// ver1.4 delete start ------------------------------------------------------
//            OAFormValueBean startDateCommitment = (OAFormValueBean)webBean.findChildRecursive("StartDateCommitment");
//            OAFormValueBean endDateCommitment = (OAFormValueBean)webBean.findChildRecursive("EndDateCommitment");
//            OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//            Date startDate = null;
//            Date endDate = null;
//            Date invDate = null;
//
//            invDate = new Date(invoiceDate.getValue(pageContext));
//            startDate = new Date(startDateCommitment.getValue(pageContext));
//            if(endDateCommitment.getValue(pageContext) != null)
//            {
//              endDate = new Date(endDateCommitment.getValue(pageContext));
//            }
//            else
//            {
//              endDate = invDate;
//            }                 
//            methodParams = new Serializable[]{startDate, endDate, invDate};
//            methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//            am.invokeMethod("checkCommitmentDate", methodParams, methodParamTypes); 
// ver1.4 delete end --------------------------------------------------------
          }            
        }

// ver1.4 delete start ------------------------------------------------------
        // �x�����@�̗L�����`�F�b�N
//        OAMessageLovInputBean paymentWay = (OAMessageLovInputBean)webBean.findChildRecursive("PaymentWay");
//        if (paymentWay.getValue(pageContext) != null)
//        {
//          OAFormValueBean startDatePayment = (OAFormValueBean)webBean.findChildRecursive("StartDatePaymentWay");
//          OAFormValueBean endDatePayment = (OAFormValueBean)webBean.findChildRecursive("EndDatePaymentWay");
//          OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//          Date startDate = null;
//          Date endDate = null;
//          Date invDate = null;
//
//          invDate = new Date(invoiceDate.getValue(pageContext));
//          startDate = new Date(startDatePayment.getValue(pageContext));
//          if(endDatePayment.getValue(pageContext) != null)
//          {
//            endDate = new Date(endDatePayment.getValue(pageContext));
//          }
//          else
//          {
//            endDate = invDate;
//          }                 
//          methodParams = new Serializable[]{startDate, endDate, invDate};
//          methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//          am.invokeMethod("checkPaymentDate", methodParams, methodParamTypes);              
//        } 
// ver1.4 delete end --------------------------------------------------------
        // ver1.3 add end -----------------------------------------------------------

        // �̔�
        String num_type = Xx03ArCommonUtil.TEMP_SLIP_NUM_TYPE;
        String requestEnableFlag = Xx03ArCommonUtil.STR_NO;
        methodParams = new Serializable[]{num_type, requestEnableFlag};
        methodParamTypes = new Class[]{num_type.getClass(), requestEnableFlag.getClass()};
        am.invokeMethod("publishNum", methodParams, methodParamTypes);
        
        // �ۑ�
        am.invokeMethod("save");

        // �ꌩ�ڋq�敪�`�F�b�N
        Object firstCustomerFlag = ((OAFormValueBean)webBean.findChildRecursive("FirstCustomerFlag")).getValue(pageContext);
        if ((firstCustomerFlag != null) && (firstCustomerFlag.toString().equals(Xx03ArCommonUtil.STR_YES)))
        {
          // �ꌩ�ڋq�敪'Y'�̏ꍇ�͉�ʑJ��
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_FIRST_CUSTOMER);
          parameters.put("receivableId", receivableId);
          parameters.put("custType", Xx03ArCommonUtil.STR_YES);

          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_FIRST_CUSTOMER, // url
            null,                                       // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,       // menuContextAction
            null,                                       // menuName
            parameters,                                 // parameter
            false,                                      // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,      // addBreadCrumb
            OAException.INFORMATION                     // messagingLevel
          );
        }
        else
        {
          // �ꌩ�ڋq�敪'N'�̏ꍇ�̓G���[���b�Z�[�W�\��
          throw new OAException("XX03", "APP-XX03-13048");
        }
      }
      // *************************************************************************
      // * �O���
      // *************************************************************************
      else if (pageContext.getParameter("PrePaidMoney") != null)
      {
        Serializable[] methodParams = null;
        Class[] methodParamTypes = null;

        // �x���\����擾
        am.invokeMethod("getDueDate");

        // �Čv�Z
        am.invokeMethod("recalculate");

        // �O��[���`�[�g�p�`�F�b�N
        OAMessageLovInputBean commitmentNumber = (OAMessageLovInputBean)webBean.findChildRecursive("CommitmentNumber");
        if (commitmentNumber.getValue(pageContext) != null)
        {
          OAWebBeanStyledText receivableNum = (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");
          String strCommitmentNumber = (String)commitmentNumber.getValue(pageContext);
          String strReceivableNum = (String)receivableNum.getValue(pageContext);
          if (strReceivableNum == null)
          {
            strReceivableNum = "";
          }
          methodParams = new Serializable[]{strCommitmentNumber, strReceivableNum};
          methodParamTypes = new Class[]{strCommitmentNumber.getClass(), strReceivableNum.getClass()};
          String useCommitmentNumber = (String)am.invokeMethod("checkCommitmentNumber", methodParams, methodParamTypes);
          if (useCommitmentNumber != null)
          {
            // �O��[���`�[
            MessageToken[] tokens = {new MessageToken("TRX_NUMBER", useCommitmentNumber)};
            throw new OAException("XX03","APP-XX03-13052", tokens);
          }
          // ver1.3 add start ---------------------------------------------------------
          else
          {
            //�O����̖�������`�F�b�N
            // ver1.4 add start ---------------------------------------------------------
            //�O����̖�������`�F�b�N���s��AM���Ăяo���B
            am.invokeMethod("checkCommitmentDate");
            // ver1.4 add end -----------------------------------------------------------
// ver1.4 delete start ------------------------------------------------------
//            OAFormValueBean startDateCommitment = (OAFormValueBean)webBean.findChildRecursive("StartDateCommitment");
//            OAFormValueBean endDateCommitment = (OAFormValueBean)webBean.findChildRecursive("EndDateCommitment");
//            OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//            Date startDate = null;
//            Date endDate = null;
//            Date invDate = null;
//
//            invDate = new Date(invoiceDate.getValue(pageContext));
//            startDate = new Date(startDateCommitment.getValue(pageContext));
//            if(endDateCommitment.getValue(pageContext) != null)
//            {
//              endDate = new Date(endDateCommitment.getValue(pageContext));
//            }
//            else
//            {
//              endDate = invDate;
//            }                 
//            methodParams = new Serializable[]{startDate, endDate, invDate};
//            methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//            am.invokeMethod("checkCommitmentDate", methodParams, methodParamTypes); 
// ver1.4 delete end --------------------------------------------------------
          }            
        }

// ver1.4 delete start ------------------------------------------------------
        // �x�����@�̗L�����`�F�b�N
//        OAMessageLovInputBean paymentWay = (OAMessageLovInputBean)webBean.findChildRecursive("PaymentWay");
//        if (paymentWay.getValue(pageContext) != null)
//        {
//          OAFormValueBean startDatePayment = (OAFormValueBean)webBean.findChildRecursive("StartDatePaymentWay");
//          OAFormValueBean endDatePayment = (OAFormValueBean)webBean.findChildRecursive("EndDatePaymentWay");
//          OAMessageDateFieldBean invoiceDate = (OAMessageDateFieldBean)webBean.findChildRecursive("InvoiceDate"); 
//          
//          Date startDate = null;
//          Date endDate = null;
//          Date invDate = null;
//
//          invDate = new Date(invoiceDate.getValue(pageContext));
//          startDate = new Date(startDatePayment.getValue(pageContext));
//          if(endDatePayment.getValue(pageContext) != null)
//          {
//            endDate = new Date(endDatePayment.getValue(pageContext));
//          }
//          else
//          {
//            endDate = invDate;
//          }                 
//          methodParams = new Serializable[]{startDate, endDate, invDate};
//          methodParamTypes = new Class[]{startDate.getClass(), endDate.getClass(), invDate.getClass()};
//          am.invokeMethod("checkPaymentDate", methodParams, methodParamTypes);              
//        }
// ver1.4 delete end --------------------------------------------------------
          // ver1.3 add end --------------------------------------------------------

        // �̔�
        String num_type = Xx03ArCommonUtil.TEMP_SLIP_NUM_TYPE;
        String requestEnableFlag = Xx03ArCommonUtil.STR_NO;
        methodParams = new Serializable[]{num_type, requestEnableFlag};
        methodParamTypes = new Class[]{num_type.getClass(), requestEnableFlag.getClass()};
        am.invokeMethod("publishNum", methodParams, methodParamTypes);
        
        // �ۑ�
        am.invokeMethod("save");

        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_INPUT);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_PREPAY);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_PREPAY,         // url
          null,                                       // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,       // menuContextAction
          null,                                       // menuName
          parameters,                                 // parameter
          false,                                      // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,      // addBreadCrumb
          OAException.INFORMATION                     // messagingLevel
        );
      }
    }
    catch(OAException ex)
    {
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      ex.printStackTrace();      
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            null,
                            OAException.ERROR,
                            null);
    }
  } // processFormRequest


  /**
   * �ꌩ�ڋq�{�^���g�p�A�s�̐ݒ�
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   * @param tableFirstCustomerFlag �e�[�u���̈ꌩ�ڋq�敪
   */
  private void setFirstCustomerRenderd(OAPageContext pageContext, OAWebBean webBean,
    String tableFirstCustomerFlag)
  {
    // �ꌩ�ڋq�{�^���\���ؑ�
    OASubmitButtonBean FirstCustomerInput = 
      (OASubmitButtonBean)webBean.findChildRecursive("FirstCustomerInput");
    Object firstCustomer = Xx03ArCommonUtil.getParameterValue(pageContext, "paramFirstCustomer");
    if (firstCustomer != null)
    {
      // �p�����[�^�̈ꌩ�ڋq�敪������ꍇ
      if (firstCustomer.toString().equals("Y"))
      {
        // �p�����[�^�̈ꌩ�ڋq�敪��'Y'
        FirstCustomerInput.setDisabled(false);
      }
      else
      {
        // �p�����[�^�̈ꌩ�ڋq�敪��'Y'�ȊO
        FirstCustomerInput.setDisabled(true);
      }
    }
    else{
      // �p�����[�^�̈ꌩ�ڋq�敪���Ȃ��ꍇ�̓e�[�u���̒l���Q��
      if (tableFirstCustomerFlag != null)
      {
        if (tableFirstCustomerFlag.equals(Xx03ArCommonUtil.STR_YES))
        {
          // �e�[�u���̈ꌩ�ڋq�敪��'Y'
          FirstCustomerInput.setDisabled(false);
        }
        else
        {
          // �e�[�u���̈ꌩ�ڋq�敪��'Y'�ȊO
          FirstCustomerInput.setDisabled(true);
        }
      }
      else
      {
        // �p�����[�^�̒l���e�[�u���̒l���Ȃ�
        FirstCustomerInput.setDisabled(true);
      }
    }
  }

  //ver11.5.10.2.6 Del Start
  //// Ver11.5.10.1.5 add start
  ///**
  // * ���ד��̓`�F�b�N
  // * 
  // * @param   pageContext   �y�[�W�E�R���e�L�X�g
  // * @param   webBean       �E�F�u�E�r�[��
  // * @return
  // */
  //private void checkLineInput(OAPageContext pageContext, OAWebBean webBean)
  //{
  //  OAFormValueBean segment11 = (OAFormValueBean)webBean.findChildRecursive("Segment11");
  //
  //  if (segment11.getValue(pageContext) == null)
  //  {
  //    throw new OAException("XX03",
  //                          "APP-XX03-13057",
  //                          null,
  //                          OAException.ERROR,
  //                          null);      
  //  }
  //} // checkLineInput
  // Ver11.5.10.1.5 add end
  //ver11.5.10.2.6 Del End

}

   