/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005  All rights reserved
 * FILENAME     XX03TaxCodesLovCO.java
 * VERSION      11.5.10.1.6
 * DATE         2005/12/22
 * HISTORY      2005/12/22 ver 11.5.10.1.6  �V�K�쐬�i�ŋ敪�̗L���`�F�b�N�Ή��j
 *===========================================================================*/
package oracle.apps.xx03.common.lov.webui;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import java.io.Serializable;
import oracle.cabo.ui.UIConstants;
import oracle.jbo.domain.Date;
import java.util.Dictionary;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;

import oracle.apps.fnd.framework.OAException;

/**
 * Controller for ...
 */
public class XX03TaxCodesLovCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);
    preparedLovQuery(pageContext, webBean);
  }

  /**
   * lov�̌��������̎��s
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  private void preparedLovQuery(OAPageContext pageContext, OAWebBean webBean)
  {
    // get VO Name
    OAMessageStyledTextBean taxCodesCol =
      (OAMessageStyledTextBean)webBean.findChildRecursive("taxCodesCol");
    String colVoName = taxCodesCol.getViewUsageName();

    // get AM
    OAApplicationModule am   = pageContext.getApplicationModule(webBean);

    // get where clause
    String searchText        = pageContext.getParameter(UIConstants.LOV_SEARCH_TEXT);
    String lovCategoryChoice = pageContext.getParameter(OAWebBeanConstants.LOV_CATEGORY_CHOICE);
  
    // get CriteriaValue
    Dictionary passiveCriteriaItems = pageContext.getLovCriteriaItems();
    String parentDateTemp = passiveCriteriaItems.get("invoiceDate").toString();
    
    Date parentDate = null;
    try
    {
      parentDate = new Date(oracle.sql.DATE.fromText(parentDateTemp,"YYYY/MM/DD",""));
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
        throw new OAException("XX03",
                              "APP-XX03-08014",
                              null,
                              OAException.ERROR,
                              null);
    }

    if (null == lovCategoryChoice)
    {
      // null�̏ꍇ�͐ŋ敪�������s��
      lovCategoryChoice = "taxCodesCol";
    }

    // setWhereClauseOnLovQuery
    Serializable[] methodParams     = {searchText, lovCategoryChoice, colVoName, parentDate};
    Class[]        methodParamTypes = {searchText.getClass(), lovCategoryChoice.getClass(), colVoName.getClass(), parentDate.getClass()};
    am.invokeMethod("setWhereClauseOnLovQuery", methodParams, methodParamTypes); 
  }

}
