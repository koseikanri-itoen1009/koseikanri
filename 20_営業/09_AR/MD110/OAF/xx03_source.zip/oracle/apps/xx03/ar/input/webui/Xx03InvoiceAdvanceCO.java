/*============================================================================
 *  Copyright (c) Oracle Corporation Japan, 2004 - 2005. All rights reserved.
 *  FILENAME    Xx03InvoiceAdvanceCO.java
 *  VERSION     11.5.10.1.6B
 *  DATE        2006/02/14
 *  HISTORY     2005/01/21  Ver1.0          �V�K�쐬
 *              2005/03/01  Ver1.1          ���z��0�ȉ��̒l����͂ł��Ȃ��悤�ύX
 *              2006/02/02  Ver11.5.10.1.6  �{�^���̃_�u���N���b�N�Ή�
 *              2006/02/14  Ver11.5.10.1.6B ��Q910�ŋ敪�̓��t�i���݂���߂�
 *===========================================================================*/
package oracle.apps.xx03.ar.input.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;
import java.util.ArrayList;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;

import oracle.jbo.domain.Number;

//ver11.5.10.1.6 Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6 Add End

/**
  * Xx03InvoiceAdvanceCO �O�����ʂ�Controller
  * @version ver 11.5.10.1.6B
  */
public class Xx03InvoiceAdvanceCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //�A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    //ver11.5.10.1.6 Add Start
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6 Add End

    try
    {
      //���ʏ���
      //�p�����[�^�擾
      String pageStatus = null; //�J�ڌ���ʖ�
      String funcButton = null; //�����{�^����

      Object tmpPageStatus = Xx03ArCommonUtil.getParameterValue(pageContext,"pageStatus");
      Object tmpFuncButton = Xx03ArCommonUtil.getParameterValue(pageContext,"funcButton");
      
      if(tmpPageStatus == null)
      {
        //�p�����[�^�̑J�ڌ���ʖ�Null�@���@�ϐ��̑J�ڌ���ʖ�Null
        pageStatus = null;
      }
      else
      {
        //�p�����[�^�̑J�ڌ���ʖ� ���@�ϐ��̑J�ڌ���ʖ�
        pageStatus = tmpPageStatus.toString();
      }    
      if(tmpFuncButton == null)
      {
        //�p�����[�^�̉����{�^����Null�@���@�ϐ��̉����{�^����Null
        funcButton = null;
      }
      else
      {
        //�p�����[�^�̉����{�^�����@���@�ϐ��̉����{�^����
        funcButton = tmpFuncButton.toString();
      }
     
      //����敪�擾
      String dealingsType = "Deposit";  // ����敪"Deposit"�Œ�

      //�V�K��ʑJ��
      if(((Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus))
        || (Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus)))
          && (Xx03ArCommonUtil.FUNC_NAME_PREPAY.equals(funcButton))
            && (dealingsType.equals("Deposit")))
      {           
        //�`�[�h�c�擾
        Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
         
        //�O������̌���
        Serializable[] methodParams = {receivableId};
        Class[] methodParamTypes = {receivableId.getClass()};
          
        am.invokeMethod("initAdvanceInfo", methodParams, methodParamTypes);
        if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
        {
          // �o���C���̎��͑S��ʍ��ڕύX�s��
          OAMessageLovInputBean slipLineTypeName = (OAMessageLovInputBean)webBean.findChildRecursive("SlipLineTypeName");
          slipLineTypeName.setDisabled(true);
          OAMessageLovInputBean summary = (OAMessageLovInputBean)webBean.findChildRecursive("Summary");
          summary.setDisabled(true);
          OAMessageTextInputBean money = (OAMessageTextInputBean)webBean.findChildRecursive("Money");
          money.setDisabled(true);
          OAMessageDateFieldBean effectiveDayFrom = (OAMessageDateFieldBean)webBean.findChildRecursive("EffectiveDayFrom");
          effectiveDayFrom.setDisabled(true);
          OAMessageDateFieldBean effectiveDayTo = (OAMessageDateFieldBean)webBean.findChildRecursive("EffectiveDayTo");
          effectiveDayTo.setDisabled(true);
        }
      }
      else
      {
        throw new Exception();
      }
    }
    catch(Exception ex)
    {
      //debug
      ex.printStackTrace();
      //�V�X�e���G���[
      throw new OAException("XX03", "APP-XX03-13008", ex);
    }

    //ver11.5.10.1.6 Add Start
    }
    //ver11.5.10.1.6 Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    try{
      //����
      //�p�����[�^�擾
      Object pageStatus = Xx03ArCommonUtil.getParameterValue(pageContext,"pageStatus");     //��ʃX�e�[�^�X
      Object receivableId = Xx03ArCommonUtil.getParameterValue(pageContext,"receivableId"); //�`�[ID
     
      //��ʑJ�ڃp�����[�^
      HashMap parameters = new HashMap(4);
       
      //�A�v���P�[�V�������W���[���̎擾
      OAApplicationModule am = pageContext.getApplicationModule(webBean);

      //�ۑ�
      if(pageContext.getParameter("Input") != null)
      {
        //�n�j�{�^���������̏���
         
        //��ʍ��ڂ̎擾
        OAMessageLovInputBean slipLineTypeName = (OAMessageLovInputBean)webBean.findChildRecursive("SlipLineTypeName");
        OAMessageLovInputBean summary = (OAMessageLovInputBean)webBean.findChildRecursive("Summary");
        OAMessageTextInputBean money = (OAMessageTextInputBean)webBean.findChildRecursive("Money");
        OAMessageDateFieldBean effectiveDayFrom = (OAMessageDateFieldBean)webBean.findChildRecursive("EffectiveDayFrom");

        //���̓`�F�b�N
        Vector vector = new Vector();
         
        if(slipLineTypeName.getValue(pageContext) == null)
        {
          //�������ׂ̃`�F�b�N
          OAException ex = new OAException
           ("XX03", "APP-XX03-13051", null, OAException.ERROR, null);
          vector.addElement(ex);
        }
         
        if(summary.getValue(pageContext) == null)
        {
          //�E�v�̃`�F�b�N
          OAException ex = new OAException
           ("XX03", "APP-XX03-13004", null, OAException.ERROR, null);
          vector.addElement(ex);
        }      
        if(money.getValue(pageContext) == null)
        {
          //���z�̃`�F�b�N
          OAException ex = new OAException
           ("XX03", "APP-XX03-13005", null, OAException.ERROR, null);
          vector.addElement(ex);
        }
        else
        {
          //���z�̃}�C�i�X�`�F�b�N
          Number checkMoney = new Number(money.getValue(pageContext));
          if(checkMoney.compareTo(0) != 1){
             OAException ex = new OAException
             ("XX03", "APP-XX03-13056", null, OAException.ERROR, null);
             vector.addElement(ex);
          }
        }
        if(effectiveDayFrom.getValue(pageContext) == null)
        {
          //�L�����i���j�̃`�F�b�N
          OAException ex = new OAException
           ("XX03", "APP-XX03-13006", null, OAException.ERROR, null);
          vector.addElement(ex);
        }
        else
        {
          //�L�����̑召�`�F�b�N
          OAException ex = (OAException)am.invokeMethod("dateInputCheck");
          if(ex != null)
          {
            vector.addElement(ex);
          }
        }     
        if (vector.size()>0)
        {
          //�G���[���b�Z�[�W�̕\��
          throw OAException.getBundledOAException(vector); 
        }

        // ���͒l���̊e��l�擾
        getValueFromInput(pageContext, webBean);
        
        //�O������m�菈��       
        am.invokeMethod("save");

        if(Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus)) 
        {
          //������̓w�b�_/���ד��͉�ʂ���J�ڂ��Ă����ꍇ
          
          //�p�����[�^���Z�b�g
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_PREPAY);
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_PREPAY);
          parameters.put("receivableId", receivableId); 

          //��ʑJ��
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_INPUT,      // url
            null,                                   // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
            null,                                   // menuName
            parameters,                             // parameter
            false,                                  // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
            OAException.INFORMATION                 // messagingLevel
          );
        }
        else if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
        {
          //�o���C����ʂ���J�ڂ��Ă����ꍇ
          
          //�p�����[�^���Z�b�g
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_PREPAY);
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_PREPAY);
          parameters.put("receivableId", receivableId); 

          //��ʑJ��
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_ACCTMODIFY,  // url
            null,                                    // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,    // menuContextAction
            null,                                    // menuName
            parameters,                              // parameter
            false,                                   // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,   // addBreadCrumb
            OAException.INFORMATION                  // messagingLevel
          );      
        }
      }
      //�O�̉�ʂɖ߂�
      else if(pageContext.getParameter("Back") != null)
      {
        //�߂�{�^���������̏���
        //�g�����U�N�V���������[���o�b�N���đO�̉�ʂɂ��ǂ�
        am.invokeMethod("back");

        if(Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus)) 
        {
          //������̓w�b�_/���ד��͉�ʂ���J�ڂ��Ă����ꍇ
          
          //�p�����[�^���Z�b�g
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_PREPAY);
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_INPUT);
          parameters.put("receivableId", receivableId); 

          //��ʑJ��
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_INPUT,      // url
            null,                                   // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
            null,                                   // menuName
            parameters,                             // parameter
            false,                                  // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
            OAException.INFORMATION                 // messagingLevel
          );
        }
        else if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
        {
          //�o���C����ʂ���J�ڂ��Ă����ꍇ
          
          //�p�����[�^���Z�b�g
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_PREPAY);
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_ACCT);
          parameters.put("receivableId", receivableId); 

          //��ʑJ��
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_ACCTMODIFY,  // url
            null,                                    // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,    // menuContextAction
            null,                                    // menuName
            parameters,                              // parameter
            false,                                   // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_NO,   // addBreadCrumb
            OAException.INFORMATION                  // messagingLevel
          );
        }
      }
    }
    catch(OAException ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            null,
                            OAException.ERROR,
                            null);
    }
  }   

  /**
   * ���͒l���̊e��l���擾����
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  private void getValueFromInput(OAPageContext pageContext, OAWebBean webBean)
  {
    // �A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);
    
    // ���͍��ڂ̎擾
    OAMessageLovInputBean summary = (OAMessageLovInputBean)webBean.findChildRecursive("Summary");
    OAMessageTextInputBean money = (OAMessageTextInputBean)webBean.findChildRecursive("Money");
    OAMessageDateFieldBean effectiveDayFrom = (OAMessageDateFieldBean)webBean.findChildRecursive("EffectiveDayFrom");

    // �{�̍��v���z �c ���z
    OAFormValueBean invItemAmount = (OAFormValueBean)webBean.findChildRecursive("InvItemAmount");
    invItemAmount.setValue(pageContext, money.getValue(pageContext));

    // ����ō��v�z �c 0
    OAFormValueBean invTaxAmount = (OAFormValueBean)webBean.findChildRecursive("InvTaxAmount");
    invTaxAmount.setValue(pageContext, new Number(0));

    // �P�� �c ���z
    OAFormValueBean slipLineUnitPrice = (OAFormValueBean)webBean.findChildRecursive("SlipLineUnitPrice");
    slipLineUnitPrice.setValue(pageContext, money.getValue(pageContext));

    // ���� �c 1
    OAFormValueBean slipLineQuantity = (OAFormValueBean)webBean.findChildRecursive("SlipLineQuantity");
    slipLineQuantity.setValue(pageContext, new Number(1));

    // ���ד��͋��z �c ���z
    OAFormValueBean slipLineEnteredAmount = (OAFormValueBean)webBean.findChildRecursive("SlipLineEnteredAmount");
    slipLineEnteredAmount.setValue(pageContext, money.getValue(pageContext));

    // �ŋ敪 �c "0000"
    OAFormValueBean taxCode = (OAFormValueBean)webBean.findChildRecursive("TaxCode");
    String strTaxCode = "0000";
    taxCode.setValue(pageContext, strTaxCode);

    // �ŋ敪���́A�ŋ敪ID �c �ŋ敪���擾
    Serializable[] methodParams = {strTaxCode};
    Class[] methodParamTypes = {strTaxCode.getClass()};
    OAFormValueBean taxName = (OAFormValueBean)webBean.findChildRecursive("TaxName");

    //Ver11.5.10.1.6B Chg Start
    //OAFormValueBean taxId = (OAFormValueBean)webBean.findChildRecursive("TaxId");
    //ArrayList taxInfo = (ArrayList)am.invokeMethod("getTaxRate", methodParams, methodParamTypes);
    //if (!taxInfo.isEmpty())
    //{
    //  taxName.setValue(pageContext, (String)taxInfo.get(0));
    //  taxId.setValue(pageContext, (Number)taxInfo.get(1));
    //}
    String taxInfo = (String)am.invokeMethod("getTaxRate", methodParams, methodParamTypes);
    if (taxInfo != null)
    {
      taxName.setValue(pageContext, taxInfo);
    }
    //Ver11.5.10.1.6B Chg End

    // �{�̋��z �c ���z
    OAFormValueBean enteredItemAmount = (OAFormValueBean)webBean.findChildRecursive("EnteredItemAmount");
    enteredItemAmount.setValue(pageContext, money.getValue(pageContext));

    // ����Ŋz �c 0
    OAFormValueBean enteredTaxAmount = (OAFormValueBean)webBean.findChildRecursive("EnteredTaxAmount");
    enteredTaxAmount.setValue(pageContext, new Number(0));

    // AFF���ڎ擾
    am.invokeMethod("getAutoAccounting");
  }
  
  public Xx03InvoiceAdvanceCO()
  {
  }
}