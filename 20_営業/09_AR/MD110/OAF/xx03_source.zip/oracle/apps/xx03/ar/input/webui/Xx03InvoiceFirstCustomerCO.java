/*============================================================================
 *  Copyright (c) Oracle Corporation Japan, 2004 - 2005. All rights reserved.
 *  FILENAME    Xx03InvoiceFirstCustomerCO.java
 *  VERSION     11.5.10.1.6 
 *  DATE        2006/02/02
 *  HISTORY     2005/01/26  Ver1.0          �V�K�쐬
 *              2006/02/02  Ver11.5.10.1.6  �{�^���̃_�u���N���b�N�Ή�
 *===========================================================================*/
package oracle.apps.xx03.ar.input.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;

import oracle.jbo.domain.Number;

//ver11.5.10.1.6 Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6 Add End

/**
  * Xx03InvoiceFirstCustomerCO �ꌩ�ڋq��ʂ�Controller
  * @version ver 1.0
  */
public class Xx03InvoiceFirstCustomerCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //�A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    //ver11.5.10.1.6 Add Start
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6 Add End

    try
    {
      //���ʏ���
      //�p�����[�^�擾
      String pageStatus = null; //�J�ڌ���ʖ�
      String funcButton = null; //�����{�^����

      Object tmpPageStatus = Xx03ArCommonUtil.getParameterValue(pageContext,"pageStatus");
      Object tmpFuncButton = Xx03ArCommonUtil.getParameterValue(pageContext,"funcButton");
      
      if(tmpPageStatus == null)
      {
        //�p�����[�^�̑J�ڌ���ʖ�Null�@���@�ϐ��̑J�ڌ���ʖ�Null
        pageStatus = null;
      }
      else
      {
        //�p�����[�^�̑J�ڌ���ʖ� ���@�ϐ��̑J�ڌ���ʖ�
        pageStatus = tmpPageStatus.toString();
      }    
      if(tmpFuncButton == null)
      {
        //�p�����[�^�̉����{�^����Null�@���@�ϐ��̉����{�^����Null
        funcButton = null;
      }
      else
      {
        //�p�����[�^�̉����{�^�����@���@�ϐ��̉����{�^����
        funcButton = tmpFuncButton.toString();
      }
      //�ꌩ�ڋq�敪�擾
      String custType = Xx03ArCommonUtil.getParameterValue(pageContext, "custType").toString();
    
      //�V�K��ʑJ��
      if(((Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus))
        || (Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus)))
          && (Xx03ArCommonUtil.FUNC_NAME_FIRST_CUSTOMER.equals(funcButton))
            && (custType.equals(Xx03ArCommonUtil.STR_YES)))
      {    
        //�`�[�h�c�擾
        Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
          
        //�ڋq���̌���
        Serializable[] methodParams = {receivableId};
        Class[] methodParamTypes = {receivableId.getClass()};
         
        am.invokeMethod("initCustInfo", methodParams, methodParamTypes);

        if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
        {
          // �o���C���̎��͑S��ʍ��ڕύX�s��
          OAMessageTextInputBean customerName = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
          customerName.setDisabled(true);
          OAMessageTextInputBean kanaName = (OAMessageTextInputBean)webBean.findChildRecursive("KanaName");
          kanaName.setDisabled(true);
          OAMessageTextInputBean zipCode = (OAMessageTextInputBean)webBean.findChildRecursive("zipCode");
          zipCode.setDisabled(true);
          OAMessageTextInputBean address1 = (OAMessageTextInputBean)webBean.findChildRecursive("Address1");
          address1.setDisabled(true);
          OAMessageTextInputBean address2 = (OAMessageTextInputBean)webBean.findChildRecursive("Address2");
          address2.setDisabled(true);
        }        
      }
      else
      {
        throw new Exception();
      }
    }
    catch(Exception ex)
    {
      //debug
      ex.printStackTrace();
      //�V�X�e���G���[
      throw new OAException("XX03", "APP-XX03-13008", ex);
    }    

    //ver11.5.10.1.6 Add Start
    }
    //ver11.5.10.1.6 Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    //����
    //�p�����[�^�擾
    Object pageStatus = Xx03ArCommonUtil.getParameterValue(pageContext,"pageStatus");     //��ʃX�e�[�^�X
    Object receivableId = Xx03ArCommonUtil.getParameterValue(pageContext,"receivableId"); //�`�[ID
    
    //��ʑJ�ڃp�����[�^
    HashMap parameters = new HashMap(4);   
    
    //�A�v���P�[�V�������W���[���̎擾
    OAApplicationModule am = pageContext.getApplicationModule(webBean);

    //�ۑ�
    if(pageContext.getParameter("Input") != null)
    {
      //�n�j�{�^���������̏���
      
      //��ʍ��ڂ̎擾
      OAMessageTextInputBean customerName = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
      OAMessageTextInputBean kanaName = (OAMessageTextInputBean)webBean.findChildRecursive("KanaName");
      OAMessageTextInputBean address1 = (OAMessageTextInputBean)webBean.findChildRecursive("Address1");

      //�K�{���ڂɓ��͂����邩����
      //�K�{���ڂɓ��͂��Ȃ��ꍇ�G���[���b�Z�[�W��\��
      Vector vector = new Vector();
        
      if(strTrim(customerName.getValue(pageContext)) == null)
      {
        //�ڋq���̂̃`�F�b�N
        OAException ex = new OAException
         ("XX03", "APP-XX03-13001", null, OAException.ERROR, null);
        vector.addElement(ex);
      }
      if(strTrim(kanaName.getValue(pageContext)) == null)
      {
        //�J�i���̃`�F�b�N
        OAException ex = new OAException
         ("XX03", "APP-XX03-13002", null, OAException.ERROR, null);
        vector.addElement(ex);
      }
      if(address1.getValue(pageContext) == null)
      {
        //�Z���P�̃`�F�b�N
        OAException ex = new OAException
         ("XX03", "APP-XX03-13003", null, OAException.ERROR, null);
        vector.addElement(ex);
      }
      if(!vector.isEmpty())
      {
        throw OAException.getBundledOAException(vector);
      }

      //�ꌩ�ڋq���̊m��
      customerName.setValue(pageContext, strTrim(customerName.getValue(pageContext)));
      kanaName.setValue(pageContext, strTrim(kanaName.getValue(pageContext)));     
      am.invokeMethod("save");

      if(Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus))
      {
        //������̓w�b�_/���ד��͉�ʂ���J�ڂ��Ă����ꍇ
        
        //�p�����[�^���Z�b�g
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER);
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_FIRST_CUSTOMER);
        parameters.put("receivableId", receivableId); 

        //��ʑJ��
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_INPUT,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
      else if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
      {
        //�o���C����ʂ���J�ڂ��Ă����ꍇ
        
        //�p�����[�^���Z�b�g
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER);
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_FIRST_CUSTOMER);
        parameters.put("receivableId", receivableId); 

        //��ʑJ��
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_ACCTMODIFY,  // url
          null,                                    // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,    // menuContextAction
          null,                                    // menuName
          parameters,                              // parameter
          false,                                   // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,   // addBreadCrumb
          OAException.INFORMATION                  // messagingLevel
        );
      }
    }
    
    //�O�̉�ʂɖ߂�
    else if(pageContext.getParameter("Back") != null)
    {
      //�߂�{�^���������̏���
      am.invokeMethod("back");
     
      if(Xx03ArCommonUtil.WINDOW_NAME_INPUT.equals(pageStatus)) 
      {
        //������̓w�b�_/���ד��͉�ʂ���J�ڂ��Ă����ꍇ
        
        //�p�����[�^���Z�b�g
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER);
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_INPUT);
        parameters.put("receivableId", receivableId); 

        //��ʑJ��
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_INPUT,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAException.INFORMATION                 // messagingLevel
        );
      }
      else if(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY.equals(pageStatus))
      {
        //�o���C����ʂ���J�ڂ��Ă����ꍇ
        
        //�p�����[�^���Z�b�g
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_FIRST_CUSTOMER);
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_ACCT);
        parameters.put("receivableId", receivableId); 

        //��ʑJ��
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_ACCTMODIFY,  // url
          null,                                    // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,    // menuContextAction
          null,                                    // menuName
          parameters,                              // parameter
          false,                                   // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,   // addBreadCrumb
          OAException.INFORMATION                  // messagingLevel
        );
      }      
    }
  }

  /**
   * Trim�֐��i�S�p�󔒑Ή��j
   * @param Object textInput �󔒏����O�̕�����
   * @return String strReturn �󔒏�����̕�����@�i������ or �󔒂̂ݓ��͎� Null�j
   */
  public String strTrim(Object textInput)
  {
    int loopNum = 0;

    if(textInput == null)
    {
      return null;
    }
    String str = (String)textInput;
    StringBuffer strTemp = new StringBuffer(str);

    //������̍����̋󔒏���
    while(loopNum < str.length())
    {
      if(str.substring(loopNum,loopNum+1).equals(" ") || str.substring(loopNum,loopNum+1).equals("�@"))
      {
        strTemp.deleteCharAt(0);
      }
      else
      {
        break;
      }
      loopNum++;
    }
    if(strTemp.length() == 0)
    {
      return null;
    }
    
    StringBuffer strReturn = new StringBuffer(strTemp.toString());
    loopNum = strTemp.length();
    
    //������̉E���̋󔒏���
    while(loopNum > 0)
    {
      if(strTemp.substring(loopNum-1,loopNum).equals(" ") || strTemp.substring(loopNum-1,loopNum).equals("�@"))
       {
         strReturn.deleteCharAt(strReturn.length()-1);
       }
       else
       {
         break;
       }
       loopNum--;
    }
    return strReturn.toString(); 
  }

  public Xx03InvoiceFirstCustomerCO()
  {
  }
}