/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005. All rights reserved.
 * FILENAME   Xx03AccountApproveCO.java
 * VERSION    11.5.10.2.8
 * DATE       2007/06/04
 * HISTORY    2004/12/16 ver 1.0          �V�K�쐬
 *            2005/11/22 ver 11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�(�ꊇ���F)
 *            2006/01/30 ver 11.5.10.1.6B ������ʂ̉�ʑJ�ڕύX�Ή�
 *            2006/02/02 ver 11.5.10.1.6C �{�^���̃_�u���N���b�N�Ή�
 *            2006/06/04 ver 11.5.10.2.8  �ꊇ���F���̏��F��ID�̌��Ή�
 *===========================================================================*/
package oracle.apps.xx03.gl.approve.webui;

import com.sun.java.util.collections.Vector;
import java.io.Serializable;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OARawTextBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASeparatorBean;
import oracle.apps.fnd.framework.webui.beans.layout.OASpacerBean;
import oracle.apps.fnd.framework.webui.beans.layout.OADefaultHideShowBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAMessageComponentLayoutBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAFlowLayoutBean;
import oracle.apps.fnd.framework.webui.beans.table.OATableBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.jbo.domain.Date;
import oracle.apps.xx03.util.Xx03CommonUtil;

//ver11.5.10.1.6C Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6C Add End

//ver 11.5.10.2.8 Add Start
import oracle.jbo.domain.Number;
//ver 11.5.10.2.8 Add End

/**
 * Xx03AccountApprove��CO
 */
public class Xx03AccountApproveCO extends OAControllerImpl
{
  public static final String  RCS_ID          = "$Header$: Xx03AccountApproveCO.java 2004/12/16";
  public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion(RCS_ID, "oracle.apps.xx03.gl.approve.webui");

  public OARawTextBean message;
  public OAMessageComponentLayoutBean conditionRN;
  public OAFlowLayoutBean searchBtnRN;
  public OASeparatorBean separator1;
  public OASpacerBean spacer1;
  public OATableBean resultRN;
  public OATableBean confirmRN;
  public OAFlowLayoutBean approveBtnRN;

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //ver11.5.10.1.6C Add Start
    OAApplicationModule am = pageContext.getRootApplicationModule();
    
    // back button support
    if (pageContext.isBackNavigationFired(false))
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6C Add End

    // ���b�Z�[�W
    message = (OARawTextBean)webBean.findChildRecursive("message");
    // ��������
    conditionRN = (OAMessageComponentLayoutBean)webBean.findChildRecursive("ConditionRN");
    // �����{�^��
    searchBtnRN = (OAFlowLayoutBean)webBean.findChildRecursive("SearchBtnRN");
    // �Z�p���[�^
    separator1 = (OASeparatorBean)webBean.findChildRecursive("separator1");
    // �X�y�[�X
    spacer1 = (OASpacerBean)webBean.findChildRecursive("spacer1");
    // ����
    resultRN = (OATableBean)webBean.findChildRecursive("ResultRN");
    // �m�F
    confirmRN = (OATableBean)webBean.findChildRecursive("ConfirmRN");
    // ���F�{�^��
    approveBtnRN = (OAFlowLayoutBean)webBean.findChildRecursive("ApproveBtnRN");

    // itemBean�̍쐬
    OASubmitButtonBean allApprove = (OASubmitButtonBean)approveBtnRN.findChildRecursive("ApproveBtn");
    OASubmitButtonBean approveYes = (OASubmitButtonBean)approveBtnRN.findChildRecursive("ApproveYesBtn");
    OASubmitButtonBean approveNo  = (OASubmitButtonBean)approveBtnRN.findChildRecursive("ApproveNoBtn");

    //ver11.5.10.1.6C Del Start
    //OAApplicationModule am = pageContext.getRootApplicationModule();
    //ver11.5.10.1.6C Del End

    // ��ʑS���ڂ��\����
    unDispAll();

    // �p�����[�^�擾
    String transaction = null;
    transaction = pageContext.getParameter("transaction");
    if (transaction == null)
    {
      transaction = "";
    }

    // �����{�^���A���F�m�F��ʂŁu�߂�v�{�^��������
    if (transaction.equals("result"))
    {
      result();
      allApprove.setRendered(true);
      approveYes.setRendered(false);
      approveNo.setRendered(false);
      am.invokeMethod("getResult");
    }
    // �ꊇ���F�m�F
    else if (transaction.equals("confirm"))
    {
      String rowCount = pageContext.getParameter("rowCount");
      confirm();
      allApprove.setRendered(false);
      approveYes.setRendered(true);
      approveNo.setRendered(true);
      MessageToken msg = new MessageToken("TOK_XX03_APPLY_COUNT", rowCount.toString());
      OAException ex   = new OAException("XX03", "APP-XX03-34058",
                                         new MessageToken[]{msg});
      ex.setApplicationModule(am);
      message.setText(ex.getMessage());
    }
    // �ꊇ���FOK
    else if (transaction.equals("approveOK"))
    {
      result();
      allApprove.setRendered(true);
      approveYes.setRendered(false);
      approveNo.setRendered(false);

      //ver 11.5.10.2.8 Add Start
      Number employeeId = new Number(pageContext.getEmployeeId());
      Serializable[] methodParams = new Serializable[]{employeeId};
      Class[] methodParamTypes = new Class[]{employeeId.getClass()};
      //ver 11.5.10.2.8 Add End

      // Workflow �N��AM���\�b�h
      //ver 11.5.10.2.8 Chg Start
      //Serializable[] returnValue = new Serializable[]{am.invokeMethod("approveTransaction")};
      Serializable[] returnValue = new Serializable[]{am.invokeMethod("approveTransaction", methodParams, methodParamTypes)};
      //ver 11.5.10.2.8 Chg End
      String         errMsg      = (String)returnValue[0];

      // �Č���
      am.invokeMethod("getResult");

      if (errMsg != null)
      {
        MessageToken msg = new MessageToken("TOK_XX03_APPROVE_ERR", errMsg);
        throw new OAException("XX03", "APP-XX03-14141",
                              new MessageToken[]{msg},
                              OAException.ERROR, null);
      }
      else
      {
        throw new OAException("XX03", "APP-XX03-34056",
                              null,
                              OAException.INFORMATION, null);
      }
    }
    // �@�\�ݒ�Ȃ�
    else if (transaction.equals(""))
    {
      search();
      am.invokeMethod("createSearchRow");

      // �m�F��ʁu�߂�v�{�^��������
      if (pageContext.getParameter("pageStatus") != null &&
          pageContext.getParameter("pageStatus").equals(Xx03CommonUtil.WINDOW_NAME_CONFIRM))
      {
        result();
        allApprove.setRendered(true);
        approveYes.setRendered(false);
        approveNo.setRendered(false);
        // �p�����[�^���擾���A�����ɃZ�b�g
        setSearchItem(pageContext, webBean);
        am.invokeMethod("getResult");
        //Ver11.5.10.1.6B Add Start
        String messageSpecified=pageContext.getParameter("messages");
        if(null!=messageSpecified && !"".equals(messageSpecified))
        {
          pageContext.putDialogMessage(Xx03CommonUtil.stringToBundledOAException(messageSpecified));
          pageContext.removeParameter("messages");
        }
        //Ver11.5.10.1.6B Add End
      }
    }
    // �\�����Ȃ��l���Z�b�g���ꂽ�ꍇ
    else
    {
      unDispAll();
      throw new OAException("XX03", "APP-XX03-14999", null, OAException.ERROR, null);
    }

    //ver11.5.10.1.6C Add Start
    }
    //ver11.5.10.1.6C Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    OAApplicationModule am = pageContext.getRootApplicationModule();

    // �����{�^��������
    if (pageContext.getParameter("SearchBtn") != null)
    {
      Vector vector = new Vector();

      // ���t�`�F�b�N
      Serializable[] returnValue =new Serializable[]{am.invokeMethod("dateInputCheck")};
      vector = (Vector)returnValue[0];
      if (vector != null)
      {
        throw OAException.getBundledOAException(vector);
      }
      else
      {
        pageContext.putParameter("transaction", "result");
        pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG,
                                  null,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  true,
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
    }
    // �m�F�{�^��������
    else if (pageContext.getParameter("Confirm") != null)
    {
      // ���������̃A�C�e��Bean�쐬
      OAMessageLovInputBean oaEntryDepartment = (OAMessageLovInputBean)webBean.findChildRecursive("EntryDepartment");
      OAMessageLovInputBean oaEntryPersonName = (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
      OAMessageLovInputBean oaSourceName = (OAMessageLovInputBean)webBean.findChildRecursive("SourceName");
      OAMessageLovInputBean oaSlipType = (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
      OAMessageTextInputBean oaJournalNum = (OAMessageTextInputBean)webBean.findChildRecursive("JournalNum");
      OAMessageDateFieldBean oaEntryDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateStart");
      OAMessageDateFieldBean oaEntryDateEnd = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateEnd");
      OAMessageDateFieldBean oaGlDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
      OAMessageDateFieldBean oaGlDateEnd = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
      OAMessageTextInputBean oaDescription = (OAMessageTextInputBean)webBean.findChildRecursive("Description");

      // �p�����[�^�̃Z�b�g
      if (oaEntryDepartment.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramEntryDepartment", oaEntryDepartment.getValue(pageContext));
      }
      if (oaEntryPersonName.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramEntryPersonName", oaEntryPersonName.getValue(pageContext));
      }
      if (oaSourceName.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramSourceName", oaSourceName.getValue(pageContext));
      }
      if (oaSlipType.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramSlipType", oaSlipType.getValue(pageContext));
      }
      if (oaJournalNum.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramJournalNum", oaJournalNum.getValue(pageContext));
      }
      if (oaEntryDateStart.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramEntryDateStart", oaEntryDateStart.getValue(pageContext));
      }
      if (oaEntryDateEnd.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramEntryDateEnd", oaEntryDateEnd.getValue(pageContext));
      }
      if (oaGlDateStart.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramGlDateStart", oaGlDateStart.getValue(pageContext));
      }
      if (oaGlDateEnd.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramGlDateEnd", oaGlDateEnd.getValue(pageContext));
      }
      if (oaDescription.getValue(pageContext) != null)
      {
        pageContext.putParameter("paramDescription", oaDescription.getValue(pageContext));
      }
      if(pageContext.getParameter("EntryDepartmentId") != null &&
         pageContext.getParameter("EntryDepartmentId") != "")
      {
        pageContext.putParameter("paramEntryDepartmentId", pageContext.getParameter("EntryDepartmentId"));
      }
      if(pageContext.getParameter("EntryPersonId") != null &&
         pageContext.getParameter("EntryPersonId") != "")
      {
        pageContext.putParameter("paramEntryPersonId", pageContext.getParameter("EntryPersonId"));
      }
      if(pageContext.getParameter("SourceCode") != null &&
         pageContext.getParameter("SourceCode") != "")
      {
        pageContext.putParameter("paramSourceCode", pageContext.getParameter("SourceCode"));
      }
      if(pageContext.getParameter("SlipTypeCodeId") != null &&
         pageContext.getParameter("SlipTypeCodeId") != "")
      {
        pageContext.putParameter("paramSlipTypeCodeId", pageContext.getParameter("SlipTypeCodeId"));
      }

      String journalId  = pageContext.getParameter("journalId");
      String sourceCode = pageContext.getParameter("sourceCode");

      pageContext.putParameter("pageStatus", Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG);
      pageContext.putParameter("funcButton", Xx03CommonUtil.FUNC_NAME_CONFIRM);

      if (sourceCode.equals("SQLGL"))
      {
        pageContext.putParameter("journalId", journalId);
        pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_CONFIRM,
                                  null,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  false,
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
      else if (sourceCode.equals("SQLAP"))
      {
        pageContext.putParameter("invoiceId", journalId);
        pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_AP_CONFIRM,
                                  null,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  false,
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
      else
      {
        pageContext.putParameter("invoiceId", journalId);
        pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_AR_CONFIRM,
                                  null,
                                  KEEP_MENU_CONTEXT,
                                  null,
                                  null,
                                  false,
                                  ADD_BREAD_CRUMB_NO,
                                  OAException.ERROR);
      }
    }
    // �ꊇ���F�{�^����������
    else if (pageContext.getParameter("ApproveBtn") != null)
    {
      String journalId  = pageContext.getParameter("journalId");
      String sourceCode = pageContext.getParameter("sourceCode");

      // �`�F�b�N�̂���f�[�^�̍����ԍ����擾��
      Vector markedVec = (Vector)am.invokeMethod("getMarkedId");
      String checkElm = (String)markedVec.firstElement();
      Vector excepVec = new Vector();
      if(!checkElm.equals("0"))
      {
        Vector errCheckVec;
        for(int i=0; i<markedVec.size() ;i++)
        {

        //ver11.5.10.1.6 Add Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkValidation", new Serializable[]{(String)markedVec.elementAt(i)});
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver11.5.10.1.6 Add End

          // �G���[�`�F�b�N�֐�
          errCheckVec = (Vector)am.invokeMethod("checkDeptInput", new Serializable[]{(String)markedVec.elementAt(i)});

          // �G���[������
          if (!(errCheckVec.lastElement().toString().equals("normal")) &&
              !(errCheckVec.lastElement().toString().equals("warn")))
          {
            for(int j=0; j<errCheckVec.size() ;j++)
            {
              // ���������G���[�̂ݏW�߂�
              excepVec.addElement((OAException)errCheckVec.elementAt(j));
            }
          }
        }
        // �G���[���������Ă����throw
        if(excepVec.size() >= 1)
        {
          throw OAException.getBundledOAException(excepVec);
        }
      }

      // �`�F�b�N�̂���f�[�^�̂ݍi���݂��s��
      Serializable[] returnObj = new Serializable[]{am.invokeMethod("searchApprove")};
      Integer rowCount = (Integer)returnObj[0];

      // �o�����F���I������Ă��Ȃ��ꍇ�̓G���[
      if (rowCount.equals(new Integer("0")))
      {
        throw new OAException("XX03","APP-XX03-14136", null, OAException.ERROR, null);
      }

      pageContext.putParameter("transaction", "confirm");
      pageContext.putParameter("journalId", journalId);
      pageContext.putParameter("sourceCode", sourceCode);
      pageContext.putParameter("rowCount", rowCount.toString());
      pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // ���F�FOK�{�^����������
    else if (pageContext.getParameter("ApproveYesBtn") != null)
    {
      pageContext.putParameter("transaction", "approveOK");
      pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // ���F�FNG�{�^����������
    else if (pageContext.getParameter("ApproveNoBtn") != null)
    {
      pageContext.putParameter("transaction", "result");
      pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
    // �N���A�{�^����������
    else if (pageContext.getParameter("ClearBtn") != null)
    {
      pageContext.putParameter("transaction", "");
      pageContext.setForwardURL(Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG,
                                null,
                                KEEP_MENU_CONTEXT,
                                null,
                                null,
                                true,
                                ADD_BREAD_CRUMB_NO,
                                OAException.ERROR);
    }
  }

  /**
   * �S���\��
   */
  private void dispAll()
  {
    message.setRendered(true);
    conditionRN.setRendered(true);
    searchBtnRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    resultRN.setRendered(true);
    confirmRN.setRendered(true);
    approveBtnRN.setRendered(true);
  }

  /**
   * �S����\��
   */
  private void unDispAll()
  {
    message.setRendered(false);
    conditionRN.setRendered(false);
    searchBtnRN.setRendered(false);
    separator1.setRendered(false);
    spacer1.setRendered(false);
    resultRN.setRendered(false);
    confirmRN.setRendered(false);
    approveBtnRN.setRendered(false);
  }

  /**
   * �ŏ��̕\��
   */
  private void search()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    searchBtnRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    resultRN.setRendered(true);
    confirmRN.setRendered(false);
    approveBtnRN.setRendered(false);
  }

  /**
   * ���ʕ\��
   */
  private void result()
  {
    message.setRendered(false);
    conditionRN.setRendered(true);
    searchBtnRN.setRendered(true);
    separator1.setRendered(true);
    spacer1.setRendered(true);
    resultRN.setRendered(true);
    confirmRN.setRendered(false);
    approveBtnRN.setRendered(true);
  }

  /**
   * ���F�m�F���
   */
  private void confirm()
  {
    message.setRendered(true);
    conditionRN.setRendered(false);
    searchBtnRN.setRendered(false);
    separator1.setRendered(false);
    spacer1.setRendered(false);
    resultRN.setRendered(false);
    confirmRN.setRendered(true);
    approveBtnRN.setRendered(true);
  }

  /**
   * ���������Z�b�g����
   *
   * @param  pageContext OAPageContext
   * @param  webBean     OAWebBean
   */
  private void setSearchItem(OAPageContext pageContext, OAWebBean webBean)
  {
    // Application Module �C���X�^���X
    OAApplicationModule am = pageContext.getRootApplicationModule();

    // ���������A�C�e��Bean�쐬
    OAMessageLovInputBean oaEntryDepartment = (OAMessageLovInputBean)webBean.findChildRecursive("EntryDepartment");
    OAMessageLovInputBean oaEntryPersonName = (OAMessageLovInputBean)webBean.findChildRecursive("EntryPersonName");
    OAMessageLovInputBean oaSourceName = (OAMessageLovInputBean)webBean.findChildRecursive("SourceName");
    OAMessageLovInputBean oaSlipType = (OAMessageLovInputBean)webBean.findChildRecursive("SlipTypeKind");
    OAMessageTextInputBean oaJournalNum = (OAMessageTextInputBean)webBean.findChildRecursive("JournalNum");
    OAMessageDateFieldBean oaEntryDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateStart");
    OAMessageDateFieldBean oaEntryDateEnd = (OAMessageDateFieldBean)webBean.findChildRecursive("EntryDateEnd");
    OAMessageDateFieldBean oaGlDateStart = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateStart");
    OAMessageDateFieldBean oaGlDateEnd = (OAMessageDateFieldBean)webBean.findChildRecursive("GlDateEnd");
    OAMessageTextInputBean oaDescription = (OAMessageTextInputBean)webBean.findChildRecursive("Description");

    OADefaultHideShowBean searchShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DefaultSearchRN");
    OADefaultHideShowBean detailShowItem = (OADefaultHideShowBean)webBean.findChildRecursive("DetailSearchRN");

    OAFormValueBean oaEntryDepartmentId = (OAFormValueBean)webBean.findChildRecursive("EntryDepartmentId");
    OAFormValueBean oaEntryPersonId = (OAFormValueBean)webBean.findChildRecursive("EntryPersonId");
    OAFormValueBean oaSourceCode = (OAFormValueBean)webBean.findChildRecursive("SourceCode");
    OAFormValueBean oaSlipTypeCodeId = (OAFormValueBean)webBean.findChildRecursive("SlipTypeCodeId");

    // �A�C�e����Row�ɒl��ݒ�
    if (pageContext.getParameter("paramEntryDepartment") != null)
    {
      oaEntryDepartment.setValue(pageContext, pageContext.getParameter("paramEntryDepartment").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDepartment",pageContext.getParameter("paramEntryDepartment")});
    }
    if (pageContext.getParameter("paramEntryPersonName") != null)
    {
      oaEntryPersonName.setValue(pageContext, pageContext.getParameter("paramEntryPersonName").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryPersonName",pageContext.getParameter("paramEntryPersonName")});
    }
    if (pageContext.getParameter("paramSourceName") != null)
    {
      oaSourceName.setDefaultValue(pageContext.getParameter("paramSourceName").toString());
      am.invokeMethod("insertValue",new Serializable[]{"sourceName",pageContext.getParameter("paramSourceName")});
    }
    if (pageContext.getParameter("paramSlipType") != null)
    {
      oaSlipType.setValue(pageContext, pageContext.getParameter("paramSlipType").toString());
      am.invokeMethod("insertValue",new Serializable[]{"slipTypeKind",pageContext.getParameter("paramSlipType")});
    }
    if (pageContext.getParameter("paramJournalNum") != null)
    {
      oaJournalNum.setValue(pageContext, pageContext.getParameter("paramJournalNum").toString());
      am.invokeMethod("insertValue",new Serializable[]{"journalNum",pageContext.getParameter("paramJournalNum")});
    }
    if (pageContext.getParameter("paramEntryDateStart") != null)
    {
      oaEntryDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramEntryDateStart")).toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDateStart",pageContext.getParameter("paramEntryDateStart")});
    }
    if (pageContext.getParameter("paramEntryDateEnd") != null)
    {
      oaEntryDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramEntryDateEnd")).toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDateEnd",pageContext.getParameter("paramEntryDateEnd")});
    }
    if (pageContext.getParameter("paramGlDateStart") != null)
    {
      oaGlDateStart.setValue(pageContext, new Date(pageContext.getParameter("paramGlDateStart")).toString());
      am.invokeMethod("insertValue",new Serializable[]{"glDateStart",pageContext.getParameter("paramGlDateStart")});
    }
    if (pageContext.getParameter("paramGlDateEnd") != null)
    {
      oaGlDateEnd.setValue(pageContext, new Date(pageContext.getParameter("paramGlDateEnd")).toString());
      am.invokeMethod("insertValue",new Serializable[]{"glDateEnd",pageContext.getParameter("paramGlDateEnd")});
    }
    if (pageContext.getParameter("paramDescription") != null)
    {
      oaDescription.setValue(pageContext, pageContext.getParameter("paramDescription").toString());
      am.invokeMethod("insertValue",new Serializable[]{"description",pageContext.getParameter("paramDescription")});
    }
    if (pageContext.getParameter("paramEntryDepartmentId") != null)
    {
      oaEntryDepartmentId.setValue(pageContext, pageContext.getParameter("paramEntryDepartmentId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"entryDepartmentId",pageContext.getParameter("paramEntryDepartmentId")});
    }
    if (pageContext.getParameter("paramSlipTypeCodeId") != null)
    {
      oaSlipTypeCodeId.setValue(pageContext, pageContext.getParameter("paramSlipTypeCodeId").toString());
      am.invokeMethod("insertValue",new Serializable[]{"slipTypeCodeID",pageContext.getParameter("paramSlipTypeCodeId")});
    }
    if (pageContext.getParameter("paramSourceCode") != null)
    {
      oaSourceCode.setValue(pageContext, pageContext.getParameter("paramSourceCode"));
      am.invokeMethod("insertValue",new Serializable[]{"source",pageContext.getParameter("paramSourceCode")});
    }
    if (pageContext.getParameter("paramEntryPersonId") != null)
    {
       oaEntryPersonId.setValue(pageContext, new Integer(pageContext.getParameter("paramEntryPersonId")));
       am.invokeMethod("insertValue",new Serializable[]{"entryPersonId",pageContext.getParameter("paramEntryPersonId")});
    }
  }
}
