/*===========================================================================
 * Copyright (c) Oracle Corporation Japan, 2004-2005  All rights reserved
 * FILENAME   XX03InvoiceConfirmCO.java
 * VERSION    11.5.10.2.10
 * DATE       2008/02/08
 * HISTORY    2004/12/17                  �V�K�쐬
 *            2005/02/24 ver 1.1          �d�l�ύX�Ή��g��
 *            2005/04/11 ver 11.5.10.1.0  ���������ێ��̕s��Ή��g��
 *            2005/04/13 ver 11.5.10.1.0  �o���C����ʂ���̉�ʑJ�ڎ��̕s��Ή��g��
 *            2005/04/20 ver 11.5.10.1.1  ���i�K���F���ɑO�̐l�̃R�����g��
 *                                        �N���A�����悤�C��
 *            2005/07/07 ver 11.5.10.1.4  ����Ŋ֌W�̌x�����ɂ��\���ł���悤�ɏC��
 *            2005/11/10 ver 11.5.10.1.6  �}�X�^�����̉ߋ��f�[�^�\���Ή�
 *            2005/11/18 ver 11.5.10.1.6B ������͂̐\�����s���ۂ̓����ύX
 *                                        (GL�̓���ɍ��킹��)
 *            2005/12/19 ver 11.5.10.1.6C ���F�Ҕ���̏C���Ή�
 *            2006/01/11 ver 11.5.10.1.6D ��Q578 ���F�Ҕ���̏C��
 *            2006/01/13 ver 11.5.10.1.6E ���ׂ̋��z���J���}��؂�ŕ\������悤�ɏC��
 *            2006/01/30 ver 11.5.10.1.6F ������ʂ̉�ʑJ�ڕύX�Ή�
 *            2006/02/02 ver 11.5.10.1.6G �{�^���̃_�u���N���b�N�Ή�
 *            2006/02/15 ver 11.5.10.1.6H �{�^���_�u���N���b�N�̍đΉ�
 *            2006/05/30 ver 11.5.10.2.3  ����ړ����A�{�l�쐬�`�[�͌����ł���悤�ɏC��
 *            2006/10/23 ver 11.5.10.2.6  ��ʕ\�����ɏd�_�Ǘ�����̃��\�b�h�����s���ĕۑ���
 *                                        �ă`�F�b�N�A�ȊO�̓e�[�u���̒l���g���悤�ɏC��
 *            2008/02/08 ver 11.5.10.2.10 PL/SQL�p�b�P�[�W�ɂčX�V�����邽�߁A�\�����
 *                                        ����ʑJ�ڂ���ۂ�ratainAM��false�ɂ���C��
 *
 *===========================================================================*/
package oracle.apps.xx03.ar.confirm.webui;

import com.sun.java.util.collections.HashMap;
import com.sun.java.util.collections.Vector;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Hashtable;

import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADataBoundValueViewObject;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanStyledText;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.layout.OAHeaderBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.OAWebBeanTextInput;
import oracle.apps.fnd.framework.webui.beans.nav.OAButtonBean;
import oracle.apps.xx03.util.Xx03ArCommonUtil;
import oracle.apps.xx03.util.Xx03CommonUtil;

import oracle.bali.share.util.BooleanUtils;

import oracle.jbo.domain.Number;

//Ver11.5.10.1.6E Add Start
import oracle.apps.fnd.framework.webui.beans.OAWebBeanDataAttribute;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
//Ver11.5.10.1.6E Add End

//ver11.5.10.1.6G Add Start
import oracle.apps.fnd.framework.webui.OADialogPage;
//ver11.5.10.1.6G Add End

/**
 * Controller for ...
 */
public class Xx03InvoiceConfirmCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);

    //ver11.5.10.1.6G Add Start
    // �A�v���P�[�V�����E���W���[���̎擾
    OAApplicationModule am = pageContext.getRootApplicationModule();
    
    // back button support
    //ver11.5.10.1.6H Chg Start
    //if (pageContext.isBackNavigationFired(false))
    if ((pageContext.isBackNavigationFired(false))
        && (!"Y".equals(pageContext.getSessionValue("afterPrint"))))
    //ver11.5.10.1.6H Chg End
    {
      // back-button

      // rollback
      am.invokeMethod("rollback");

      // dialogpage
      OADialogPage dialogPage = new OADialogPage(
        OAException.ERROR,
        new OAException("XX03", "APP-XX03-14156"),  // �G���[���e���b�Z�[�W
        new OAException("XX03", "APP-XX03-14157"),  // �G���[�Ώ��@���b�Z�[�W
        "/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE",      // OK�{�^���������̑J�ڐ�
        null
      );

      pageContext.redirectToDialogPage(dialogPage);
    }
    else
    {
      // non back-button 
    //ver11.5.10.1.6G Add End

    try{
      /**
       ***************************************************************************
       * ���ʏ���
       ***************************************************************************
       */
      //ver11.5.10.1.6G Del Start
      //// �A�v���P�[�V�����E���W���[���̎擾
      //OAApplicationModule am = pageContext.getApplicationModule(webBean);
      //ver11.5.10.1.6G Del End

      // �p�����[�^�̎擾
//      String pageStatus = Xx03ArCommonUtil.getParameterValue(pageContext, "pageStatus").toString();
      String pageStatus = null;
      Object objPageStatus = Xx03ArCommonUtil.getParameterValue(pageContext, "pageStatus");
      Number receivableId = null;
      if (objPageStatus == null)
      {
        // �؜ߑ䎆�{�^��������
        if ((pageContext.getSessionValue("receivableId") == null)
            || (pageContext.getSessionValue("pageStatus") == null))
        {
          // Session�l������
          throw new OAException("XX03",
                                "APP-XX03-13008",
                                null,
                                OAException.ERROR,
                                null);
        }
        pageStatus = (String)pageContext.getSessionValue("pageStatus");
        receivableId = (Number)pageContext.getSessionValue("receivableId");
      }
      else if (objPageStatus.toString().equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
      {
        // �o���ꊇ���F��ʂ���J�ڂ����ꍇ��"journalId"�Ŏ擾
        receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "journalId"));
        pageStatus = objPageStatus.toString();
      }
      else
      {
        // ����ȊO��"receivableId"�Ŏ擾
        receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
        pageStatus = objPageStatus.toString();
      }
      pageContext.putSessionValue("pageStatus", pageStatus);
      pageContext.putSessionValue("receivableId", receivableId);
//      String pageStatus = Xx03ArCommonUtil.WINDOW_NAME_INPUT;
//      Number receivableId = new Number(1719);
      Number employeeId = new Number(pageContext.getEmployeeId());
      String msgNum = pageContext.getParameter("msgNum");
      String msgToken = pageContext.getParameter("msgToken");

      // �p�����[�^�̎擾(������ʗp)
      if (pageStatus.equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
      {
        // �o���ꊇ���F��ʂ���J��
        for (int i=0; i<Xx03CommonUtil.APPROVE_PARAMETER.length; i++)
        {
          //2005.04.11 change start Ver11.5.10.1.0
          String parameterName  = Xx03CommonUtil.APPROVE_PARAMETER[i];
          //2005.04.11 change end Ver11.5.10.1.0
          String parameterValue = pageContext.getParameter(parameterName);

          if (parameterValue != null)
          {
            pageContext.putSessionValue(parameterName, parameterValue);
          }
          else
          {
            pageContext.removeSessionValue(parameterName);
          }
        }
        //2005.04.13 add start Ver11.5.10.1.0
        pageContext.putSessionValue("originalPage",Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG);
        //2005.04.13 add end Ver11.5.10.1.0
      }
      else if(pageStatus.equals(Xx03ArCommonUtil.WINDOW_NAME_SEARCH))
      {
        //Ver11.5.10.1.6F Delete Start
        // ����������TransientSessionValue�ɕێ�����邱�ƂɂȂ����̂�
        // ���̏����͕K�v�Ȃ��B
        // ������ʂ���J��
        //for (int i=0; i<Xx03ArCommonUtil.SEARCH_PARAMETER.length; i++)
        //{
        //  String parameterName  = Xx03ArCommonUtil.SEARCH_PARAMETER[i];
        //  String parameterValue = pageContext.getParameter(parameterName);

        //  if (parameterValue != null)
        //  {
        //    pageContext.putSessionValue(parameterName, parameterValue);
        //  }
        //}
        //Ver11.5.10.1.6F Delete End
        //2005.04.13 add start Ver11.5.10.1.0
        pageContext.putSessionValue("originalPage",Xx03ArCommonUtil.WINDOW_NAME_SEARCH);
        //2005.04.13 add end Ver11.5.10.1.0
      }
      
      // ���b�Z�[�W�\��
      if ((msgNum != null) && (msgToken != null))
      {
        MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", msgToken)};        
        OAException msg = new OAException(
          "XX03",
          msgNum,
          msgTokens, 
          OAException.INFORMATION,
          null
        );

        pageContext.putDialogMessage(msg);
        pageContext.removeParameter("msgNum");
        pageContext.removeParameter("msgToken");
      }
      
      // AdvancedTable���[�W�����g�p���̂��܂��Ȃ�(Develper's Guide P942)
      // Boolean executeQuery = BooleanUtils.getBoolean(false);
      Boolean executeQuery = BooleanUtils.getBoolean(true);

      // �w�b�_�[�A���ׂ̌���
      try{
        //ver11.5.10.1.6 Chg Start
        //Serializable[] methodParams = {receivableId, executeQuery};
        //Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
        //am.invokeMethod("initReceivableSlips", methodParams, methodParamTypes);
        Serializable[] methodParams = {receivableId};
        Class[] methodParamTypes = {receivableId.getClass()};
        am.invokeMethod("initConfirmReceivableSlips", methodParams, methodParamTypes);
        //ver11.5.10.1.6 Chg End
      }
      catch(Exception ex)
      {
        throw new OAException(ex.getMessage());
      }

      // �\���A��\���̐ݒ�
      setDispRendered(pageContext, webBean, am);

      // �`�[��ʂ̕\��
      OAHeaderBean slipHeaderTitleBean = (OAHeaderBean)webBean.findIndexedChildRecursive("SlipHeaderTitleRN");
      //ver11.5.10.1.6 Chg Start
      //slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
      //  new OADataBoundValueViewObject(slipHeaderTitleBean, "SlipTypeName", "Xx03ReceivableSlipsVO1"));
      slipHeaderTitleBean.setAttributeValue(OAWebBeanConstants.TEXT_ATTR,
        new OADataBoundValueViewObject(slipHeaderTitleBean, "SlipTypeName", "Xx03ConfirmDispSlipsVO1"));
      //ver11.5.10.1.6 Chg End

      //Ver11.5.10.1.6E Add Start
      OAMessageStyledTextBean currencyCode =
        (OAMessageStyledTextBean)webBean.findChildRecursive("InvoiceCurrencyCode");
      String currencyCodeStr = currencyCode.getValue(pageContext).toString();

      setCurrencyCodeToBean(webBean ,"EnteredItemAmount"     ,currencyCodeStr);
      setCurrencyCodeToBean(webBean ,"EnteredTaxAmount"      ,currencyCodeStr);
      setCurrencyCodeToBean(webBean ,"SlipLineQuantity"      ,currencyCodeStr);
      setCurrencyCodeToBean(webBean ,"SlipLineUnitPrice"     ,currencyCodeStr);
      setCurrencyCodeToBean(webBean ,"SlipLineEnteredAmount" ,currencyCodeStr);
      //Ver11.5.10.1.6E Add End

      //ver11.5.10.1.6 Del Start
      //// �ʉ݂ɂ����z�t�H�[�}�b�g
      //am.invokeMethod("formatAmount");
      //ver11.5.10.1.6 Del End

      // ���b�Z�[�W�\��(�d�_�Ǘ��`�[�A�o���C���`�[)
      //ver11.5.10.2.6 Del Start
      //OAFormValueBean accountApprovalFlag =
      //  (OAFormValueBean)webBean.findChildRecursive("AccountApprovalFlag");
      //ver11.5.10.2.6 Del End

      OAFormValueBean accountRevisionFlag =
        (OAFormValueBean)webBean.findChildRecursive("AccountRevisionFlag");
      OAWebBeanStyledText receivableNum =
        (OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum");

      //ver11.5.10.2.6 Del Start
      //String accountApprovalFlagStr = accountApprovalFlag.getValue(pageContext).toString();
      //ver11.5.10.2.6 Del End

      String accountRevisionFlagStr = accountRevisionFlag.getValue(pageContext).toString();
      String receivableNumStr = receivableNum.getValue(pageContext).toString();

      // AFF�v�����v�g�擾�A���̐ݒ�
      OAWebBeanStyledText segment1Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment1Name");
      OAWebBeanStyledText segment2Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment2Name");
      OAWebBeanStyledText segment3Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment3Name");
      OAWebBeanStyledText segment4Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment4Name");
      OAWebBeanStyledText segment5Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment5Name");
      OAWebBeanStyledText segment6Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment6Name");
      OAWebBeanStyledText segment7Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment7Name");
      OAWebBeanStyledText segment8Name = (OAWebBeanStyledText)webBean.findChildRecursive("Segment8Name");
      OAWebBeanStyledText incrDecrReasonName = (OAWebBeanStyledText)webBean.findChildRecursive("IncrDecrReasonName");
      OAWebBeanStyledText reconReference = (OAWebBeanStyledText)webBean.findChildRecursive("ReconReference");
      ArrayList affPromptInfo = (ArrayList)am.invokeMethod("getAFFPromptArInput");
      segment1Name.setLabel((String)affPromptInfo.get(0));
      segment2Name.setLabel((String)affPromptInfo.get(1));
      segment3Name.setLabel((String)affPromptInfo.get(2));
      segment4Name.setLabel((String)affPromptInfo.get(3));
      segment5Name.setLabel((String)affPromptInfo.get(4));
      segment6Name.setLabel((String)affPromptInfo.get(5));
      segment7Name.setLabel((String)affPromptInfo.get(6));
      segment8Name.setLabel((String)affPromptInfo.get(7));
      incrDecrReasonName.setLabel((String)affPromptInfo.get(8));
      reconReference.setLabel((String)affPromptInfo.get(9));

      //2005.04.20 add start Ver11.5.10.1.1
      // ���F�R�����g�̃N���A
      OAWebBeanTextInput approverComment =
        (OAWebBeanTextInput)webBean.findChildRecursive("ApproverComments");
      if(approverComment.isRendered() == true)
      {
        approverComment.setValue(pageContext, "");
      }
      //2005.04.20 add end Ver11.5.10.1.1

      //ver11.5.10.2.6 Chg Start
      //if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlagStr))
      //{
      //  // �d�_�Ǘ��`�[
      //  MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNumStr)};
      //  OAException msg = new OAException(
      //    "XX03",
      //    "APP-XX03-33500",
      //    msgTokens,
      //    OAException.INFORMATION,
      //    null
      //  );
      //  pageContext.putDialogMessage(msg);
      //}

      // �d�_�Ǘ��`�F�b�N���\�b�h���Ăяo��
      String accountApprovalFlagStr = (String)am.invokeMethod("setAccAppFlag_Conf");
      if (   (!Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlagStr))
          && (!Xx03ArCommonUtil.STR_NO.equals(accountApprovalFlagStr) ) )
      {
        // �d�_�Ǘ��̎擾�Ɏ��s�����G���[�\�� 
        throw new OAException("XX03",
                              "APP-XX03-14143",
                              null,
                              OAException.ERROR,
                              null);
      }
      else if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlagStr))
      {
        // �d�_�Ǘ��`�[
        MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNumStr)};
        OAException msg = new OAException(
          "XX03",
          "APP-XX03-33500",
          msgTokens,
          OAException.INFORMATION,
          null
        );
        pageContext.putDialogMessage(msg);
      }
      //ver11.5.10.2.6 Chg End

      if ((Xx03ArCommonUtil.STR_YES.equals(accountRevisionFlagStr))
          || ("T".equals(accountRevisionFlagStr)))
      {
        // �o���C���`�[
        MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNumStr)};
        OAException msg = new OAException(
          "XX03",
          "APP-XX03-33501",
          msgTokens,
          OAException.INFORMATION,
          null
        );
        pageContext.putDialogMessage(msg);
      }

      //Ver11.5.10.1.4 Add Start
      //�x���\���̂��߂̃G���[�`�F�b�N���{
      Number checkReceivableId = new Number(receivableId);
      Serializable[] methodParams = new Serializable[]{checkReceivableId};
      Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
      Vector msgVec = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

      String retCode = msgVec.firstElement().toString();
      msgVec.removeElementAt(0);

      if (Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode))
      {
        throw OAException.getBundledOAException(msgVec);
      }
      //Ver11.5.10.1.4 Add END

      //ver11.5.10.1.6H Add Start
      if ("printable".equals(pageContext.getParameter("OARF")))
      {
        pageContext.putSessionValue("afterPrint", "Y");
      }
      else
      {
        pageContext.removeSessionValue("afterPrint");  
      }
      //ver11.5.10.1.6H Add End

    }
    catch(OAException ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            null,
                            OAException.ERROR,
                            null);      
    }

    //ver11.5.10.1.6G Add Start
    }
    //ver11.5.10.1.6G Add End

  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processFormRequest(pageContext, webBean);

    try{
      // ***************************************************************************
      // * ����
      // ***************************************************************************
      // ��ʑJ�ڃp�����[�^
      HashMap parameters = new HashMap(4);

      // �A�v���P�[�V�����E���W���[���̎擾
      OAApplicationModule am = pageContext.getApplicationModule(webBean);

      // �p�����[�^�̎擾
      // Number receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));

      Number receivableId = new Number(((OAFormValueBean)webBean.findChildRecursive("ReceivableId")).getValue(pageContext));
      String receivableNum = ((OAWebBeanStyledText)webBean.findChildRecursive("ReceivableNum")).getValue(pageContext).toString();
      String accountApprovalFlag = ((OAFormValueBean)webBean.findChildRecursive("AccountApprovalFlag")).getValue(pageContext).toString();
      String slipType = ((OAFormValueBean)webBean.findChildRecursive("SlipType")).getValue(pageContext).toString();
      Number requestorPersonId = new Number(((OAFormValueBean)webBean.findChildRecursive("RequestorPersonId")).getValue(pageContext));
      Number employeeId = new Number(pageContext.getEmployeeId());
      Number transTypeId = new Number(((OAFormValueBean)webBean.findChildRecursive("TransTypeId")).getValue(pageContext));
        
      //Ver11.5.10.1.6F Add Start
      OAFormValueBean accountRevisionFlag =
        (OAFormValueBean)webBean.findChildRecursive("AccountRevisionFlag");
      String accountRevisionFlagStr = accountRevisionFlag.getValue(pageContext).toString();
      //Ver11.5.10.1.6F Add End

      //
      // ���[�N�t���[�E�C�x���g
      //
      // ***************************************************************************
      // * ���F
      // ***************************************************************************
      if (pageContext.getParameter("Approve") != null)
      {
        String num_type = Xx03ArCommonUtil.NON_TEMP_SLIP_NUM_TYPE;

        //ver11.5.10.1.6 Add Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkConfValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver11.5.10.1.6 Add End

        // �d��`�F�b�N�֐��̌ďo
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = new Serializable[]{checkReceivableId};
        Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msgVec = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msgVec.firstElement().toString();
        msgVec.removeElementAt(0);

        //Ver11.5.10.1.4 2005/07/07 Modify Start
        //if (!Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode))
        if (!(Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode) ||
              Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode)))
        //Ver11.5.10.1.4 2005/07/07 Modify End
        {
          throw OAException.getBundledOAException(msgVec);
        }

        // ���[�N�t���[�̌ďo
        String answerFlag = Xx03ArCommonUtil.STR_YES;                 // ��(���F)
        String requestKey = ((OAFormValueBean)webBean.findChildRecursive("RequestKey")).getValue(pageContext).toString();
        //Ver11.5.10.1.6F Change Start
        //Object tmpApproverComments = ((OAWebBeanTextInput)webBean.findChildRecursive("ApproverComments")).getValue(pageContext);
        //String approverComments = "";
        //if (tmpApproverComments != null)
        //{
        //  approverComments = tmpApproverComments.toString();
        //}
        String approverComments=pageContext.getParameter("ApproverComments");
        if(null==approverComments) 
        {
          approverComments="";
        }
        //Ver11.5.10.1.6F Change End

        Number approverPersonId = new Number(((OAFormValueBean)webBean.findChildRecursive("ApproverPersonId")).getValue(pageContext));
        methodParams = new Serializable[]{receivableId,
                                          requestKey,
                                          employeeId,
                                          answerFlag,
                                          approverComments,
                                          approverPersonId};
        methodParamTypes = new Class[]{receivableId.getClass(),
                                       requestKey.getClass(),
                                       employeeId.getClass(),
                                       answerFlag.getClass(),
                                       approverComments.getClass(),
                                       approverPersonId.getClass()};
        Serializable retMsg = am.invokeMethod("answerDivProposal", methodParams, methodParamTypes);
        String msg = retMsg.toString();

        if (!Xx03ArCommonUtil.SUCCESS.equals(msg))
        {
          throw new OAException(msg);
        }

        //Ver11.5.10.1.6F Change Start
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_SELECT);

        //���b�Z�[�W�������B
        ArrayList messages=new ArrayList();
        messages.add(new OAException(
          "XX03",
          "APP-XX03-13043",
          new MessageToken[] {new MessageToken("RECEIVABLE_NUM",receivableNum)},
          OAException.INFORMATION,
          null));

        if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlag))
        {
          // �d�_�Ǘ��`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33500",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }
        // DEPTINPUT�Ԃ�l���x���� 
        if (retCode.equals(Xx03ArCommonUtil.RETCODE_WARNING))
        {
          messages.add(new OAException(
            "XX03",
            "APP-XX03-24001",
            null,
            OAException.INFORMATION,
            null));
        } 

        parameters.put("messages",Xx03CommonUtil.oaExceptionsToString(messages.iterator()));
        
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_SEARCH,     // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_YES, // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );

        // // ���b�Z�[�W
        //pageContext.putParameter("msgNum", "APP-XX03-13043");
        //pageContext.putParameter("msgToken", receivableNum);

        // // �ĕ`��
        //parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        //parameters.put("slipType", "");
        //parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_APPROVE);
        //parameters.put("receivableId", receivableId);
        
        //pageContext.setForwardURLToCurrentPage(
        //  parameters,                             // parameter
        //  true,                                   // ratainAM
        //  OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
        //  OAWebBeanConstants.IGNORE_MESSAGES
        //);
        //Ver11.5.10.1.6F Change End
      }
      // ***************************************************************************
      // * �۔F
      // ***************************************************************************
      else if (pageContext.getParameter("Deny") != null)
      {
        //Ver11.5.10.1.6F Add Start
        //�x���\���̂��߂̃G���[�`�F�b�N���{
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = new Serializable[]{checkReceivableId};
        Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msgVec = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msgVec.firstElement().toString();
        msgVec.removeElementAt(0);
        //Ver11.5.10.1.6F Add End

        // ���[�N�t���[�̌ďo
        String answerFlag = Xx03ArCommonUtil.STR_NO;                 // ��(�۔F)
        String requestKey = ((OAFormValueBean)webBean.findChildRecursive("RequestKey")).getValue(pageContext).toString();
        //Ver11.5.10.1.6F Change Start
        //Object tmpApproverComments = ((OAWebBeanTextInput)webBean.findChildRecursive("ApproverComments")).getValue(pageContext);
        //String approverComments = "";
        //if (tmpApproverComments != null)
        //{
        //  approverComments = tmpApproverComments.toString();
        //}
        String approverComments=pageContext.getParameter("ApproverComments");
        if(null==approverComments) 
        {
          approverComments="";
        }
        //Ver11.5.10.1.6F Change End

        Number approverPersonId = new Number(((OAFormValueBean)webBean.findChildRecursive("ApproverPersonId")).getValue(pageContext));
        //Ver11.5.10.1.6F Change Start
        //Serializable[] methodParams = {receivableId,
        methodParams = new Serializable[]{receivableId,
                                          requestKey,
                                          employeeId,
                                          answerFlag,
                                          approverComments,
                                          approverPersonId};
        //Ver11.5.10.1.6F Change End
        //Ver11.5.10.1.6F Change Start
        //Class[] methodParamTypes = {receivableId.getClass(),
        methodParamTypes = new Class[]{receivableId.getClass(),
                                       requestKey.getClass(),
                                       employeeId.getClass(),
                                       answerFlag.getClass(),
                                       approverComments.getClass(),
                                       approverPersonId.getClass()};
        //Ver11.5.10.1.6F Change End
        Serializable retMsg = am.invokeMethod("answerDivProposal", methodParams, methodParamTypes);
        String msg = retMsg.toString();

        if (!Xx03ArCommonUtil.SUCCESS.equals(msg))
        {
          throw new OAException(msg);
        }

        //Ver11.5.10.1.6F Change Start
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_SELECT);

        //���b�Z�[�W�������B
        ArrayList messages=new ArrayList();
        messages.add(new OAException(
          "XX03",
          "APP-XX03-13044",
          new MessageToken[] {new MessageToken("RECEIVABLE_NUM",receivableNum)},
          OAException.INFORMATION,
          null));

        if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlag))
        {
          // �d�_�Ǘ��`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33500",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }

        // DEPTINPUT�Ԃ�l���x���� 
        if (retCode.equals(Xx03ArCommonUtil.RETCODE_WARNING))
        {
          messages.add(new OAException(
            "XX03",
            "APP-XX03-24001",
            null,
            OAException.INFORMATION,
            null));
        } 

        parameters.put("messages",Xx03CommonUtil.oaExceptionsToString(messages.iterator()));
        
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_SEARCH,     // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_YES, // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );

        //// ���b�Z�[�W
        //pageContext.putParameter("msgNum", "APP-XX03-13044");
        //pageContext.putParameter("msgToken", receivableNum);

        //// �ĕ`��
        //parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        //parameters.put("slipType", "");
        //parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_DENY);
        //parameters.put("receivableId", receivableId);

        //pageContext.setForwardURLToCurrentPage(
        //  parameters,                             // parameter
        //  true,                                   // ratainAM
        //  OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
        //  OAWebBeanConstants.IGNORE_MESSAGES
        //);
        //Ver11.5.10.1.6F Change End
      }
      // ***************************************************************************
      // * �\��
      // ***************************************************************************
      else if (pageContext.getParameter("Apply") != null)
      {
        //�̔ԏ�����PL/SQL���[�N�t���[�֐��Ɉړ�
        //String num_type = Xx03ArCommonUtil.NON_TEMP_SLIP_NUM_TYPE;
        //String requestEnableFlag = Xx03ArCommonUtil.STR_YES;
        //Serializable[] methodParams = {num_type, requestEnableFlag};
        //Class[] methodParamTypes = {num_type.getClass(), requestEnableFlag.getClass()};

        // �̔�
        //am.invokeMethod("publishNum", methodParams, methodParamTypes);

        // �ۑ�
        //am.invokeMethod("save");

        //ver11.5.10.2.3 Chg Start
        ////ver11.5.10.1.6 Add Start
        //// �}�X�^�`�F�b�N
        //Vector error = (Vector)am.invokeMethod("checkConfValidation");
        //if (!error.isEmpty())
        //{
        //  throw OAException.getBundledOAException(error);
        //}
        ////ver11.5.10.1.6 Add End

        // �\�����}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkApplyValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
        //ver11.5.10.2.3 Chg End

        // �d��`�F�b�N�֐��̌ďo
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = {checkReceivableId};
        Class[] methodParamTypes = {checkReceivableId.getClass()};
        Vector msg = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msg.firstElement().toString();
        msg.removeElementAt(0);

        //Ver11.5.10.1.4 2005/07/07 Modify Start
        //if (!(Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode) ||
        if (!(Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode) ||
              Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode)))
        //Ver11.5.10.1.4 2005/07/07 Modify Start
        {
          throw OAException.getBundledOAException(msg);
        }

        // ���[�N�t���[�ďo
        receivableNum = (String)am.invokeMethod("startDivProcess");
        
        // ���b�Z�[�W
        pageContext.putParameter("msgNum", "APP-XX03-13045");
        pageContext.putParameter("msgToken", receivableNum);

        // �ĕ`��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_APPLY);
        parameters.put("receivableId", receivableId);

        //ver 11.5.10.2.10 Chg Start
        //pageContext.setForwardURLToCurrentPage(
        //  parameters,                             // parameter
        //  true,                                   // ratainAM
        //  OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
        //  OAWebBeanConstants.IGNORE_MESSAGES
        //);
        pageContext.setForwardURLToCurrentPage(
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES
        );
        //ver 11.5.10.2.10 Chg End
      }
      // ***************************************************************************
      // * �\�����
      // ***************************************************************************
      else if (pageContext.getParameter("ApplicationCancel") != null)
      {
        // ���[�N�t���[�ďo
        am.invokeMethod("cancelProposal");

        // ���b�Z�[�W
        pageContext.putParameter("msgNum", "APP-XX03-13046");
        pageContext.putParameter("msgToken", receivableNum);

        // �ĕ`��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_APP_CANCEL);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURLToCurrentPage(
          parameters,                             // parameter
          true,                                   // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES
        );       
      }
      // ***************************************************************************
      // * �o�����F
      // ***************************************************************************
      else if (pageContext.getParameter("ApproveAcc") != null)
      {
        String num_type = Xx03ArCommonUtil.NON_TEMP_SLIP_NUM_TYPE;

        //ver11.5.10.1.6 Add Start
        // �}�X�^�`�F�b�N
        Vector error = (Vector)am.invokeMethod("checkConfValidation");
        if (!error.isEmpty())
        {
          throw OAException.getBundledOAException(error);
        }
       //ver11.5.10.1.6 Add End

        // �d��`�F�b�N�֐��̌ďo
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = new Serializable[]{checkReceivableId};
        Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msg = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        //Ver11.5.10.1.6F Add Start
        String retCode = msg.firstElement().toString();
        msg.removeElementAt(0);

        if (!Xx03ArCommonUtil.RETCODE_SUCCESS.equals(retCode)
            && !Xx03ArCommonUtil.RETCODE_WARNING.equals(retCode))
        {
          throw OAException.getBundledOAException(msg);
        }
        //Ver11.5.10.1.6F Add End

        // ���[�N�t���[�̌ďo
        String answerFlag = Xx03ArCommonUtil.STR_YES;                 // ��(���F)
        Number answerId = new Number(pageContext.getEmployeeId());    // ���F��(���O�C�����[�U)
        //Ver11.5.10.1.6F Change Start
        String approverComments=pageContext.getParameter("ApproverComments");
        if(null==approverComments) 
        {
          approverComments="";
        }
        methodParams = new Serializable[]
          {receivableId, answerId, answerFlag, approverComments};
        methodParamTypes = new Class[]
          {receivableId.getClass(),answerId.getClass(), 
          answerFlag.getClass(),approverComments.getClass()}; 
        am.invokeMethod("startAccProcess", methodParams, methodParamTypes);

        //methodParams = new Serializable[]{answerFlag, answerId};
        //methodParamTypes = new Class[]{answerFlag.getClass(), answerId.getClass()}; 
        //am.invokeMethod("startAccProcess", methodParams, methodParamTypes);
        //Ver11.5.10.1.6F Change End

        //Ver11.5.10.1.6F Change Start
        // �߂��ݒ�
        if(pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
        {
          // �o���ꊇ���F��ʂ��J�ڎ�
          // �p�����[�^�̐ݒ�
          for (int i=0; i<Xx03CommonUtil.APPROVE_PARAMETER.length; i++)
          {
            String parameterName  = Xx03CommonUtil.APPROVE_PARAMETER[i];
            Object parameterValue = pageContext.getSessionValue(parameterName);

            if (parameterValue != null)
            {
              // �Z�b�V��������p�����[�^(HashMap)�ɃR�s�[��Z�b�V�����l�N���A
              parameters.put(parameterName, parameterValue.toString());
              pageContext.removeSessionValue(parameterName);
            }
          }
        
          // ��ʑJ��
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_ACCT);
        }
        else
        {
          // ������ʂ��J�ڎ�
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_SELECT);
        }
        
        //���b�Z�[�W�������B
        ArrayList messages=new ArrayList();
        messages.add(new OAException(
          "XX03",
          "APP-XX03-13043",
          new MessageToken[] {new MessageToken("RECEIVABLE_NUM",receivableNum)},
          OAException.INFORMATION,
          null));

        if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlag))
        {
          // �d�_�Ǘ��`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33500",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }
        
        if (Xx03ArCommonUtil.STR_YES.equals(accountRevisionFlagStr))
        {
          // �o���C���`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33501",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }

        // DEPTINPUT�̕Ԃ�l���x���� 
        if (retCode.equals(Xx03ArCommonUtil.RETCODE_WARNING))
        {
          messages.add(new OAException(
            "XX03",
            "APP-XX03-24001",
            null,
            OAException.INFORMATION,
            null));
        } 

        parameters.put("messages",Xx03CommonUtil.oaExceptionsToString(messages.iterator()));

        // �߂��ݒ�
        if(pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
        {
         // �o���ꊇ���F��ʂ��J�ڎ�
          pageContext.setForwardURL(
            Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG, // url
            null,                                     // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,     // menuContextAction
            null,                                     // menuName
            parameters,                               // parameter
            false,                                    // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_YES,   // addBreadCrumb
            OAWebBeanConstants.IGNORE_MESSAGES        // messagingLevel
          );
         }
        else
        {
          // ������ʂ��J�ڎ�
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_SEARCH,     // url
            null,                                   // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
            null,                                   // menuName
            parameters,                             // parameter
            false,                                  // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_YES, // addBreadCrumb
            OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
          );
        }

        //// ���b�Z�[�W
        //pageContext.putParameter("msgNum", "APP-XX03-13043");
        //pageContext.putParameter("msgToken", receivableNum);

        //// �ĕ`��
        //parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        //parameters.put("slipType", "");
        //parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_APPROVE);
        //parameters.put("receivableId", receivableId);
        
        //pageContext.setForwardURLToCurrentPage(
        //  parameters,                             // parameter
        //  true,                                   // ratainAM
        //  OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
        //  OAWebBeanConstants.IGNORE_MESSAGES
        //);
        //Ver11.5.10.1.6F Change End
      }
      // ***************************************************************************
      // * �o���۔F
      // ***************************************************************************
      else if (pageContext.getParameter("DenyAcc") != null)
      {
        //Ver11.5.10.1.6F Add Start
        //�x���\���̂��߂̃G���[�`�F�b�N���{
        Number checkReceivableId = new Number(receivableId);
        Serializable[] methodParams = new Serializable[]{checkReceivableId};
        Class[] methodParamTypes = new Class[]{checkReceivableId.getClass()};
        Vector msgVec = (Vector)am.invokeMethod("callDeptInputAr", methodParams, methodParamTypes);

        String retCode = msgVec.firstElement().toString();
        msgVec.removeElementAt(0);
        //Ver11.5.10.1.6F Add End

        // ���[�N�t���[�ďo
        // ���[�N�t���[�̌ďo
        String answerFlag = Xx03ArCommonUtil.STR_NO;                // ��(�۔F)
        Number answerId = new Number(pageContext.getEmployeeId());  // ���F��(���O�C�����[�U)
        //Ver11.5.10.1.6F Change Start
        String approverComments=pageContext.getParameter("ApproverComments");
        if(null==approverComments) 
        {
          approverComments="";
        }
        
        methodParams = new Serializable[]
          {receivableId, answerId, answerFlag, approverComments};
        methodParamTypes = new Class[]
          {receivableId.getClass(),answerId.getClass(), 
          answerFlag.getClass(),approverComments.getClass()}; 
        am.invokeMethod("startAccProcess", methodParams, methodParamTypes);
        
        //Serializable[] methodParams = {answerFlag, answerId};
        //Class[] methodParamTypes = {answerFlag.getClass(), answerId.getClass()}; 
        //am.invokeMethod("startAccProcess", methodParams, methodParamTypes);
        //Ver11.5.10.1.6F Change End

        //Ver11.5.10.1.6F Change Start
        // �߂��ݒ�
        if(pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
        {
          // �o���ꊇ���F��ʂ��J�ڎ�
          // �p�����[�^�̐ݒ�
          for (int i=0; i<Xx03CommonUtil.APPROVE_PARAMETER.length; i++)
          {
            String parameterName  = Xx03CommonUtil.APPROVE_PARAMETER[i];
            Object parameterValue = pageContext.getSessionValue(parameterName);

            if (parameterValue != null)
            {
              // �Z�b�V��������p�����[�^(HashMap)�ɃR�s�[��Z�b�V�����l�N���A
              parameters.put(parameterName, parameterValue.toString());
              pageContext.removeSessionValue(parameterName);
            }
          }
        
          // ��ʑJ��
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_ACCT);
        }
        else
        {
          // ������ʂ��J�ڎ�
          parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
          parameters.put("slipType", "");
          parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_SELECT);
        }

        //���b�Z�[�W�������B
        ArrayList messages=new ArrayList();
        messages.add(new OAException(
          "XX03",
          "APP-XX03-13044",
          new MessageToken[] {new MessageToken("RECEIVABLE_NUM",receivableNum)},
          OAException.INFORMATION,
          null));

        if (Xx03ArCommonUtil.STR_YES.equals(accountApprovalFlag))
        {
          // �d�_�Ǘ��`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33500",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }

        if (Xx03ArCommonUtil.STR_YES.equals(accountRevisionFlagStr))
        {
          // �o���C���`�[
          MessageToken[] msgTokens = {new MessageToken("RECEIVABLE_NUM", receivableNum)};
          messages.add(new OAException(
            "XX03",
            "APP-XX03-33501",
            msgTokens,
            OAException.INFORMATION,
            null
          ));
        }
        
        // DEPTINPUT�Ԃ�l���x���� 
        if (retCode.equals(Xx03ArCommonUtil.RETCODE_WARNING))
        {
          messages.add(new OAException(
            "XX03",
            "APP-XX03-24001",
            null,
            OAException.INFORMATION,
            null));
        } 

        parameters.put("messages",Xx03CommonUtil.oaExceptionsToString(messages.iterator()));

        // �߂��ݒ�
        if(pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
        {
         // �o���ꊇ���F��ʂ��J�ڎ�
          pageContext.setForwardURL(
            Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG, // url
            null,                                     // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,     // menuContextAction
            null,                                     // menuName
            parameters,                               // parameter
            false,                                    // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_YES,   // addBreadCrumb
            OAWebBeanConstants.IGNORE_MESSAGES        // messagingLevel
          );
         }
        else
        {
          // ������ʂ��J�ڎ�
          pageContext.setForwardURL(
            Xx03ArCommonUtil.WINDOW_URL_SEARCH,     // url
            null,                                   // functinoName
            OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
            null,                                   // menuName
            parameters,                             // parameter
            false,                                  // ratainAM
            OAWebBeanConstants.ADD_BREAD_CRUMB_YES, // addBreadCrumb
            OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
          );
        }

        // ���b�Z�[�W
        //pageContext.putParameter("msgNum", "APP-XX03-13044");
        //pageContext.putParameter("msgToken", receivableNum);

        //// �ĕ`��
        //parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        //parameters.put("slipType", "");
        //parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_DENY);
        //parameters.put("receivableId", receivableId);

        //pageContext.setForwardURLToCurrentPage(
        //  parameters,                             // parameter
        //  true,                                   // ratainAM
        //  OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
        //  OAWebBeanConstants.IGNORE_MESSAGES
        //);
        //Ver11.5.10.1.6F Change End
      }
      ////////////////////////////////////////////////////////////////////////////
      // �񃏁[�N�t���[�E�C�x���g
      ////////////////////////////////////////////////////////////////////////////
      // ***************************************************************************
      // * �X�V
      // ***************************************************************************
      else if (pageContext.getParameter("Update") != null)
      {
        // �ۑ�
        //ver11.5.10.1.6 Chg Start
        //am.invokeMethod("save");
        am.invokeMethod("confirmSave");
        //ver11.5.10.1.6 Chg End
        
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_UPDATE);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_INPUT,        // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          //ver11.5.10.1.6 Chg Start
          //true,                                   // ratainAM
          false,                                  // ratainAM
          //ver11.5.10.1.6 Chg End
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );
      }
      // ***************************************************************************
      // * �C��
      // ***************************************************************************
      else if (pageContext.getParameter("Modify") != null)
      {
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_MODIFY);
        parameters.put("receivableId", receivableId);

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_ACCTMODIFY, // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          //ver11.5.10.1.6 Chg Start
////          false,                                  // ratainAM
          //true,                                   // ratainAM
          false,                                  // ratainAM
          //ver11.5.10.1.6 Chg End
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel        
        );
      }
      // ***************************************************************************
      // * �R�s�[
      // ***************************************************************************
      else if (pageContext.getParameter("Copy") != null)
      {
/* �R�s�[������J�ڐ�̓��͉�ʂɈړ����ARetainAM��false��(�_�u���N���b�N�Ή�)
        // ����
        Number newreceivableId = (Number)am.invokeMethod("copy");
*/
      
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_COPY);
        parameters.put("receivableId", receivableId);
        
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_INPUT,      // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );
      }
      // ***************************************************************************
      // * �V�K
      // ***************************************************************************
      else if (pageContext.getParameter("New") != null)
      {
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", slipType);
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_NEW);
        parameters.put("receivableId", "");

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_INPUT,        // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );
      }
      // ***************************************************************************
      // * �`�[���
      // ***************************************************************************
      else if (pageContext.getParameter("SlipCancel") != null)
      {
        // ����`�[����^�C�v�擾
        Hashtable returnHashtable = new Hashtable();
        Serializable[] methodParams = {transTypeId};
        Class[] methodParamTypes = {transTypeId.getClass()};
        returnHashtable = (Hashtable)am.invokeMethod("getCreditMemoTypeInfo", methodParams, methodParamTypes);
        // ����`�[���p�����[�^�Z�b�g
        parameters.put("paramCreditMemoTypeId", (Number)returnHashtable.get("creditTypeId"));
        parameters.put("paramCreditMemoTypeName", (String)returnHashtable.get("creditTypeName"));
        
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_SLIP_CANCEL);
        parameters.put("receivableId", receivableId.toString());

        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_CANCEL,     // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          //ver11.5.10.1.6 Chg Start
          //true,                                   // ratainAM
          false,                                  // ratainAM
          //ver11.5.10.1.6 Chg End
          OAWebBeanConstants.ADD_BREAD_CRUMB_NO,  // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );
      }
      // ***************************************************************************
      // * ������ʂ֖߂�
      // ***************************************************************************
      else if (pageContext.getParameter("BackToSelect") != null
        //Ver11.5.10.1.6F Add Start
        || pageContext.getParameter("BackToSearch") != null
        //Ver11.5.10.1.6F Add End
      )
      {
        // �����ꗗ�֖߂�B�`���[�g���A���Q�ƁuBREAD CRUMB�v
        
        //Ver11.5.10.1.6F Delete Start
        //// �p�����[�^�̐ݒ�
        //for (int i=0; i<Xx03ArCommonUtil.SEARCH_PARAMETER.length; i++)
        //{
        //  String parameterName  = Xx03ArCommonUtil.SEARCH_PARAMETER[i];
        //  Object parameterValue = pageContext.getSessionValue(parameterName);

        //  if (parameterValue != null)
        //  {
        //    // �Z�b�V��������p�����[�^(HashMap)�ɃR�s�[��Z�b�V�����l�N���A
        //    parameters.put(parameterName, parameterValue.toString());
        //    pageContext.removeSessionValue(parameterName);
        //  }
        //}
        //Ver11.5.10.1.6F Delete End

        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_SELECT);
        
        pageContext.setForwardURL(
          Xx03ArCommonUtil.WINDOW_URL_SEARCH,     // url
          null,                                   // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,   // menuContextAction
          null,                                   // menuName
          parameters,                             // parameter
          false,                                  // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_YES, // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES      // messagingLevel
        );
      }
      // ***************************************************************************
      // * �o���ꊇ���F��ʂ֖߂�
      // ***************************************************************************
      else if (pageContext.getParameter("BackToAcct") != null)
      {
        // �o���ꊇ���F��ʂ֖߂�B�`���[�g���A���Q�ƁuBREAD CRUMB�v

        // �p�����[�^�̐ݒ�
        for (int i=0; i<Xx03CommonUtil.APPROVE_PARAMETER.length; i++)
        {
          String parameterName  = Xx03CommonUtil.APPROVE_PARAMETER[i];
          Object parameterValue = pageContext.getSessionValue(parameterName);

          if (parameterValue != null)
          {
            // �Z�b�V��������p�����[�^(HashMap)�ɃR�s�[��Z�b�V�����l�N���A
            parameters.put(parameterName, parameterValue.toString());
            pageContext.removeSessionValue(parameterName);
          }
        }
        
        // ��ʑJ��
        parameters.put("pageStatus", Xx03ArCommonUtil.WINDOW_NAME_CONFIRM);
        parameters.put("slipType", "");
        parameters.put("funcButton", Xx03ArCommonUtil.FUNC_NAME_BACK_TO_ACCT);

        pageContext.setForwardURL(
          Xx03CommonUtil.WINDOW_URL_ACCTPACKRECONG, // url
          null,                                     // functinoName
          OAWebBeanConstants.KEEP_MENU_CONTEXT,     // menuContextAction
          null,                                     // menuName
          parameters,                               // parameter
          false,                                    // ratainAM
          OAWebBeanConstants.ADD_BREAD_CRUMB_YES,   // addBreadCrumb
          OAWebBeanConstants.IGNORE_MESSAGES        // messagingLevel
        );
      }
    }
    catch(OAException ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw OAException.wrapperException(ex);
    }
    catch(Exception ex)
    {
      // �G���[�E���b�Z�[�W
      ex.printStackTrace();
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            null,
                            OAException.ERROR,
                            null);
    }
  }

  /**
   * �g�p�A�s�̐ݒ�
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   * @param am RootApplicationModule
   */
  private void setDispRendered(OAPageContext pageContext,
                               OAWebBean webBean,
                               OAApplicationModule am)
  {
    try{
      // ��ʂ̏]�ƈ�
      int nowEmployeeId = pageContext.getEmployeeId();

      // �ۑ����Ă���]�ƈ�
      OAFormValueBean entryPersonId =
        (OAFormValueBean)webBean.findChildRecursive("EntryPersonId");
      Integer saveEnployeeInteger =
        new Integer(entryPersonId.getValue(pageContext).toString());
      int saveEmployeeId = saveEnployeeInteger.intValue();

      // �ۑ����Ă��鏳�F��
      OAFormValueBean approverPersonId =
        (OAFormValueBean)webBean.findChildRecursive("ApproverPersonId");

      // WorkFolw�X�e�[�^�X���擾
      OAFormValueBean wkStatus =
        (OAFormValueBean)webBean.findChildRecursive("WfStatus");
      String workFlowStatus = wkStatus.getValue(pageContext).toString();

      // Ver11.5.10.1.6C Add Start
      // �`�[��ʃA�v�����擾
      OAFormValueBean slipTypeApp =
        (OAFormValueBean)webBean.findChildRecursive("SlipTypeApp");
      String slipTypeApplication = slipTypeApp.getValue(pageContext).toString();
      // Ver11.5.10.1.6C Add End

      Integer saveApproverInteger = null;
      int saveApproverId = 0;

      if (!(workFlowStatus.equals("80")))
      {
        if (approverPersonId.getValue(pageContext) != null) 
        {
          saveApproverInteger = 
            new Integer(approverPersonId.getValue(pageContext).toString());
          saveApproverId = saveApproverInteger.intValue();
        }
      }
      
      //Ver11.5.10.1.6B 2005/11/18 Delete Start
      // // �\���\�t���O
      //OAFormValueBean requestEnableFlag =
      //  (OAFormValueBean)webBean.findChildRecursive("RequestEnableFlag");
      //String requestFlag = requestEnableFlag.getValue(pageContext).toString();
      //Ver11.5.10.1.6B 2005/11/18 Delete End

      // �o���C���t���O
      OAFormValueBean accountRevisionFlag =
        (OAFormValueBean)webBean.findChildRecursive("AccountRevisionFlag");
      String accountFlag = accountRevisionFlag.getValue(pageContext).toString();

      // �E�Ӄ��x���v���t�@�C���I�v�V�������擾
      String respLevel = (String)am.invokeMethod("getRespLevel");
      // Ver11.5.10.1.6C Add Start
      String accAppMod = (String)am.invokeMethod("getAccAppMod");
      // Ver11.5.10.1.6C Add End

      // ���F��LOV
      OAMessageLovInputBean approverPersonNameInput =
        (OAMessageLovInputBean)webBean.findChildRecursive("ApproverPersonName");
      approverPersonNameInput.setCSSClass("OraFieldText");

      //ver 11.5.10.1.6D Add Start
      boolean defaultApproverFlg = false;
      //ver 11.5.10.1.6D Add End

      // ���F�{�^��
      OASubmitButtonBean approveButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Approve");

      // �۔F�{�^��
      OASubmitButtonBean rejectButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Deny");

      // �o�����F�{�^��
      OASubmitButtonBean approveAccButton =
        (OASubmitButtonBean)webBean.findChildRecursive("ApproveAcc");

      // �o���۔F�{�^��
      OASubmitButtonBean rejectAccButton =
        (OASubmitButtonBean)webBean.findChildRecursive("DenyAcc");

      // �R�����g
      OAWebBeanTextInput approverComment =
        (OAWebBeanTextInput)webBean.findChildRecursive("ApproverComments");

      // �X�V�{�^��
      OASubmitButtonBean updateButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Update");

      // �C���{�^��
      OASubmitButtonBean modifyButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Modify");

      // �\���{�^��
      OASubmitButtonBean applyButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Apply");

      // �R�s�[�{�^��
      OASubmitButtonBean copyButton =
        (OASubmitButtonBean)webBean.findChildRecursive("Copy");

      // �V�K�{�^��
      OASubmitButtonBean newButton =
        (OASubmitButtonBean)webBean.findChildRecursive("New");

      // (������ʂ�)�߂�{�^��
      OASubmitButtonBean backToSelectButton =
        (OASubmitButtonBean)webBean.findChildRecursive("BackToSelect");

        //Ver11.5.10.1.6F Add Start
      // ������ʂ֖߂�{�^��
      OASubmitButtonBean backToSearchButton=
        (OASubmitButtonBean)webBean.findChildRecursive("BackToSearch");
        //Ver11.5.10.1.6F Add End

      // (�o���ꊇ���F��ʂ�)�߂�{�^��
      OASubmitButtonBean backToAcctButton =
        (OASubmitButtonBean)webBean.findChildRecursive("BackToAcct");

      // ����������{�^��
      OASubmitButtonBean slipCancelButton =
        (OASubmitButtonBean)webBean.findChildRecursive("SlipCancel");

      // �C�����`�[�ԍ�
      OAWebBeanStyledText origInvoiceNum =
        (OAWebBeanStyledText)webBean.findChildRecursive("OrigInvoiceNum");

      // Printable Page
      OAButtonBean printPage =
        (OAButtonBean)webBean.findChildRecursive("Print");

      // WorkFlow�X�e�[�^�X�ɂ�萧��
      // �؜ߑ䎆�{�^���̔�\��
      // �ۑ��E�۔F�͔�\��
      if (workFlowStatus.equals("00") || workFlowStatus.equals("10"))
      {
        printPage.setRendered(false);
      }
      // ���F�ς݂͕\��
      else if (workFlowStatus.equals("80"))
      {
        printPage.setRendered(true);
      }
      // ���右�F�ҁE����ŏI���F�ҁE�o�����F��
      else
      {
        // ���O�C�����Ă��郆�[�U�łȂ��ꍇ��\��
        if (saveEmployeeId != nowEmployeeId)
        {
          printPage.setRendered(false);
        }
      }

      // �߂�{�^���̔�\��
      if (pageContext.getParameter("pageStatus") != null)
      {
        // ������ʂ��J�ڎ�
        if (pageContext.getParameter("pageStatus").equals(Xx03ArCommonUtil.WINDOW_NAME_SEARCH))
        {
          backToSelectButton.setRendered(true);
          backToAcctButton.setRendered(false);
          //Ver11.5.10.1.6F Add Start
          backToSearchButton.setRendered(false);
          //Ver11.5.10.1.6F Add End
        }
        // �o���ꊇ���F��ʂ��J�ڎ�
        else if(pageContext.getParameter("pageStatus").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
        {
          backToSelectButton.setRendered(false);
          backToAcctButton.setRendered(true);
          //Ver11.5.10.1.6F Add Start
          backToSearchButton.setRendered(false);
          //Ver11.5.10.1.6F Add End
        }
        //2005.04.06 add start Ver11.5.10.1.0
        // �o���C����ʂ��J�ڎ�
        else if(pageContext.getParameter("pageStatus").equals(Xx03ArCommonUtil.WINDOW_NAME_ACCTMODIFY))
        {
          String accountRevisionFlagStr = accountRevisionFlag.getValue(pageContext).toString();
          // ���߂̑J�ڌ����o���ꊇ���F��ʂ̏ꍇ
          if(pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
          {
            backToSelectButton.setRendered(false);
            if (Xx03ArCommonUtil.STR_NO.equals(accountRevisionFlagStr))
            {
              // �o���C���Ȃ�
              backToAcctButton.setRendered(true);
            }
            else
            {
              // �o���C���ς�
              backToAcctButton.setRendered(false);
            }
          }
          // ���߂̑J�ڌ���������ʂ̏ꍇ
          if(pageContext.getSessionValue("originalPage").equals(Xx03ArCommonUtil.WINDOW_NAME_SEARCH))
          {
            backToAcctButton.setRendered(false);
            if (Xx03ArCommonUtil.STR_NO.equals(accountRevisionFlagStr))
            {
              // �o���C���Ȃ�
              backToSelectButton.setRendered(true);
            }
            else
            {
              // �o���C���ς�
              backToSelectButton.setRendered(false);
            }
          }
          //Ver11.5.10.1.6F Add Start
          backToSearchButton.setRendered(false);
          //Ver11.5.10.1.6F Add End
        }
        //2005.04.06 add end Ver11.5.10.1.0
        // ���̑��̉�ʂ��J�ڎ�
        else
        {
          backToSelectButton.setRendered(false);
          backToAcctButton.setRendered(false);
          //Ver11.5.10.1.6F Add Start
          // ���߂̑J�ڌ���������ʁE�o���ꊇ���F��ʂ̏ꍇ
          if(pageContext.getSessionValue("originalPage") == null)
          {
            backToSearchButton.setRendered(false);
          }
          else{
            if(   (pageContext.getSessionValue("originalPage").equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
               || (pageContext.getSessionValue("originalPage").equals(Xx03ArCommonUtil.WINDOW_NAME_SEARCH)      )
               )
            {
              backToSearchButton.setRendered(true);
            }
            else
            {
              backToSearchButton.setRendered(false);
            }            
          }
          //Ver11.5.10.1.6F Add End
        }
      }
      else
      {
        // �J�ڌ��y�[�W�p�����[�^�Ȃ�
        backToSelectButton.setRendered(false);
        backToAcctButton.setRendered(false);
        //Ver11.5.10.1.6F Add Start
        backToSearchButton.setRendered(false);
        //Ver11.5.10.1.6F Add End
      }

      // �C�����`�[�ԍ���NULL�̏ꍇ�A�C�����`�[�ԍ��͔�\��
      if (origInvoiceNum.getValue(pageContext) == null)
      {
        origInvoiceNum.setRendered(false);
      }
      // �C�����`�[�ԍ�������ꍇ�A����������A�X�V�A�R�s�[�̊e�{�^���͎g�p�s��
      else
      {
        // ����������͕s��
        slipCancelButton.setRendered(false);
        // �X�V�{�^���͕s��
        updateButton.setRendered(false);
        // �R�s�[�{�^���͕s��
        copyButton.setRendered(false);
      }

      // WorkFlow�X�e�[�^�X�ɂ�蕪�����
      // �ۑ�
      if (workFlowStatus.equals("00"))
      {
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);

        // �C���{�^��
        modifyButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);

        // ������͎ҐE�ӂłȂ�
        if (!(respLevel.equals("0")))
        {
          // �R�s�[
          copyButton.setRendered(false);
          // �V�K
          newButton.setRendered(false);
        }

        // �ۑ��f�[�^�Ə]�ƈ�������̏ꍇ
        if (saveEmployeeId == nowEmployeeId)
        {
          //Ver11.5.10.1.6B 2005/11/18 Delete Start
          // �X�V�t���O���m�F
          //if (requestFlag.equals("N"))
          //{
          //  // ���F��LOV
          //  approverPersonNameInput.setReadOnly(true);
          //  approverPersonNameInput.setCSSClass("OraDataText");

          //  // �\���s��
          //  applyButton.setRendered(false);
          //}
          //else if (requestFlag.equals("Y"))
          //{
          //  // ���F��
          //}
          //Ver11.5.10.1.6B 2005/11/18 Delete End
        }
        // �ۑ��f�[�^�Ə]�ƈ�������łȂ��ꍇ
        else if (saveEmployeeId != nowEmployeeId)
        {
          // ���F��LOV
          approverPersonNameInput.setReadOnly(true);
          approverPersonNameInput.setCSSClass("OraDataText");

          // �X�V
          updateButton.setRendered(false);
          // �\��
          applyButton.setRendered(false);
        }
      }
      // �۔F
      else if (workFlowStatus.equals("10"))
      {
        // ���F��LOV
        approverPersonNameInput.setReadOnly(true);
        approverPersonNameInput.setCSSClass("OraDataText");
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);

        // �X�V�{�^��
        updateButton.setRendered(false);
        // �C���{�^��
        modifyButton.setRendered(false);
        // �\���{�^��
        applyButton.setRendered(false);
        // ����������{�^��
        slipCancelButton.setRendered(false);

        // ������͎ҐE�ӂłȂ�
        if (!(respLevel.equals("0")))
        {
          // �R�s�[
          copyButton.setRendered(false);
          // �V�K
          newButton.setRendered(false);
        }
      }
      // ���右�F�҂��܂��͕���ŏI���F�҂�
      else if (workFlowStatus.equals("20") || workFlowStatus.equals("30"))
      {
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �X�V
        updateButton.setRendered(false);
        // �C��
        modifyButton.setRendered(false);
        // �\��
        applyButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);

        // ������͎ҐE��
        if (respLevel.equals("0"))
        {
          // ���F��LOV
          approverPersonNameInput.setReadOnly(true);
          approverPersonNameInput.setCSSClass("OraDataText");
          // ���F�{�^��
          approveButton.setRendered(false);
          // �۔F�{�^��
          rejectButton.setRendered(false);
          // �R�����g
          approverComment.setRendered(false);
        }
        else
        {
          // �R�s�[
          copyButton.setRendered(false);
          // �V�K
          newButton.setRendered(false);

          // ���������右�F��
          if (saveApproverId == nowEmployeeId && (!respLevel.equals("9")))
          {
            // ����ŏI���F���͏��F�҂�\�����Ȃ�
            if (workFlowStatus.equals("30"))
            {
              // ���F��LOV
              approverPersonNameInput.setReadOnly(true);
              approverPersonNameInput.setCSSClass("OraDataText");
            }
            else
            {
              defaultApproverFlg = true;
            }
          }
          // ���̑����右�F�҂ƌo���ӔC��
          else
          {
            // ���F��LOV
            approverPersonNameInput.setReadOnly(true);
            approverPersonNameInput.setCSSClass("OraDataText");
            // ���F�{�^��
            approveButton.setRendered(false);
            // �۔F�{�^��
            rejectButton.setRendered(false);
            // �R�����g
            approverComment.setRendered(false);
          }
        }
      }
      // �o�����F�҂�
      else if (workFlowStatus.equals("60"))
      {
        // ���F��LOV
        approverPersonNameInput.setReadOnly(true);
        approverPersonNameInput.setCSSClass("OraDataText");

        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �\��
        applyButton.setRendered(false);
        // �X�V
        updateButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);

        // ������͎ҐE�ӂ̏ꍇ
        if (respLevel.equals("0"))
        {
          // �o�����F�{�^��
          approveAccButton.setRendered(false);
          // �o���۔F�{�^��
          rejectAccButton.setRendered(false);
          // �R�����g
          approverComment.setRendered(false);
          // �C��
          modifyButton.setRendered(false);
        }
        // ���F�ҐE�ӂ̏ꍇ
        else
        {
          // �o�����F�ҐE�ӂłȂ�
          if (!(respLevel.equals("9")))
          {
            // �o�����F�{�^��
            approveAccButton.setRendered(false);
            // �o���۔F�{�^��
            rejectAccButton.setRendered(false);
            // �R�����g
            approverComment.setRendered(false);
            // �C��
            modifyButton.setRendered(false);
          }
          // Ver11.5.10.1.6C Add Start
          else if (!accAppMod.equals("ALL") && !accAppMod.equals(slipTypeApplication))
          {
            // �o�����F�{�^��
            approveAccButton.setRendered(false);
            // �o���۔F�{�^��
            rejectAccButton.setRendered(false);
            // �R�����g
            approverComment.setRendered(false);
            // �C��
            modifyButton.setRendered(false);
          }
          // Ver11.5.10.1.6C Add End

          // �o���C����
          if("T".equals(accountFlag))
          {
            // �o�����F�{�^��
            approveAccButton.setRendered(false);
            // �o���۔F�{�^��
            rejectAccButton.setRendered(false);
            // �R�����g
            approverComment.setRendered(false);
          }

          // �R�s�[
          copyButton.setRendered(false);
          // �V�K
          newButton.setRendered(false);
        }
      }
      // ���F��
      else if (workFlowStatus.equals("80"))
      {
        // ���F��LOV
        approverPersonNameInput.setReadOnly(true);
        approverPersonNameInput.setCSSClass("OraDataText");
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);

        // �X�V
        updateButton.setRendered(false);
        // �C��
        modifyButton.setRendered(false);
        // �\��
        applyButton.setRendered(false);

        // ������͎ҐE�ӂłȂ�
        if (!(respLevel.equals("0")))
        {
          // �R�s�[
          copyButton.setRendered(false);
          // �V�K
          newButton.setRendered(false);
          // ���������
          slipCancelButton.setRendered(false);
        }

        // �C�����`�[�ԍ���NULL�łȂ�
        if (origInvoiceNum.getValue(pageContext) != null)
        {
          // ���������
          slipCancelButton.setRendered(false);
        }
      }

      // ���F�K�w�N���X
      Serializable recognitionClass = null;
      String recognitionClassValue = null;

      // �����ԍ������Ƀf�[�^���擾
      String pageStatus = null;
      Object objPageStatus = Xx03ArCommonUtil.getParameterValue(pageContext, "pageStatus");
      Number receivableId = null;
      if (objPageStatus == null)
      {
        // �؜ߑ䎆�{�^��������
        if ((pageContext.getSessionValue("receivableId") == null)
            || (pageContext.getSessionValue("pageStatus") == null))
        {
          // Session�l������
          throw new OAException("XX03",
                                "APP-XX03-13008",
                                null,
                                OAException.ERROR,
                                null);
        }
        pageStatus = (String)pageContext.getSessionValue("pageStatus");
        receivableId = (Number)pageContext.getSessionValue("receivableId");
      }
      else if (objPageStatus.toString().equals(Xx03CommonUtil.WINDOW_NAME_ACCTPACKRECONG))
      {
        // �o���ꊇ���F��ʂ���J�ڂ����ꍇ��"journalId"�Ŏ擾
        receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "journalId"));
        pageStatus = objPageStatus.toString();
      }
      else
      {
        // ����ȊO��"receivableId"�Ŏ擾
        receivableId = new Number(Xx03ArCommonUtil.getParameterValue(pageContext, "receivableId"));
        pageStatus = objPageStatus.toString();
      }
      //ver11.5.10.1.6 Chg Start
      //Boolean executeQuery = BooleanUtils.getBoolean(true);
      //Serializable[] methodParams = {receivableId, executeQuery};
      //Class[] methodParamTypes = {receivableId.getClass(), executeQuery.getClass()};
      //recognitionClass = am.invokeMethod("getRecognitionClass", methodParams, methodParamTypes);
      recognitionClass = am.invokeMethod("confirmRecognitionClass");
      //ver11.5.10.1.6 Chg End

      // ���F�K�w�N���X���擾
      if (recognitionClass != null) 
      {
        recognitionClassValue = recognitionClass.toString();
      }
      else
      {
        recognitionClassValue = "";
      }   
      // �\������{�^��

      // �\������{�^��
      OASubmitButtonBean applCancelButton =
        (OASubmitButtonBean)webBean.findChildRecursive("ApplicationCancel");

      // �ȉ��̏����ɓ��Ă͂܂�Ε\������
      // ������͎ҐE�ӂŃ��O�C�����Ă��郆�[�U�����͎�
      // �X�e�[�^�X�͕��右�F�҂�����ŏI���F��
      // ��x�����F����Ă��Ȃ�(���F�K�w�N���X��1)
      if (saveEmployeeId == nowEmployeeId && 
          respLevel.equals("0") &&
          recognitionClassValue.equals("1") &&
          (workFlowStatus.equals("20") || workFlowStatus.equals("30")))
      {
        applCancelButton.setRendered(true);
      }
      else
      {
        applCancelButton.setRendered(false);
      }

      // �O����̏ꍇ�A����������͕s��
      // �O����\���敪�擾
      //ver11.5.10.1.6 Chg Start
      //String strPrePayFlag = (String)am.invokeMethod("getPrePayButton");
      String strPrePayFlag = (String)am.invokeMethod("confirmPrePay");
      //ver11.5.10.1.6 Chg End
      if ((strPrePayFlag != null) && (strPrePayFlag.equals("Y")))
      {
        // �O����̏ꍇ�A����������͕s��
        slipCancelButton.setRendered(false);
      }

      //ver11.5.10.1.6 Add Start
      //�`�[��ʂ������f�[�^�̏ꍇ�A�ȉ��̃{�^���͔�\���Ƃ���
      
      //�`�[��ʗL������������擾
      Serializable enaSlipType    = am.invokeMethod("retEnableSlipType");
      String       strEnaSlipType = enaSlipType.toString();
      
      if (strEnaSlipType.equals("N") == true)
      {
        // ���F��LOV
        approverPersonNameInput.setRendered(false);
        //ver 11.5.10.1.6D Add Start
        defaultApproverFlg = false;
        //ver 11.5.10.1.6D Add End
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);
        // �\��
        applyButton.setRendered(false);
        // �X�V 
        updateButton.setRendered(false);
        // �o���C���{�^��
        modifyButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);
        // �\�����
        applCancelButton.setRendered(false);
        // �R�s�[
        copyButton.setRendered(false);
        // �V�K 
        newButton.setRendered(false);
      }
      //ver11.5.10.1.6 Add End

      //ver11.5.10.2.3 Chg Start
      Serializable enaSlipType3    = am.invokeMethod("retEnableSlipType3");
      String       strEnaSlipType3 = enaSlipType3.toString();
      
      if (strEnaSlipType3.equals("Y1") == true)
      {
      }
      else if (strEnaSlipType3.equals("Y2") == true)
      {
        // �ؕ[�䎆�{�^��
        printPage.setRendered(false);
        // ���F��LOV
        approverPersonNameInput.setRendered(false);
        defaultApproverFlg = false;
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);
        // �\��
        applyButton.setRendered(false);
        // �X�V 
        updateButton.setRendered(false);
        // �o���C���{�^��
        modifyButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);
        // �\�����
        applCancelButton.setRendered(false);
      }
      else if (strEnaSlipType3.equals("N1") == true)
      {
        // �R�s�[
        copyButton.setRendered(false);
        // �V�K 
        newButton.setRendered(false);
      }
      else if (strEnaSlipType3.equals("N2") == true)
      {
        // �ؕ[�䎆�{�^��
        printPage.setRendered(false);
        // ���F��LOV
        approverPersonNameInput.setRendered(false);
        //ver 11.5.10.1.6D Add Start
        defaultApproverFlg = false;
        //ver 11.5.10.1.6D Add End
        // ���F�{�^��
        approveButton.setRendered(false);
        // �۔F�{�^��
        rejectButton.setRendered(false);
        // �o�����F�{�^��
        approveAccButton.setRendered(false);
        // �o���۔F�{�^��
        rejectAccButton.setRendered(false);
        // �R�����g
        approverComment.setRendered(false);
        // �\��
        applyButton.setRendered(false);
        // �X�V 
        updateButton.setRendered(false);
        // �o���C���{�^��
        modifyButton.setRendered(false);
        // ���������
        slipCancelButton.setRendered(false);
        // �\�����
        applCancelButton.setRendered(false);
        // �R�s�[
        copyButton.setRendered(false);
        // �V�K 
        newButton.setRendered(false);
      }
      //ver11.5.10.2.3 Chg Start

      //ver 11.5.10.1.6D Add Start
      if (defaultApproverFlg)
      {
        //�f�t�H���g���F�҂̎擾
        am.invokeMethod("getDefaultApprover");
      }
      //ver 11.5.10.1.6D Add End

    }
    catch(Exception ex)
    {
      // debug
      ex.printStackTrace();
      
      // �V�X�e���G���[
      throw new OAException("XX03",
                            "APP-XX03-13008",
                            ex);
    }
  }

  //Ver11.5.10.1.6E Add Start
  /**
   * �E�F�u�r�[���̒ʉ݃R�[�h��ύX���܂��B
   * @param pageBean     �E�F�u�r�[��
   * @param beanName     �ύX����r�[����ID
   * @param currencyCode �ύX����ʉ݃R�[�h
   */
  public void setCurrencyCodeToBean(OAWebBean pageBean,String beanName,String currencyCode) 
  {
    OAWebBeanDataAttribute bean = (OAWebBeanDataAttribute)pageBean.findChildRecursive(beanName);
    bean.setCurrencyCode(currencyCode);
  }
  //Ver11.5.10.1.6E Add End

}
